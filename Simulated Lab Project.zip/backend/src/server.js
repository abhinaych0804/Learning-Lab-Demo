const app = require("./app");
const config = require("./config");

app.listen(config.PORT, config.HOST, () => {
    console.log(`Simulated Labs running at http://${config.HOST}:${config.PORT} (${config.NODE_ENV})`);
});
