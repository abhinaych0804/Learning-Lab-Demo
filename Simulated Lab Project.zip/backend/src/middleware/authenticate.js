const jwt = require("jsonwebtoken");

const config = require("../config");
const db = require("../config/db");
const { accessBlockMessage } = require("../services/reportingAccess");
const { isAllowedEmail, emailPolicyMessage } = require("../services/emailPolicy");

async function authenticate(req, res, next) {
    const token = req.cookies && req.cookies[config.SESSION_COOKIE];

    if (!token) {
        return res.status(401).json({ success: false, message: "Not authenticated" });
    }

    let payload;
    try {
        payload = jwt.verify(token, config.JWT_SECRET, { algorithms: ["HS256"] });
    } catch {
        return res.status(401).json({ success: false, message: "Session expired. Please log in again." });
    }

    const [rows] = await db.query(
        `SELECT u.id, u.full_name, u.username, u.email, u.role, rl.status AS approval_status
         FROM users u
         LEFT JOIN reporting_lines rl ON rl.user_id = u.id
         WHERE u.id = ? LIMIT 1`,
        [payload.id]
    );

    if (rows.length === 0) {
        return res.status(401).json({ success: false, message: "Not authenticated" });
    }

    const { approval_status: approvalStatus, ...user } = rows[0];

    // Also covers sessions issued before an allowlist was introduced or changed.
    if (!isAllowedEmail(user.email)) {
        return res.status(403).json({ success: false, message: emailPolicyMessage() });
    }

    const blocked = accessBlockMessage(approvalStatus);
    if (blocked) {
        return res.status(403).json({ success: false, message: blocked });
    }

    req.user = user;
    next();
}

module.exports = { authenticate };
