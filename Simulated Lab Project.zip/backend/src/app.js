const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const { rateLimit } = require("express-rate-limit");

const config = require("./config");
const { authenticate } = require("./middleware/authenticate");
const authRoutes = require("./routes/auth");
const labRoutes = require("./routes/labs");
const managerRoutes = require("./routes/manager");

const app = express();

app.disable("x-powered-by");

if (config.TRUST_PROXY !== false) {
    app.set("trust proxy", config.TRUST_PROXY);
}

app.use(
    helmet({
        contentSecurityPolicy: {
            directives: {
                "upgrade-insecure-requests": config.isProd ? [] : null
            }
        }
    })
);

if (config.FRONTEND_ORIGINS.length > 0) {
    app.use(cors({ origin: config.FRONTEND_ORIGINS, credentials: true }));
}

app.use("/api/labs", express.json({ limit: "1mb" }));
app.use(express.json({ limit: "10kb" }));
app.use(cookieParser());

const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 30,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { success: false, message: "Too many attempts. Please try again later." }
});

app.get("/api/health", (req, res) => res.json({ success: true }));
app.use("/api/auth", authLimiter, authRoutes);
app.get("/api/me", authenticate, (req, res) => {
    const { id, full_name: fullName, username, email, role } = req.user;
    res.json({ success: true, user: { id, fullName, username, email, role } });
});
app.use("/api/labs", authenticate, labRoutes);
app.use("/api/manager", authenticate, managerRoutes);

app.use(express.static(config.FRONTEND_DIR));

app.use("/api", (req, res) => {
    res.status(404).json({ success: false, message: "Not found" });
});

app.use((err, req, res, next) => {
    if (res.headersSent) return next(err);

    // Errors flagged `expose` (body-parser, or raised deliberately) are safe to show.
    if (err.expose && err.status) {
        return res.status(err.status).json({ success: false, message: err.message });
    }

    console.error(err);
    res.status(500).json({ success: false, message: "Something went wrong. Please try again." });
});

module.exports = app;
