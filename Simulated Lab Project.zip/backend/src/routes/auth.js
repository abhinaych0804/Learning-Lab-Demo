const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { randomUUID } = require("crypto");

const config = require("../config");
const db = require("../config/db");
const { generateOtp, sendOtpEmail } = require("../services/emailOtp");
const { accessBlockMessage } = require("../services/reportingAccess");
const { isAllowedEmail, emailPolicyMessage } = require("../services/emailPolicy");

const router = express.Router();

const USERNAME_PATTERN = /^[A-Za-z0-9._-]{3,50}$/;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const OTP_PATTERN = /^\d{6}$/;

// Compared against when the account does not exist so response time does not reveal it.
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 10);

function text(value) {
    return typeof value === "string" ? value.trim() : "";
}

function isPasswordStrong(password) {
    return (
        typeof password === "string" &&
        password.length >= 8 &&
        password.length <= 72 &&
        /[A-Z]/.test(password) &&
        /[a-z]/.test(password) &&
        /[^A-Za-z0-9]/.test(password)
    );
}

function publicUser(row) {
    return {
        id: row.id,
        fullName: row.full_name,
        username: row.username,
        email: row.email,
        role: row.role
    };
}

// Returns false when the username or email is already taken.
// A learner's reporting-manager link is created in the same transaction, so a user never exists without it.
async function insertUser({ fullName, username, email, passwordHash, role = "learner", managerId = null }) {
    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();
        const [result] = await conn.query(
            "INSERT INTO users (full_name, username, email, password_hash, role) VALUES (?, ?, ?, ?, ?)",
            [fullName, username, email, passwordHash, role]
        );
        if (managerId) {
            await conn.query("INSERT INTO reporting_lines (user_id, manager_id) VALUES (?, ?)", [result.insertId, managerId]);
        }
        await conn.commit();
        return true;
    } catch (err) {
        await conn.rollback();
        if (err.code === "ER_DUP_ENTRY") return false;
        throw err;
    } finally {
        conn.release();
    }
}

function registrationMessage(role) {
    return role === "manager"
        ? "Manager registration successful. Please log in."
        : "Registration successful. Your reporting manager must approve your request before you can sign in.";
}

function startSession(res, user) {
    const token = jwt.sign({ id: user.id }, config.JWT_SECRET, { algorithm: "HS256", expiresIn: "1d" });

    res.cookie(config.SESSION_COOKIE, token, {
        httpOnly: true,
        sameSite: "lax",
        secure: config.isProd,
        maxAge: config.SESSION_MAX_AGE_MS
    });

    res.json({ success: true, user: publicUser(user) });
}

async function createPendingOtp({ purpose, email, userId = null, payload = null }) {
    const otp = generateOtp();
    const otpHash = await bcrypt.hash(otp, 10);
    const pendingToken = randomUUID();

    await db.query(
        `INSERT INTO email_otp_verifications
         (pending_token, purpose, email, otp_hash, user_id, payload_json, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE))`,
        [pendingToken, purpose, email, otpHash, userId, payload ? JSON.stringify(payload) : null, config.OTP_TTL_MINUTES]
    );

    try {
        await sendOtpEmail({ toEmail: email, otp, purpose });
    } catch (err) {
        await db.query("DELETE FROM email_otp_verifications WHERE pending_token = ?", [pendingToken]);
        console.error("Failed to send OTP email:", err.message);
        const error = new Error("Unable to send the verification email. Please try again later.");
        error.status = 502;
        error.expose = true;
        throw error;
    }

    return pendingToken;
}

// Returns the OTP row on success, or sends the failure response and returns null.
async function consumeOtp(req, res, purpose) {
    const pendingToken = text(req.body.pendingToken);
    const otp = text(req.body.otp);

    if (!pendingToken || !OTP_PATTERN.test(otp)) {
        res.status(400).json({ success: false, message: "Enter the 6-digit verification code." });
        return null;
    }

    const [rows] = await db.query(
        `SELECT * FROM email_otp_verifications
         WHERE pending_token = ? AND purpose = ? AND used_at IS NULL AND expires_at > NOW()
         LIMIT 1`,
        [pendingToken, purpose]
    );

    if (rows.length === 0) {
        res.status(400).json({ success: false, message: "Invalid or expired verification code." });
        return null;
    }

    const record = rows[0];

    if (record.attempts >= config.OTP_MAX_ATTEMPTS) {
        res.status(400).json({ success: false, message: "Too many incorrect attempts. Please start again." });
        return null;
    }

    if (!(await bcrypt.compare(otp, record.otp_hash))) {
        await db.query("UPDATE email_otp_verifications SET attempts = attempts + 1 WHERE id = ?", [record.id]);
        res.status(400).json({ success: false, message: "Incorrect verification code." });
        return null;
    }

    const [result] = await db.query(
        "UPDATE email_otp_verifications SET used_at = NOW() WHERE id = ? AND used_at IS NULL",
        [record.id]
    );

    if (result.affectedRows === 0) {
        res.status(400).json({ success: false, message: "Invalid or expired verification code." });
        return null;
    }

    return record;
}

router.post("/register", async (req, res) => {
    const fullName = text(req.body.fullName);
    const username = text(req.body.username);
    const email = text(req.body.email).toLowerCase();
    const password = req.body.password;
    const role = text(req.body.accountType) === "manager" ? "manager" : "learner";
    const managerEmail = text(req.body.managerEmail).toLowerCase();

    if (!fullName || fullName.length > 100) {
        return res.status(400).json({ success: false, message: "Enter your full name (up to 100 characters)." });
    }
    if (!USERNAME_PATTERN.test(username)) {
        return res.status(400).json({
            success: false,
            message: "Username must be 3-50 characters: letters, numbers, dot, underscore or hyphen."
        });
    }
    if (email.length > 150 || !EMAIL_PATTERN.test(email)) {
        return res.status(400).json({ success: false, message: "Enter a valid email address." });
    }
    if (!isAllowedEmail(email)) {
        return res.status(403).json({ success: false, message: emailPolicyMessage() });
    }
    if (!isPasswordStrong(password)) {
        return res.status(400).json({
            success: false,
            message: "Password must be 8-72 characters with an uppercase letter, a lowercase letter and a special character."
        });
    }

    let managerId = null;
    if (role === "learner") {
        if (managerEmail.length > 150 || !EMAIL_PATTERN.test(managerEmail)) {
            return res.status(400).json({ success: false, message: "Enter your reporting manager's email address." });
        }
        if (managerEmail === email) {
            return res.status(400).json({ success: false, message: "Your reporting manager cannot be your own email." });
        }
        if (!isAllowedEmail(managerEmail)) {
            return res.status(403).json({ success: false, message: emailPolicyMessage() });
        }
        const [managers] = await db.query("SELECT id FROM users WHERE email = ? AND role = 'manager' LIMIT 1", [managerEmail]);
        if (managers.length === 0) {
            return res.status(400).json({
                success: false,
                message: "No reporting manager is registered with that email. Ask your manager to register first."
            });
        }
        managerId = managers[0].id;
    }

    const [existing] = await db.query(
        "SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1",
        [email, username]
    );
    if (existing.length > 0) {
        return res.status(409).json({ success: false, message: "Username or email is already registered." });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const payload = { fullName, username, email, passwordHash, role, managerId };

    if (!config.OTP_ENABLED) {
        if (!(await insertUser(payload))) {
            return res.status(409).json({ success: false, message: "Username or email is already registered." });
        }
        return res.status(201).json({ success: true, message: registrationMessage(role) });
    }

    const pendingToken = await createPendingOtp({
        purpose: "register",
        email,
        payload
    });

    res.json({
        success: true,
        pendingToken,
        message: `A verification code has been sent to ${email}.`
    });
});

router.post("/register/verify", async (req, res) => {
    const record = await consumeOtp(req, res, "register");
    if (!record) return;

    const payload = typeof record.payload_json === "string" ? JSON.parse(record.payload_json) : record.payload_json;

    if (!(await insertUser(payload))) {
        return res.status(409).json({ success: false, message: "Username or email is already registered." });
    }

    res.status(201).json({ success: true, message: registrationMessage(payload.role) });
});


router.post("/login", async (req, res) => {
    const identifier = text(req.body.username);
    const password = typeof req.body.password === "string" ? req.body.password : "";

    if (!identifier || !password || password.length > 72) {
        return res.status(400).json({ success: false, message: "Enter your username and password." });
    }

    const [rows] = await db.query(
        "SELECT id, full_name, username, email, role, password_hash FROM users WHERE username = ? OR email = ? LIMIT 1",
        [identifier, identifier.toLowerCase()]
    );

    const user = rows[0];
    const match = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);

    if (!user || !match) {
        return res.status(401).json({ success: false, message: "Incorrect username or password." });
    }

    // Checked only after the password matches, so this never reveals whether an account exists.
    if (!isAllowedEmail(user.email)) {
        return res.status(403).json({ success: false, message: emailPolicyMessage() });
    }

    const [lines] = await db.query("SELECT status FROM reporting_lines WHERE user_id = ? LIMIT 1", [user.id]);
    const blocked = accessBlockMessage(lines.length ? lines[0].status : null);
    if (blocked) {
        return res.status(403).json({ success: false, message: blocked });
    }

    if (!config.OTP_ENABLED) {
        return startSession(res, user);
    }

    const pendingToken = await createPendingOtp({ purpose: "login", email: user.email, userId: user.id });

    res.json({
        success: true,
        pendingToken,
        message: "A verification code has been sent to your registered email."
    });
});

router.post("/login/verify", async (req, res) => {
    const record = await consumeOtp(req, res, "login");
    if (!record) return;

    const [rows] = await db.query(
        "SELECT id, full_name, username, email, role FROM users WHERE id = ? LIMIT 1",
        [record.user_id]
    );
    if (rows.length === 0) {
        return res.status(400).json({ success: false, message: "Account not found." });
    }
    if (!isAllowedEmail(rows[0].email)) {
        return res.status(403).json({ success: false, message: emailPolicyMessage() });
    }

    startSession(res, rows[0]);
});

router.post("/logout", (req, res) => {
    res.clearCookie(config.SESSION_COOKIE, { httpOnly: true, sameSite: "lax", secure: config.isProd });
    res.json({ success: true });
});

module.exports = router;
