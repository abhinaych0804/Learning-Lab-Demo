const express = require("express");

const db = require("../config/db");
const { LAB_IDS, LAB_NAMES } = require("../config/labs");

const router = express.Router();

const MAX_SCORES_PER_LAB = 20;

function requireManager(req, res, next) {
    if (req.user.role !== "manager") {
        return res.status(403).json({ success: false, message: "Reporting manager access only." });
    }
    next();
}

router.use(requireManager);

router.get("/reports", async (req, res) => {
    const managerId = req.user.id;

    const [people] = await db.query(
        `SELECT u.id, u.full_name, u.username, u.email, rl.status, rl.created_at
         FROM reporting_lines rl
         JOIN users u ON u.id = rl.user_id
         WHERE rl.manager_id = ? AND rl.status IN ('pending', 'approved')
         ORDER BY rl.created_at`,
        [managerId]
    );

    const pending = people
        .filter((p) => p.status === "pending")
        .map((p) => ({ id: p.id, fullName: p.full_name, username: p.username, email: p.email, requestedAt: p.created_at }));

    const approved = people.filter((p) => p.status === "approved");
    const approvedIds = approved.map((p) => p.id);

    const progressByUser = new Map();
    const scoresByUser = new Map();

    if (approvedIds.length > 0) {
        const [progressRows] = await db.query(
            "SELECT user_id, lab_id, status FROM lab_progress WHERE user_id IN (?)",
            [approvedIds]
        );
        progressRows.forEach((r) => {
            if (!progressByUser.has(r.user_id)) progressByUser.set(r.user_id, new Map());
            progressByUser.get(r.user_id).set(r.lab_id, r.status);
        });

        const [scoreRows] = await db.query(
            `SELECT user_id, lab_id, total, grade, elapsed_ms, fault, created_at FROM lab_scores
             WHERE user_id IN (?) ORDER BY created_at DESC, id DESC`,
            [approvedIds]
        );
        scoreRows.forEach((r) => {
            if (!scoresByUser.has(r.user_id)) scoresByUser.set(r.user_id, new Map());
            const byLab = scoresByUser.get(r.user_id);
            if (!byLab.has(r.lab_id)) byLab.set(r.lab_id, []);
            byLab.get(r.lab_id).push(r);
        });
    }

    const reports = approved.map((p) => ({
        id: p.id,
        fullName: p.full_name,
        username: p.username,
        email: p.email,
        labs: LAB_IDS.map((labId) => {
            const status = (progressByUser.get(p.id) || new Map()).get(labId) || "not_started";
            const rows = ((scoresByUser.get(p.id) || new Map()).get(labId)) || [];
            const best = rows.length > 0 ? Math.max(...rows.map((r) => r.total)) : null;
            const latest = rows.length > 0 ? rows[0].total : null;
            return {
                labId,
                name: LAB_NAMES[labId] || labId,
                status,
                attempts: rows.length,
                best,
                latest,
                scores: rows.slice(0, MAX_SCORES_PER_LAB).map((r) => ({
                    total: r.total,
                    grade: r.grade,
                    elapsedMs: r.elapsed_ms,
                    fault: r.fault,
                    createdAt: r.created_at
                }))
            };
        })
    }));

    res.json({ success: true, labIds: LAB_IDS, pending, reports });
});

router.post("/requests/:userId/decision", async (req, res) => {
    const userId = Number(req.params.userId);
    const decision = req.body.decision;

    if (!Number.isInteger(userId) || userId <= 0 || !["approve", "decline"].includes(decision)) {
        return res.status(400).json({ success: false, message: "Invalid request." });
    }

    const status = decision === "approve" ? "approved" : "declined";
    const [result] = await db.query(
        `UPDATE reporting_lines SET status = ?, decided_at = NOW()
         WHERE user_id = ? AND manager_id = ? AND status = 'pending'`,
        [status, userId, req.user.id]
    );

    if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: "No pending request found." });
    }

    res.json({ success: true, status });
});

module.exports = router;
