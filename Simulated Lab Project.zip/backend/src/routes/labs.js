const express = require("express");

const db = require("../config/db");
const { LAB_IDS } = require("../config/labs");

const router = express.Router();

const LABS = new Set(LAB_IDS);
const STATUSES = new Set(["in_progress", "completed"]);
const MAX_ACTIONS = 20000;

router.get("/progress", async (req, res) => {
    const [rows] = await db.query("SELECT lab_id, status FROM lab_progress WHERE user_id = ?", [req.user.id]);
    const progress = {};
    rows.forEach((row) => {
        progress[row.lab_id] = row.status;
    });
    res.json({ success: true, progress });
});

router.put("/:labId/progress", async (req, res) => {
    const { labId } = req.params;
    const status = req.body && req.body.status;

    if (!LABS.has(labId) || !STATUSES.has(status)) {
        return res.status(400).json({ success: false, message: "Invalid lab or status." });
    }

    // Once completed, a lab stays completed even if the learner starts it again.
    await db.query(
        `INSERT INTO lab_progress (user_id, lab_id, status, completed_at)
         VALUES (?, ?, ?, IF(? = 'completed', NOW(), NULL))
         ON DUPLICATE KEY UPDATE
             completed_at = IF(status = 'completed', completed_at, IF(? = 'completed', NOW(), NULL)),
             status = IF(status = 'completed', status, ?)`,
        [req.user.id, labId, status, status, status, status]
    );

    res.json({ success: true });
});

router.get("/:labId/actions", async (req, res) => {
    const { labId } = req.params;
    if (!LABS.has(labId)) {
        return res.status(400).json({ success: false, message: "Invalid lab." });
    }

    const [rows] = await db.query("SELECT actions FROM lab_actions WHERE user_id = ? AND lab_id = ?", [req.user.id, labId]);
    const actions = rows.length ? rows[0].actions : [];
    res.json({ success: true, actions: typeof actions === "string" ? JSON.parse(actions) : actions });
});

router.put("/:labId/actions", async (req, res) => {
    const { labId } = req.params;
    const actions = req.body && req.body.actions;

    if (!LABS.has(labId) || !Array.isArray(actions) || actions.length > MAX_ACTIONS) {
        return res.status(400).json({ success: false, message: "Invalid lab or actions." });
    }

    await db.query(
        `INSERT INTO lab_actions (user_id, lab_id, actions) VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE actions = VALUES(actions)`,
        [req.user.id, labId, JSON.stringify(actions)]
    );

    res.json({ success: true });
});

const MAX_SCORE_HISTORY = 20;
const MAX_ELAPSED_MS = 24 * 60 * 60 * 1000;
const MAX_CHECKS = 20;

function gradeFor(total) {
    if (total >= 90) return "Expert";
    if (total >= 75) return "Proficient";
    if (total >= 50) return "Developing";
    return "Needs practice";
}

function cleanChecks(checks) {
    if (!Array.isArray(checks) || checks.length > MAX_CHECKS) return null;
    const clean = [];
    for (const c of checks) {
        if (!c || typeof c.label !== "string" || typeof c.group !== "string" || !Number.isFinite(c.points) || !Number.isFinite(c.max)) {
            return null;
        }
        clean.push({ group: c.group.slice(0, 40), label: c.label.slice(0, 80), points: c.points, max: c.max });
    }
    return clean;
}

router.get("/:labId/scores", async (req, res) => {
    const { labId } = req.params;
    if (!LABS.has(labId)) {
        return res.status(400).json({ success: false, message: "Invalid lab." });
    }

    const [rows] = await db.query(
        `SELECT total, grade, elapsed_ms, fault, created_at FROM lab_scores
         WHERE user_id = ? AND lab_id = ? ORDER BY created_at DESC, id DESC LIMIT ?`,
        [req.user.id, labId, MAX_SCORE_HISTORY]
    );
    const [best] = await db.query("SELECT MAX(total) AS best FROM lab_scores WHERE user_id = ? AND lab_id = ?", [req.user.id, labId]);

    res.json({
        success: true,
        best: best[0].best,
        scores: rows.map((r) => ({ total: r.total, grade: r.grade, elapsedMs: r.elapsed_ms, fault: r.fault, createdAt: r.created_at }))
    });
});

router.post("/:labId/scores", async (req, res) => {
    const { labId } = req.params;
    const body = req.body || {};
    const checks = cleanChecks(body.checks);

    if (
        !LABS.has(labId) ||
        !Number.isInteger(body.total) || body.total < 0 || body.total > 100 ||
        !Number.isInteger(body.elapsedMs) || body.elapsedMs < 0 || body.elapsedMs > MAX_ELAPSED_MS ||
        typeof body.fault !== "string" || !/^[a-z-]{1,64}$/.test(body.fault) ||
        !checks
    ) {
        return res.status(400).json({ success: false, message: "Invalid score." });
    }

    await db.query(
        "INSERT INTO lab_scores (user_id, lab_id, total, grade, elapsed_ms, fault, details) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [req.user.id, labId, body.total, gradeFor(body.total), body.elapsedMs, body.fault, JSON.stringify({ checks })]
    );

    res.json({ success: true });
});

module.exports = router;
