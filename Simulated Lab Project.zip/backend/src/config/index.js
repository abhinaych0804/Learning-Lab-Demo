const path = require("path");

require("dotenv").config({ path: path.join(__dirname, "..", "..", ".env") });

const NODE_ENV = process.env.NODE_ENV || "development";
const JWT_SECRET = process.env.JWT_SECRET || "";
const isProd = NODE_ENV === "production";

if (JWT_SECRET.length < 32) {
    throw new Error("JWT_SECRET must be set to a random string of at least 32 characters (see .env.example).");
}

// Domains allowed to register and sign in, e.g. "hpe.com". "*" allows any address; unset means unrestricted
// in development. Production refuses to start without it so a missing setting can never open the site up.
const ALLOWED_EMAIL_DOMAINS = String(process.env.ALLOWED_EMAIL_DOMAINS || "")
    .split(",")
    .map((d) => d.trim().toLowerCase().replace(/^@/, ""))
    .filter(Boolean);

if (isProd && ALLOWED_EMAIL_DOMAINS.length === 0) {
    throw new Error('ALLOWED_EMAIL_DOMAINS must be set in production, e.g. "hpe.com" (use "*" to allow any address).');
}

// How many reverse proxies sit in front of the app. Leave unset when the app is reached directly: trusting a
// proxy that is not there would let clients fake their address and dodge the login rate limit.
function parseTrustProxy(value) {
    const v = String(value || "").trim();
    if (!v || v.toLowerCase() === "false") return false;
    return /^\d+$/.test(v) ? Number(v) : v;
}

module.exports = {
    NODE_ENV,
    isProd,
    HOST: process.env.HOST || "127.0.0.1",
    PORT: Number(process.env.PORT) || 5000,
    TRUST_PROXY: parseTrustProxy(process.env.TRUST_PROXY),
    ALLOWED_EMAIL_DOMAINS,
    JWT_SECRET,
    SESSION_COOKIE: "sl_session",
    SESSION_MAX_AGE_MS: 24 * 60 * 60 * 1000,
    OTP_ENABLED: String(process.env.OTP_ENABLED ?? "true").trim().toLowerCase() !== "false",
    OTP_TTL_MINUTES: 10,
    OTP_MAX_ATTEMPTS: 5,
    FRONTEND_ORIGINS: String(process.env.FRONTEND_ORIGIN || "")
        .split(",")
        .map((o) => o.trim())
        .filter(Boolean),
    FRONTEND_DIR: path.join(__dirname, "..", "..", "..", "frontend")
};
