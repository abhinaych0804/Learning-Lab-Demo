// Lab IDs that have progress and practice-score tracking. Add a new lab here to include it in manager reports.
const LAB_IDS = ["vme-installation-setup"];

// Display names shown in manager reports, keyed by lab ID.
const LAB_NAMES = {
  "vme-installation-setup": "VME Installation and Setup"
};

module.exports = { LAB_IDS, LAB_NAMES };
