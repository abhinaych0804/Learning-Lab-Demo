const fs = require("fs");

// TLS settings for the MySQL connection, shared by the app and the migration script.
// Managed MySQL (for example Azure Database for MySQL) rejects unencrypted connections by default.
// DB_SSL_CA is an optional path to a PEM file, for servers whose certificate authority Node does not already trust.
function dbSsl() {
    if (String(process.env.DB_SSL || "").trim().toLowerCase() !== "true") return undefined;
    const ssl = { rejectUnauthorized: true };
    const caPath = String(process.env.DB_SSL_CA || "").trim();
    if (caPath) ssl.ca = fs.readFileSync(caPath);
    return ssl;
}

module.exports = { dbSsl };
