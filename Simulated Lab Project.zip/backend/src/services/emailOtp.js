const sendGridMail = require("@sendgrid/mail");
const { createHash, createHmac, randomInt } = require("crypto");

const config = require("../config");

const PURPOSE_LABELS = {
    register: "Account Registration",
    login: "Login Verification"
};

function generateOtp() {
    return String(randomInt(100000, 1000000));
}

// Azure Communication Services Email is called over its REST API so no extra package is needed.
function parseAzureConnection(value) {
    const parts = {};
    String(value || "").split(";").forEach((segment) => {
        const i = segment.indexOf("=");
        if (i > 0) parts[segment.slice(0, i).trim().toLowerCase()] = segment.slice(i + 1).trim();
    });
    if (!parts.endpoint || !parts.accesskey) return null;
    return { endpoint: parts.endpoint.replace(/\/+$/, ""), accessKey: parts.accesskey };
}

async function sendWithAzure({ connection, from, to, subject, text, html }) {
    const url = new URL("/emails:send?api-version=2023-03-31", connection.endpoint);
    const body = JSON.stringify({
        senderAddress: from,
        content: { subject, plainText: text, html },
        recipients: { to: [{ address: to }] }
    });
    const date = new Date().toUTCString();
    const contentHash = createHash("sha256").update(body).digest("base64");
    const stringToSign = `POST\n${url.pathname}${url.search}\n${date};${url.host};${contentHash}`;
    const signature = createHmac("sha256", Buffer.from(connection.accessKey, "base64")).update(stringToSign).digest("base64");

    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "x-ms-date": date,
            "x-ms-content-sha256": contentHash,
            Authorization: `HMAC-SHA256 SignedHeaders=x-ms-date;host;x-ms-content-sha256&Signature=${signature}`
        },
        body
    });

    if (!response.ok) {
        const detail = await response.text().catch(() => "");
        throw new Error(`Azure email service returned ${response.status}: ${detail.slice(0, 200)}`);
    }
}

async function sendOtpEmail({ toEmail, otp, purpose }) {
    const label = PURPOSE_LABELS[purpose] || "Verification";
    const apiKey = String(process.env.SENDGRID_API_KEY || "").trim();
    const azureConnection = parseAzureConnection(process.env.AZURE_COMMUNICATION_CONNECTION_STRING);
    const fromEmail = String(process.env.OTP_FROM_EMAIL || "").trim();

    if (!fromEmail || (!apiKey && !azureConnection)) {
        if (config.isProd) {
            throw new Error(
                "Email service not configured. Set OTP_FROM_EMAIL and either SENDGRID_API_KEY or AZURE_COMMUNICATION_CONNECTION_STRING."
            );
        }
        console.warn(`[dev] Email not configured. ${label} code for ${toEmail}: ${otp}`);
        return;
    }

    const minutes = config.OTP_TTL_MINUTES;
    const text = [
        `Your Simulated Labs ${label.toLowerCase()} code is ${otp}.`,
        `It is valid for ${minutes} minutes.`,
        "Do not share this code with anyone. If you did not request it, you can ignore this email."
    ].join("\n\n");

    const html = `
<div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;padding:24px;color:#333">
  <h2 style="margin:0 0 16px;color:#01a982">Simulated Labs</h2>
  <p>Use the code below to complete your ${label.toLowerCase()}.</p>
  <p style="font-size:32px;font-weight:bold;letter-spacing:8px;margin:24px 0">${otp}</p>
  <p>This code is valid for ${minutes} minutes.</p>
  <p style="color:#777;font-size:13px">Do not share this code with anyone. If you did not request it, you can ignore this email.</p>
</div>`;

    const subject = `Your Simulated Labs ${label} Code`;

    if (apiKey) {
        sendGridMail.setApiKey(apiKey);
        await sendGridMail.send({ to: toEmail, from: fromEmail, subject, text, html });
        return;
    }

    await sendWithAzure({ connection: azureConnection, from: fromEmail, to: toEmail, subject, text, html });
}

module.exports = { generateOtp, sendOtpEmail };
