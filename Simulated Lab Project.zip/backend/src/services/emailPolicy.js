const config = require("../config");

function emailDomain(email) {
    const text = String(email || "").trim().toLowerCase();
    const at = text.lastIndexOf("@");
    return at < 0 ? "" : text.slice(at + 1);
}

// Exact domain match only: "hpe.com" does not admit "hpe.com.example.net" or "mail.hpe.com".
function isAllowedEmail(email) {
    const allowed = config.ALLOWED_EMAIL_DOMAINS;
    if (allowed.length === 0 || allowed.indexOf("*") >= 0) return true;
    return allowed.indexOf(emailDomain(email)) >= 0;
}

function emailPolicyMessage() {
    const list = config.ALLOWED_EMAIL_DOMAINS.map((d) => "@" + d).join(" or ");
    return `Only ${list} email addresses can be used with this site.`;
}

module.exports = { isAllowedEmail, emailPolicyMessage };
