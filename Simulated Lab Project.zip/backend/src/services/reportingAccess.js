const BLOCKED_MESSAGES = {
    pending: "Your reporting manager has not approved your account yet. You can sign in once they approve it.",
    declined: "Your reporting manager declined your access request. Please contact them."
};

function accessBlockMessage(approvalStatus) {
    return BLOCKED_MESSAGES[approvalStatus] || null;
}

module.exports = { accessBlockMessage };
