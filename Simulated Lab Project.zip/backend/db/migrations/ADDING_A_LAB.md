# Adding a new lab to lab progress tracking

Lab status (not started, in progress, completed) is keyed by a lab ID. The same ID must be used in three places.

## 1. Register the ID in the backend

In [backend/src/routes/labs.js](../../src/routes/labs.js), add the ID to the `LABS` set:

```js
const LABS = new Set(["vme-installation-setup", "your-new-lab-id"]);
```

Requests with an ID that is not in this set are rejected with a 400 error.

## 2. Add the lab card

In [frontend/VME/index.html](../../../frontend/VME/index.html), add `data-lab` to the lab's card:

```html
<a class="vme-card" href="YourNewLab.html" data-lab="your-new-lab-id">
```

The status badge and button text are added to any card that has this attribute.

## 3. Add the progress script to the lab page

In the lab page (for example `frontend/VME/YourNewLab.html`), load `vme-progress.js` before the lab's own script:

```html
<script src="../Scripts/vme-progress.js" data-lab="your-new-lab-id" data-complete-event="your-final-event"></script>
```

- `data-lab` must match the ID from steps 1 and 2.
- `data-complete-event` is the simulator event that marks the lab complete in Practice Mode. Guided Mode completes the lab when its last step is done.

## Notes

- Guided Mode needs a step script like [frontend/Scripts/vme-guide.js](../../../frontend/Scripts/vme-guide.js). It sends the `vme:lab-complete` event when the last step is done.
- Lab IDs are stored in the database, so do not rename an ID after it has been used.
