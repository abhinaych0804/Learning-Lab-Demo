-- One row per finished Practice Mode attempt, so a learner can review past scores.
CREATE TABLE IF NOT EXISTS lab_scores (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    lab_id VARCHAR(64) NOT NULL,
    total TINYINT UNSIGNED NOT NULL,
    grade VARCHAR(32) NOT NULL,
    elapsed_ms INT UNSIGNED NOT NULL,
    fault VARCHAR(64) NOT NULL,
    details JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_lab_scores_user_lab (user_id, lab_id, created_at),
    CONSTRAINT fk_lab_scores_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);
