-- No row for a user/lab pair means the lab has not been started.
CREATE TABLE IF NOT EXISTS lab_progress (
    user_id INT NOT NULL,
    lab_id VARCHAR(64) NOT NULL,
    status ENUM('in_progress','completed') NOT NULL,
    started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, lab_id),
    CONSTRAINT fk_lab_progress_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);
