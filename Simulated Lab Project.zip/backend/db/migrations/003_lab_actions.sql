-- The learner's recorded actions in a lab, replayed when they continue from saved progress.
CREATE TABLE IF NOT EXISTS lab_actions (
    user_id INT NOT NULL,
    lab_id VARCHAR(64) NOT NULL,
    actions JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, lab_id),
    CONSTRAINT fk_lab_actions_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);
