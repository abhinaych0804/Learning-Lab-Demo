-- Managers are a role of their own. Re-running this statement with the same enum is a no-op.
ALTER TABLE users MODIFY COLUMN role ENUM('learner', 'author', 'admin', 'manager') NOT NULL DEFAULT 'learner';

-- Links a learner to the manager they named at sign-up. Learners only appear on the manager's panel once approved.
CREATE TABLE IF NOT EXISTS reporting_lines (
    user_id INT NOT NULL,
    manager_id INT NOT NULL,
    status ENUM('pending', 'approved', 'declined') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    decided_at TIMESTAMP NULL,
    PRIMARY KEY (user_id),
    KEY idx_reporting_lines_manager (manager_id, status),
    CONSTRAINT fk_reporting_lines_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_reporting_lines_manager FOREIGN KEY (manager_id) REFERENCES users (id) ON DELETE CASCADE
);
