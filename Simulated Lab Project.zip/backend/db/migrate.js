require("dotenv").config({ path: require("path").join(__dirname, "..", ".env") });
const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");

const { dbSsl } = require("../src/config/dbOptions");

async function run() {
    const dbName = process.env.DB_NAME || "simulated_labs";
    if (!/^[A-Za-z0-9_]+$/.test(dbName)) {
        throw new Error("DB_NAME may only contain letters, digits and underscores");
    }

    // The tables need DDL rights the running app does not. MIGRATE_DB_USER / MIGRATE_DB_PASSWORD let the
    // migration use a more privileged account while the app itself runs with a read/write-only one.
    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        port: Number(process.env.DB_PORT) || 3306,
        user: process.env.MIGRATE_DB_USER || process.env.DB_USER,
        password: process.env.MIGRATE_DB_USER ? process.env.MIGRATE_DB_PASSWORD : process.env.DB_PASSWORD,
        ssl: dbSsl(),
        multipleStatements: true
    });

    try {
        // On a managed server the database usually exists already, and the account may not be allowed to create one.
        const [existing] = await connection.query("SELECT 1 FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?", [dbName]);
        if (existing.length === 0) {
            await connection.query(
                `CREATE DATABASE \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
            );
        }
        await connection.query(`USE \`${dbName}\``);

        const dir = path.join(__dirname, "migrations");
        const files = fs.readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();

        for (const file of files) {
            await connection.query(fs.readFileSync(path.join(dir, file), "utf8"));
            console.log(`Applied ${file}`);
        }
    } finally {
        await connection.end();
    }
}

run().catch((err) => {
    console.error("Migration failed:", err.message);
    process.exit(1);
});
