(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const desktop = $("vmeDesktop");
  const win = $("vmeChrome");
  const taskbarBtn = $("vmeChromeBtn");
  if (!desktop || !win || !taskbarBtn) return;

  const explorerWin = $("vmeExplorer");
  const mobaWin = $("vmeMoba");
  const strip = $("crStrip");
  const tabsEl = $("crTabs");
  const view = $("crView");
  const layer = $("crLayer");
  const bookmarksEl = $("crBookmarks");
  const omni = $("crOmni");
  const urlInput = $("crUrl");
  const pill = $("crPill");
  const scheme = $("crScheme");
  const info = $("crInfo");
  const star = $("crStar");
  const backBtn = $("crBack");
  const fwdBtn = $("crForward");
  const reloadBtn = $("crReload");
  let launching = false;

  // Chrome shows the destination of a hovered link in the bottom-left corner.
  const statusBubble = document.createElement("div");
  statusBubble.className = "cr-status";
  statusBubble.hidden = true;
  win.appendChild(statusBubble);
  const toast = (message) => window.VmeDesktop && window.VmeDesktop.toast(message);
  const notAvailable = (name) => toast(name + " is not available yet.");
  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // ── Simulated lab network ───────────────────────────────────────
  // hpe-vm1 is the Morpheus appliance on first boot (self-signed certificate, setup wizard).
  // hpe-vm is the configured appliance (login and dashboard) and only answers once setup is complete.
  const HOST_VM = "hpe-vm.talabs.local";
  const HOST_VM1 = "hpe-vm1.talabs.local";
  const URL_VM = "https://" + HOST_VM;
  const URL_VM1 = "https://" + HOST_VM1;
  const URL_VCENTER = "https://vcenter-01.talabs.local";
  const LOGO_URL = "../HPE_Logo/HPE_logo_full-clr_pos_rgb.svg";
  const LOGO_REV_URL = "../HPE_Logo/HPE_logo_full-clr_rev_rgb.svg";
  const BOOT_MS = 5000;

  // Appliance state survives closing Chrome; the certificate exception does not.
  const server = { setupDone: false, booted: false, loggedIn: false, user: null, settings: null, groups: [], clouds: [], seq: { group: 1, cloud: 0 } };
  const track = (name, detail) => document.dispatchEvent(new CustomEvent("vme:track", { detail: Object.assign({ name: name }, detail) }));
  const report = (visited) => track("setup-state", { snapshot: Object.assign({}, server, { visited: visited || "" }) });
  const infrastructure = window.VmeInfrastructure({
    server: server, esc: esc, shell: morpheusShell, modal: openModal, modalOpen: () => !layer.hidden, close: closeLayer, save: saveServer, toast: toast,
    refresh: (tab) => { tab.view = null; show(tab); report(); },
    navigate: (tab, path) => load(tab, URL_VM + path, "push"),
    managerPassword: () => (document.getElementById("vmeManagerPassword") || {}).value
  });
  server.infrastructure = infrastructure.fresh();

  // Ids only ever go up, so a deleted group or cloud never gets its address reused.
  function nextId(kind) {
    const list = kind === "group" ? server.groups : server.clouds;
    server.seq[kind] = Math.max(server.seq[kind], list.reduce((n, x) => Math.max(n, x.id), 0)) + 1;
    return server.seq[kind];
  }
  const session = { certAccepted: false, tempFavicon: false, setupRequested: false };

  // Each Settings tab is its own page in the console, with its own address and tab title.
  const SETTINGS_PAGES = {
    appliance: { tab: "Appliance", title: "Appliance Settings | HPE Morpheus" },
    provisioning: { tab: "Provisioning", title: "Provisioning Settings | HPE Morpheus" },
    backups: { tab: "Backups", title: "Backup Settings | HPE Morpheus" },
    environments: { tab: "Environments", title: "Provisioning Settings: Environments | HPE Morpheus" },
    utilities: { tab: "Utilities", title: "Utilities | HPE Morpheus" },
    support: { tab: "Support", title: "Support Settings | HPE Morpheus" },
    license: { tab: "License", title: "License Settings | HPE Morpheus" },
    "morpheus-central": { tab: "Morpheus Central", title: "Morpheus Central | HPE Morpheus", heading: "Morpheus Central" }
  };
  const hasOwn = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);

  // The configured appliance (tenant, master user, settings) is remembered in this browser so setup
  // only has to be done once. The password is stored as a hash, never in plain text.
  const STORE_KEY = "vme.morpheus.v1";

  function hashPassword(username, password) {
    const text = "vme-lab:" + username.toLowerCase() + ":" + password;
    if (window.crypto && window.crypto.subtle) {
      return window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)).then((buf) =>
        Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("")
      );
    }
    // Non-secure contexts have no SubtleCrypto; a simple hash is enough for a simulated lab.
    let h = 5381;
    for (let i = 0; i < text.length; i++) h = ((h * 33) ^ text.charCodeAt(i)) >>> 0;
    return Promise.resolve("x" + h.toString(16));
  }

  function saveServer() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ user: server.user, settings: server.settings, groups: server.groups, clouds: server.clouds, seq: server.seq, infrastructure: server.infrastructure }));
    } catch (e) {
      // Storage unavailable (private mode or full); the lab still works for this page load.
      toast("Appliance changes could not be saved in this browser. Keep this page open.");
    }
    report();
  }

  function loadServer() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORE_KEY));
      if (saved && saved.user && saved.user.hash) {
        server.setupDone = true;
        server.user = saved.user;
        server.settings = saved.settings || null;
        server.groups = Array.isArray(saved.groups) ? saved.groups : [];
        server.clouds = Array.isArray(saved.clouds) ? saved.clouds : [];
        if (saved.infrastructure && saved.infrastructure.vm && Array.isArray(saved.infrastructure.shares)) server.infrastructure = saved.infrastructure;
        if (saved.seq && typeof saved.seq.group === "number" && typeof saved.seq.cloud === "number") server.seq = saved.seq;
      }
    } catch (e) {
      localStorage.removeItem(STORE_KEY);
    }
  }

  loadServer();
  infrastructure.resume();
  document.addEventListener("vme:setup-request", () => { infrastructure.settle(); report(); });
  document.addEventListener("vme:setup-reset", () => {
    server.user = null;
    server.setupDone = server.booted = server.loggedIn = false;
    server.settings = null;
    server.groups = [];
    server.clouds = [];
    server.infrastructure = infrastructure.fresh();
    window.SimLabsSetup.resetReviews();
    saveServer();
  });

  // ── Icons ───────────────────────────────────────────────────────
  const i24 = (body) => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' + body + "</svg>";
  const ICON = {
    back: i24('<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z"/>'),
    forward: i24('<path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/>'),
    reload: i24('<path d="M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4z"/>'),
    close: i24('<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>'),
    home: i24('<path d="M4 11l8-7 8 7v9h-5v-6H9v6H4z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>'),
    tune: i24('<path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"/>'),
    starOff: i24('<path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z"/>'),
    starOn: i24('<path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>'),
    profile: i24('<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0 14.2a7.2 7.2 0 0 1-6-3.22c.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08a7.2 7.2 0 0 1-6 3.22z"/>'),
    kebab: i24('<circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/>'),
    apps: i24('<path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/>'),
    google:
      '<svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>',
    mic: i24('<path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11z"/>'),
    lens: i24('<path d="M4 8V6a2 2 0 0 1 2-2h2v2H6v2zm12-4h2a2 2 0 0 1 2 2v2h-2V6h-2zM4 16h2v2h2v2H6a2 2 0 0 1-2-2zm14 2v-2h2v2a2 2 0 0 1-2 2h-2v-2zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"/>'),
    plus: i24('<path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"/>'),
    building: i24('<path d="M12 7V3H2v18h20V7zM6 19H4v-2h2zm0-4H4v-2h2zm0-4H4V9h2zm0-4H4V5h2zm4 12H8v-2h2zm0-4H8v-2h2zm0-4H8V9h2zm0-4H8V5h2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8zm-2-8h-2v2h2zm0 4h-2v2h2z"/>'),
    pencil: i24('<path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z"/>'),
    bulb: i24('<path d="M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9zm3-19a7 7 0 0 0-4 12.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26A7 7 0 0 0 12 2z" fill="none" stroke="currentColor" stroke-width="1.6"/>'),
    check: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M7.5 12.5l3 3 6-6.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    chevron: i24('<path d="M7 10l5 5 5-5z"/>')
  };

  const FAV = {
    hpe: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.500" y="4.500" width="13" height="7" fill="none" stroke="#01a982" stroke-width="2"/></svg>',
    globe:
      '<svg viewBox="0 0 16 16" aria-hidden="true" fill="none" stroke="#5f6368" stroke-width="1.300"><circle cx="8" cy="8" r="6.500"/><ellipse cx="8" cy="8" rx="2.800" ry="6.500"/><path d="M1.500 8h13"/></svg>',
    vcenter:
      '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.500" y="4" width="9" height="9" rx="1.500" fill="#cfe9f7" stroke="#1d8fd1" stroke-width="1.300"/><rect x="5.500" y="1.500" width="9" height="9" rx="1.500" fill="#e8f5fc" stroke="#1d8fd1" stroke-width="1.300"/></svg>',
    chrome: '<img src="../Images/ChromeIcon.webp" alt="">',
    webstore:
      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 15a9 9 0 0 1 18 0z" fill="#fbbc04"/><path d="M12 6a9 9 0 0 1 8.5 6H15a3 3 0 0 0-3-3z" fill="#ea4335"/><path d="M3.500 12A9 9 0 0 1 12 6v3a3 3 0 0 0-2.500 1.400z" fill="#4285f4"/><circle cx="12" cy="15" r="3" fill="#fff"/></svg>'
  };

  const BOOKMARKS = [
    { label: "HPE VM Essentials", href: URL_VM, icon: () => FAV.hpe },
    { label: "HPE VM Temp", href: URL_VM1, icon: () => (session.tempFavicon ? FAV.hpe : FAV.globe) },
    { label: "vCenter-01", href: URL_VCENTER, icon: () => FAV.vcenter }
  ];

  // ── Routing ─────────────────────────────────────────────────────
  function parseInput(raw) {
    const text = raw.trim();
    if (!text) return null;
    let candidate = text;
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(candidate)) {
      if (/\s/.test(candidate) || !/[./]/.test(candidate)) return { search: text };
      candidate = "https://" + candidate;
    }
    try {
      const u = new URL(candidate);
      if (!/^https?:$/.test(u.protocol)) return { search: text };
      const path = u.pathname === "/" ? "" : u.pathname.replace(/\/+$/, "");
      return { href: "https://" + u.hostname.toLowerCase() + path + u.search };
    } catch (e) {
      return { search: text };
    }
  }

  function route(href) {
    if (!href) return { kind: "newtab", title: "New Tab", fav: "chrome" };
    const u = new URL(href);
    const host = u.hostname;
    const path = u.pathname === "/" ? "" : u.pathname.replace(/\/+$/, "");

    if (host === HOST_VM1) {
      if (!session.certAccepted) return { kind: "cert", title: "Privacy error", fav: null, insecure: true, host: host };
      // The login page's "Set up a new lab" link reopens the wizard even though an appliance already exists.
      if (server.setupDone && !session.setupRequested) return { redirect: URL_VM + "/login/auth" };
      if (path === "/setup/appliance") {
        return { kind: "setup", title: "Setup | HPE Morpheus", fav: "hpe", insecure: true };
      }
      if (!server.booted) return { kind: "loading", title: "Morpheus Loading", fav: "globe", insecure: true };
      return { redirect: URL_VM1 + "/setup/appliance" };
    }

    if (host === HOST_VM) {
      // A new lab has no credentials yet, so every address leads to the setup wizard.
      if (!server.setupDone) {
        session.certAccepted = true;
        server.booted = true;
        return { redirect: URL_VM1 + "/setup/appliance" };
      }
      if (path === "/operations/dashboard") {
        return server.loggedIn
          ? { kind: "dashboard", title: "Dashboard | HPE Morpheus", fav: "hpe" }
          : { redirect: URL_VM + "/login/auth" };
      }
      if (path === "/admin" || path === "/admin/settings" || path.indexOf("/admin/settings/") === 0) {
        if (!server.loggedIn) return { redirect: URL_VM + "/login/auth" };
        const slug = path.split("/")[3];
        return hasOwn(SETTINGS_PAGES, slug)
          ? { kind: "settings", which: slug, title: SETTINGS_PAGES[slug].title, fav: "hpe" }
          : { redirect: URL_VM + "/admin/settings/appliance" };
      }
      if (path === "/infrastructure" || path.indexOf("/infrastructure/") === 0) {
        if (!server.loggedIn) return { redirect: URL_VM + "/login/auth" };
        const infra = /^\/infrastructure\/(clusters|compute|storage)(?:\/(1))?$/.exec(path);
        if (infra) return { kind: "infrastructure", section: infra[1], clusterDetail: infra[1] === "clusters" && !!infra[2], vmDetail: infra[1] === "compute" && !!infra[2], title: "Infrastructure | HPE Morpheus", fav: "hpe" };
        const one = /^\/infrastructure\/groups\/(\d+)$/.exec(path);
        if (one) {
          return server.groups.some((g) => String(g.id) === one[1])
            ? { kind: "group", groupId: Number(one[1]), title: "Group | HPE Morpheus", fav: "hpe" }
            : { redirect: URL_VM + "/infrastructure/groups" };
        }
        const cloud = /^\/infrastructure\/clouds\/(\d+)$/.exec(path);
        if (cloud) {
          return server.clouds.some((c) => String(c.id) === cloud[1])
            ? { kind: "cloud", cloudId: Number(cloud[1]), title: "Cloud | HPE Morpheus", fav: "hpe" }
            : { redirect: URL_VM + "/infrastructure/clouds" };
        }
        if (path === "/infrastructure/clouds" || path.indexOf("/infrastructure/clouds/") === 0) {
          return path === "/infrastructure/clouds"
            ? { kind: "clouds", title: "Clouds | HPE Morpheus", fav: "hpe" }
            : { redirect: URL_VM + "/infrastructure/clouds" };
        }
        const infraStatic = Object.keys(INFRA_PAGES).filter((k) => INFRA_PAGES[k].path === path)[0];
        if (infraStatic) return { kind: "infra", which: infraStatic, title: INFRA_PAGES[infraStatic].title, fav: "hpe" };
        // Anything else under Infrastructure lands on Groups.
        return path === "/infrastructure/groups"
          ? { kind: "groups", title: "Groups | HPE Morpheus", fav: "hpe" }
          : { redirect: URL_VM + "/infrastructure/groups" };
      }
      if (server.loggedIn) return { redirect: URL_VM + "/operations/dashboard" };
      if (path !== "/login/auth") return { redirect: URL_VM + "/login/auth" };
      return { kind: "login", title: "Login | HPE Morpheus", fav: "hpe" };
    }

    const code = /\.talabs\.local$/.test(host) ? "DNS_PROBE_FINISHED_NXDOMAIN" : "ERR_INTERNET_DISCONNECTED";
    return { kind: "neterr", code: code, host: host, title: host };
  }

  // ── Tabs and navigation ─────────────────────────────────────────
  let nextTabId = 1;
  let tabs = [];
  let active = null;

  function createTab() {
    return { id: nextTabId++, hist: [""], i: 0, page: route(""), view: null, scroll: 0, loading: false, token: 0, timer: null };
  }

  function load(tab, href, mode, quick) {
    const token = ++tab.token;
    clearTimeout(tab.timer);
    tab.loading = true;
    renderTabs();
    updateToolbar();
    setTimeout(
      () => {
        if (token !== tab.token || tabs.indexOf(tab) < 0) return;
        let target = href;
        let page = route(target);
        let hops = 0;
        while (page.redirect && hops++ < 5) {
          target = page.redirect;
          page = route(target);
        }
        commit(tab, target, page, mode);
      },
      quick ? 80 : 250 + Math.random() * 350
    );
  }

  function commit(tab, href, page, mode) {
    if (mode === "push" && href !== tab.hist[tab.i]) {
      tab.hist.length = tab.i + 1;
      tab.hist.push(href);
      tab.i++;
    } else {
      tab.hist[tab.i] = href;
    }
    tab.page = page;
    if (page.kind !== "setup") session.setupRequested = false;
    tab.loading = false;
    tab.view = null;
    tab.scroll = 0;

    if (page.kind === "loading") {
      tab.timer = setTimeout(() => {
        if (tab.page !== page || tabs.indexOf(tab) < 0) return;
        server.booted = true;
        load(tab, URL_VM1 + "/setup/appliance", "replace", true);
      }, BOOT_MS);
    } else if (page.kind === "setup") {
      server.booted = true;
      session.tempFavicon = true;
      renderBookmarks();
    }

    renderTabs();
    if (tab === active) show(tab);
    report(page.kind === "settings" ? page.which : "");
  }

  function submit(tab, raw) {
    const parsed = parseInput(raw);
    if (!parsed) return;
    const href = parsed.search
      ? "https://www.google.com/search?q=" + encodeURIComponent(parsed.search)
      : parsed.href;
    load(tab, href, "push");
  }

  function navigateBack(tab) {
    if (tab.i <= 0) return;
    tab.i--;
    load(tab, tab.hist[tab.i], "traverse");
  }

  function navigateForward(tab) {
    if (tab.i >= tab.hist.length - 1) return;
    tab.i++;
    load(tab, tab.hist[tab.i], "traverse");
  }

  // Dialogs sit above the page and dim it; closing the layer discards whatever dialog is open.
  function closeLayer() {
    layer.hidden = true;
    layer.replaceChildren();
  }

  function openModal(html) {
    layer.innerHTML = html;
    layer.hidden = false;
    layer.scrollTop = 0;
    const box = layer.firstElementChild;
    const x = box.querySelector(".md__x");
    if (x) x.addEventListener("click", closeLayer);
    return box;
  }

  layer.addEventListener("mousedown", (event) => {
    if (event.target === layer) closeLayer();
  });
  win.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !layer.hidden) closeLayer();
  });

  function show(tab) {
    closeLayer();
    statusBubble.hidden = true;
    if (active) active.scroll = view.scrollTop;
    active = tab;
    if (!tab.view) tab.view = (BUILDERS[tab.page.kind] || buildNewTab)(tab);
    view.replaceChildren(tab.view);
    view.scrollTop = tab.scroll || 0;
    renderTabs();
    updateToolbar();
    const focus = tab.view.querySelector("[data-autofocus]");
    if (focus) focus.focus({ preventScroll: true });
  }

  function addTab() {
    const tab = createTab();
    tabs.push(tab);
    show(tab);
    urlInput.focus();
  }

  function closeTab(tab) {
    const idx = tabs.indexOf(tab);
    if (idx < 0) return;
    tab.token++;
    clearTimeout(tab.timer);
    tabs.splice(idx, 1);
    if (!tabs.length) {
      closeWindow();
      return;
    }
    if (tab === active) show(tabs[Math.min(idx, tabs.length - 1)]);
    else renderTabs();
  }

  // ── Browser chrome rendering ────────────────────────────────────
  function favHtml(tab) {
    if (tab.loading) return '<span class="cr-spin"></span>';
    return tab.page.fav ? FAV[tab.page.fav] : "";
  }

  function renderTabs() {
    tabsEl.innerHTML = "";
    tabs.forEach((tab) => {
      const el = document.createElement("div");
      el.className = "cr-tab" + (tab === active ? " is-active" : "");
      el.setAttribute("role", "tab");
      el.setAttribute("aria-selected", String(tab === active));
      el.innerHTML =
        '<span class="cr-tab__fav">' + favHtml(tab) + "</span>" +
        '<span class="cr-tab__title">' + esc(tab.page.title || "") + "</span>" +
        '<button type="button" class="cr-tab__close" aria-label="Close tab">' + ICON.close + "</button>";
      el.addEventListener("pointerdown", (event) => {
        if (event.target.closest(".cr-tab__close")) return;
        if (tab !== active) show(tab);
      });
      el.querySelector(".cr-tab__close").addEventListener("click", (event) => {
        event.stopPropagation();
        closeTab(tab);
      });
      tabsEl.appendChild(el);
    });
  }

  function renderBookmarks() {
    bookmarksEl.innerHTML = "";
    const apps = document.createElement("button");
    apps.type = "button";
    apps.className = "cr-bm cr-bm--apps";
    apps.setAttribute("aria-label", "Apps");
    apps.innerHTML = ICON.apps;
    apps.addEventListener("click", () => notAvailable("Apps"));
    bookmarksEl.appendChild(apps);
    const sep = document.createElement("i");
    sep.className = "cr-bm__sep";
    bookmarksEl.appendChild(sep);
    BOOKMARKS.forEach((b) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cr-bm";
      btn.innerHTML = '<span class="cr-bm__ico">' + b.icon() + "</span><span>" + esc(b.label) + "</span>";
      btn.addEventListener("click", () => active && load(active, b.href, "push"));
      bookmarksEl.appendChild(btn);
    });
  }

  function renderOmni() {
    const tab = active;
    const href = tab.hist[tab.i];
    const editing = omni.classList.contains("is-editing");
    const insecure = !!tab.page.insecure;
    const hideInsecure = !insecure || editing;

    pill.hidden = hideInsecure;
    scheme.hidden = hideInsecure;
    info.hidden = !hideInsecure;
    omni.classList.toggle("is-insecure", !hideInsecure);
    info.innerHTML = tab.page.kind === "newtab" && !editing ? ICON.google : ICON.tune;
    info.classList.toggle("is-google", tab.page.kind === "newtab" && !editing);

    star.innerHTML = BOOKMARKS.some((b) => b.href === href) ? ICON.starOn : ICON.starOff;
    star.classList.toggle("is-on", BOOKMARKS.some((b) => b.href === href));

    if (editing) return;
    urlInput.placeholder = href ? "" : "Ask Google or type a URL";
    if (!href) urlInput.value = "";
    else if (insecure) urlInput.value = href.replace(/^https/, "");
    else urlInput.value = href.replace(/^https:\/\//, "");
  }

  function updateToolbar() {
    const tab = active;
    if (!tab) return;
    backBtn.disabled = tab.i <= 0;
    fwdBtn.disabled = tab.i >= tab.hist.length - 1;
    reloadBtn.innerHTML = tab.loading ? ICON.close : ICON.reload;
    reloadBtn.setAttribute("aria-label", tab.loading ? "Stop loading" : "Reload");
    renderOmni();
  }

  win.querySelectorAll("[data-icon]").forEach((el) => {
    el.innerHTML = ICON[el.dataset.icon];
  });

  backBtn.addEventListener("click", () => navigateBack(active));
  fwdBtn.addEventListener("click", () => navigateForward(active));
  reloadBtn.addEventListener("click", () => {
    if (active.loading) {
      active.token++;
      active.loading = false;
      renderTabs();
      updateToolbar();
    } else {
      load(active, active.hist[active.i], "replace");
    }
  });
  $("crHome").addEventListener("click", () => load(active, "", "push"));
  $("crNewTab").addEventListener("click", addTab);
  $("crTabSearch").addEventListener("click", () => notAvailable("Tab search"));
  $("crProfile").addEventListener("click", () => notAvailable("Profile"));
  $("crMenu").addEventListener("click", () => notAvailable("Chrome menu"));
  info.addEventListener("click", () => notAvailable("Site information"));
  star.addEventListener("click", () => notAvailable("Bookmarks"));

  urlInput.addEventListener("focus", () => {
    omni.classList.add("is-editing");
    urlInput.value = active.hist[active.i];
    renderOmni();
    urlInput.select();
  });
  urlInput.addEventListener("blur", () => {
    omni.classList.remove("is-editing");
    renderOmni();
  });
  urlInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      const raw = urlInput.value;
      urlInput.blur();
      submit(active, raw);
    } else if (event.key === "Escape") {
      event.stopPropagation();
      urlInput.blur();
    }
  });

  // ── Pages ───────────────────────────────────────────────────────
  const logoImg = (rev, cls) => '<img class="' + cls + '" src="' + (rev ? LOGO_REV_URL : LOGO_URL) + '" alt="HPE">';

  function wirePage(el, tab) {
    el.querySelectorAll("[data-na]").forEach((n) => {
      n.addEventListener("click", (event) => {
        event.preventDefault();
        notAvailable(n.dataset.na);
      });
    });
    el.querySelectorAll("[data-go]").forEach((n) => {
      n.addEventListener("click", (event) => {
        event.preventDefault();
        load(tab, n.dataset.go, "push");
      });
    });
    return el;
  }

  function pageEl(cls, html) {
    const el = document.createElement("div");
    el.className = cls;
    el.innerHTML = html;
    return el;
  }

  function buildNewTab(tab) {
    const letters = [["G", "#4285f4"], ["o", "#ea4335"], ["o", "#fbbc05"], ["g", "#4285f4"], ["l", "#34a853"], ["e", "#ea4335"]];
    const tile = (label, icon, attr) =>
      '<button type="button" class="nt-tile" ' + attr + '><span class="nt-tile__ico">' + icon + "</span><span>" + label + "</span></button>";
    const el = pageEl(
      "nt-page",
      '<div class="nt-top"><a href="#" data-na="Gmail">Gmail</a><a href="#" data-na="Images">Images</a>' +
        '<button type="button" class="nt-apps" data-na="Google apps" aria-label="Google apps">' + ICON.apps + "</button></div>" +
        '<div class="nt-main">' +
        '<div class="nt-logo" role="img" aria-label="Google">' +
        letters.map((l) => '<span style="color:' + l[1] + '">' + l[0] + "</span>").join("") + "</div>" +
        '<form class="nt-search">' +
        '<button type="button" class="nt-search__plus" data-na="Add" aria-label="Add">' + ICON.plus + "</button>" +
        '<input type="text" placeholder="Ask Google" aria-label="Ask Google" autocomplete="off" spellcheck="false">' +
        '<button type="button" class="nt-search__ico" data-na="Voice search" aria-label="Voice search">' + ICON.mic + "</button>" +
        '<button type="button" class="nt-search__ico" data-na="Search by image" aria-label="Search by image">' + ICON.lens + "</button>" +
        '<button type="button" class="nt-ai" data-na="AI Mode">AI Mode</button></form>' +
        '<div class="nt-tiles">' +
        tile("Login", FAV.hpe, 'data-go="' + URL_VM + '"') +
        tile("Login", FAV.vcenter, 'data-go="' + URL_VCENTER + '"') +
        tile("vSphere Client", FAV.vcenter, 'data-go="' + URL_VCENTER + '/ui"') +
        tile("Web Store", FAV.webstore, 'data-go="https://chromewebstore.google.com"') +
        tile("Add shortcut", ICON.plus, 'data-na="Add shortcut"') +
        "</div></div>" +
        '<div class="nt-foot"><div class="nt-foot__bar"><span class="nt-foot__ico">' + ICON.building +
        '</span><a href="#" data-na="Organization policy">Managed by your organization</a></div>' +
        '<button type="button" class="nt-edit" data-na="Customize Chrome" aria-label="Customize Chrome">' + ICON.pencil + "</button></div>"
    );
    el.querySelector(".nt-search").addEventListener("submit", (event) => {
      event.preventDefault();
      submit(tab, el.querySelector(".nt-search input").value);
    });
    return wirePage(el, tab);
  }

  function buildCert(tab) {
    const host = tab.page.host;
    const el = pageEl(
      "pe-page",
      '<div class="pe-box">' +
        '<svg class="pe-icon" viewBox="0 0 72 64" aria-hidden="true"><path d="M36 4L68 60H4z" fill="#d93025" stroke="#d93025" stroke-width="6" stroke-linejoin="round"/><path d="M36 24v18" stroke="#fff" stroke-width="6" stroke-linecap="round"/><circle cx="36" cy="51" r="3.200" fill="#fff"/></svg>' +
        "<h1>Your connection is not private</h1>" +
        '<p class="pe-p">Attackers might be trying to steal your information from <b>' + esc(host) +
        '</b> (for example, passwords, messages, or credit cards). <a href="#" data-na="Learn more">Learn more about this warning</a></p>' +
        '<p class="pe-code">NET::ERR_CERT_AUTHORITY_INVALID</p>' +
        '<div class="pe-prot"><span class="pe-prot__ico">' + ICON.bulb + '</span><span><a href="#" data-na="Enhanced protection">Turn on enhanced protection</a> to get Chrome\u2019s highest level of security</span></div>' +
        '<div class="pe-actions"><button type="button" class="pe-btn" data-adv>Advanced</button>' +
        '<button type="button" class="pe-btn pe-btn--primary" data-safe>Back to safety</button></div>' +
        '<div class="pe-adv" hidden><p class="pe-p">This server could not prove that it is <b>' + esc(host) +
        "</b>; its security certificate is not trusted by your computer\u2019s operating system. This may be caused by a misconfiguration or an attacker intercepting your connection.</p>" +
        '<p class="pe-p"><a href="#" data-proceed>Proceed to ' + esc(host) + " (unsafe)</a></p></div></div>"
    );
    const adv = el.querySelector(".pe-adv");
    const advBtn = el.querySelector("[data-adv]");
    advBtn.addEventListener("click", () => {
      adv.hidden = !adv.hidden;
      advBtn.textContent = adv.hidden ? "Advanced" : "Hide advanced";
      if (!adv.hidden) adv.scrollIntoView({ block: "nearest" });
    });
    el.querySelector("[data-safe]").addEventListener("click", () => {
      if (tab.i > 0) navigateBack(tab);
      else load(tab, "", "replace");
    });
    el.querySelector("[data-proceed]").addEventListener("click", (event) => {
      event.preventDefault();
      session.certAccepted = true;
      load(tab, tab.hist[tab.i], "replace");
    });
    return wirePage(el, tab);
  }

  function buildLoading() {
    return pageEl(
      "ld-page",
      '<div class="ld-card">' + logoImg(true, "ld-logo") +
        "<h1>Morpheus is Loading...</h1><p>please wait</p>" +
        '<div class="ld-spin" role="progressbar" aria-label="Loading"></div>' +
        '<small>This page refreshes automatically</small></div>'
    );
  }

  function buildNetErr(tab) {
    const code = tab.page.code;
    const host = esc(tab.page.host);
    let title = "This site can\u2019t be reached";
    let body = "<b>" + host + "</b>\u2019s server IP address could not be found.";
    let tips = ["Checking the connection", "Checking the proxy and the firewall", "Running Windows Network Diagnostics"];
    if (code === "ERR_CONNECTION_REFUSED") {
      body = "<b>" + host + "</b> refused to connect.";
      tips = ["Checking the connection", "Checking the proxy and the firewall"];
    } else if (code === "ERR_INTERNET_DISCONNECTED") {
      title = "No internet";
      body = "Try:";
      tips = ["Checking the network cables, modem, and router", "Reconnecting to Wi-Fi"];
    }
    const el = pageEl(
      "ne-page",
      '<div class="ne-box"><svg class="ne-icon" viewBox="0 0 72 72" aria-hidden="true"><path d="M18 8h26l12 12v44H18z" fill="#f1f3f4" stroke="#9aa0a6" stroke-width="3" stroke-linejoin="round"/><path d="M44 8v12h12" fill="none" stroke="#9aa0a6" stroke-width="3"/><circle cx="30" cy="38" r="2.500" fill="#9aa0a6"/><circle cx="44" cy="38" r="2.500" fill="#9aa0a6"/><path d="M29 52c3-4 12-4 15 0" fill="none" stroke="#9aa0a6" stroke-width="3" stroke-linecap="round"/></svg>' +
        "<h1>" + title + "</h1><p>" + body + "</p>" +
        (code === "ERR_INTERNET_DISCONNECTED" ? "" : "<p>Try:</p>") +
        "<ul>" + tips.map((t) => "<li>" + t + "</li>").join("") + "</ul>" +
        '<p class="ne-code">' + code + '</p><button type="button" class="pe-btn pe-btn--primary" data-reload>Reload</button></div>'
    );
    el.querySelector("[data-reload]").addEventListener("click", () => load(tab, tab.hist[tab.i], "replace"));
    return el;
  }

  function buildSetup(tab) {
    const steps = [
      { title: "Create Master Tenant", fields: [{ key: "tenant", label: "Name", ph: "Account Name" }] },
      {
        title: "Create Master User",
        fields: [
          { key: "first", label: "First Name", ph: "First Name" },
          { key: "last", label: "Last Name", ph: "Last Name" },
          { key: "username", label: "Username", ph: "Username" },
          { key: "email", label: "Email", ph: "Email" },
          { key: "password", label: "Password", ph: "Password", type: "password" },
          { key: "confirm", label: "Confirm Password", ph: "Confirm Password", type: "password" }
        ]
      },
      {
        title: "Initial Setup",
        fields: [
          { key: "appName", label: "Appliance Name", ph: "Appliance Name", value: "morpheus" },
          { key: "appUrl", label: "Appliance URL", ph: "Appliance URL", value: URL_VM1 },
          { key: "enableBackups", label: "Enable Backups", type: "checkbox", optional: true },
          { key: "enableMonitoring", label: "Enable Monitoring", type: "checkbox", checked: true, optional: true },
          { key: "enableLogs", label: "Enable Logs", type: "checkbox", checked: true, optional: true }
        ]
      },
      { title: "License", fields: [{ key: "license", label: "License Key", ph: "License Key (optional)", optional: true }] }
    ];
    const data = {};
    let step = 0;
    let completing = false;

    const el = pageEl(
      "mp-page",
      '<div class="mp-card">' + logoImg(false, "mp-logo") + '<div class="mp-form" data-form></div></div>' +
        '<p class="mp-terms">By clicking you agree to our <a href="#" data-na="Terms &amp; Conditions">Terms &amp; Conditions</a> and <a href="#" data-na="Privacy Policy">Privacy Policy</a></p>'
    );
    const form = el.querySelector("[data-form]");

    function validate(s) {
      const v = (k) => (data[k] || "").trim();
      for (const f of s.fields) {
        if (!f.optional && !v(f.key)) return f.label + " is required.";
      }
      if (s.title === "Create Master User") {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v("email"))) return "Enter a valid email address.";
        if (data.password.length < 8) return "Password must be at least 8 characters.";
        if (data.password !== data.confirm) return "Passwords do not match.";
      }
      if (s.title === "Initial Setup" && !/^https?:\/\/\S+$/i.test(v("appUrl"))) {
        return "Appliance URL must start with http:// or https://.";
      }
      return "";
    }

    function render() {
      form.innerHTML =
        steps
          .map((s, i) => {
            const state = i < step ? "done" : i === step ? "active" : "todo";
            let body = "";
            if (state === "active") {
              body =
                '<div class="mp-step__body">' +
                s.fields
                  .map(
                    (f) =>
                      '<label class="mp-label">' + f.label + '<input class="mp-input" data-key="' + f.key + '" type="' + (f.type || "text") +
                      '" placeholder="' + (f.ph || "") + '" value="' + esc(f.value || "") + '"' + (f.checked ? " checked" : "") + ' autocomplete="off" spellcheck="false"' + (f === s.fields[0] ? " data-autofocus" : "") + '></label>'
                  )
                  .join("") +
                '<p class="mp-err" data-err hidden></p><button type="button" class="mp-btn mp-btn--sm" data-next>Next</button></div>';
            }
            return '<section class="mp-step is-' + state + '"><h3 class="mp-step__head"><span>' + s.title + "</span>" + ICON.check + "</h3>" + body + "</section>";
          })
          .join("") +
        '<button type="button" class="mp-btn mp-btn--block" data-complete' + (step < steps.length || completing ? " disabled" : "") + ">" +
        (completing ? "Completing Setup..." : "Complete Setup") + "</button>";

      const first = form.querySelector(".mp-input");
      if (first && tab === active && !el.hidden) first.focus({ preventScroll: true });
    }

    function next() {
      const s = steps[step];
      form.querySelectorAll(".mp-input").forEach((input) => {
        data[input.dataset.key] = input.type === "checkbox" ? input.checked : input.value;
      });
      const error = validate(s);
      if (error) {
        const err = form.querySelector("[data-err]");
        err.textContent = error;
        err.hidden = false;
        return;
      }
      step++;
      render();
    }

    function complete() {
      completing = true;
      render();
      const username = data.username.trim();
      Promise.all([hashPassword(username, data.password), new Promise((resolve) => setTimeout(resolve, 1500))]).then((res) => {
        server.user = {
          first: data.first.trim(),
          last: data.last.trim(),
          username: username,
          hash: res[0]
        };
        server.setupDone = true;
        server.loggedIn = false;
        server.settings = { applianceName: data.appName.trim(), applianceUrl: data.appUrl.trim(), bkCreate: !!data.enableBackups, monitoring: !!data.enableMonitoring, logs: !!data.enableLogs };
        server.groups = [];
        server.clouds = [];
        server.infrastructure = infrastructure.fresh();
        window.SimLabsSetup.resetReviews();
        server.seq = { group: 1, cloud: 0 };
        saveServer();
        load(tab, URL_VM + "/login/auth", "push");
      });
    }

    form.addEventListener("click", (event) => {
      if (event.target.closest("[data-next]")) next();
      else if (event.target.closest("[data-complete]") && step >= steps.length && !completing) complete();
    });
    form.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && event.target.classList.contains("mp-input")) {
        event.preventDefault();
        next();
      }
    });

    render();
    return wirePage(el, tab);
  }

  function buildLogin(tab) {
    const el = pageEl(
      "mp-page",
      '<form class="mp-card" novalidate>' + logoImg(false, "mp-logo") +
        '<div class="mp-form"><label class="mp-label">Username<input class="mp-input" name="u" type="text" placeholder="Username" autocomplete="off" spellcheck="false" data-autofocus></label>' +
        '<label class="mp-label">Password<input class="mp-input" name="p" type="password" placeholder="Password" autocomplete="off"></label>' +
        '<a class="mp-forgot" href="#" data-na="Forgot password">Forgot password?</a>' +
        '<p class="mp-err" data-err hidden></p>' +
        '<button type="submit" class="mp-btn mp-btn--block">Log In</button></div></form>' +
        '<p class="mp-terms">By clicking Log In you agree to our <a href="#" data-na="Terms &amp; Conditions">Terms &amp; Conditions</a> and <a href="#" data-na="Privacy Policy">Privacy Policy</a></p>' +
        '<div class="mp-reset"><button type="button" class="mp-link" data-reset>Don\u2019t have credentials? Set up a new lab</button></div>'
    );
    const err = el.querySelector("[data-err]");
    // Straight to the setup fields; the existing account is only replaced if the wizard is completed.
    el.querySelector("[data-reset]").addEventListener("click", () => {
      session.certAccepted = true;
      session.setupRequested = true;
      server.booted = true;
      load(tab, URL_VM1 + "/setup/appliance", "push");
    });
    const btn = el.querySelector("button[type=submit]");
    el.querySelector("form").addEventListener("submit", (event) => {
      event.preventDefault();
      const user = el.querySelector("[name=u]").value.trim();
      const pass = el.querySelector("[name=p]").value;
      if (!user || !pass) {
        err.textContent = "Enter your username and password.";
        err.hidden = false;
        return;
      }
      btn.disabled = true;
      hashPassword(user, pass).then((hash) => {
        const ok = server.user && user.toLowerCase() === server.user.username.toLowerCase() && hash === server.user.hash;
        if (!ok) {
          btn.disabled = false;
          err.textContent = "Invalid username or password.";
          err.hidden = false;
          return;
        }
        err.hidden = true;
        btn.textContent = "Logging In...";
        setTimeout(() => {
          server.loggedIn = true;
          load(tab, URL_VM + "/operations/dashboard", "push");
        }, 700);
      });
    });
    return wirePage(el, tab);
  }

  const URL_GROUPS = URL_VM + "/infrastructure/groups";
  const URL_CLOUDS = URL_VM + "/infrastructure/clouds";
  const INFRA_ITEMS = ["Groups", "Clouds", "Clusters", "Compute", "Network", "Storage", "Trust", "Systems"];
  // Clusters, Compute and Storage are built in vme-infrastructure.js; the rest are static placeholder pages.
  const INFRA_PAGES = {
    network: { sub: "Network", path: "/infrastructure/networks", title: "Networks | HPE Morpheus" },
    trust: { sub: "Trust", path: "/infrastructure/trust", title: "Trust | HPE Morpheus" },
    systems: { sub: "Systems", path: "/infrastructure/systems", title: "Systems | HPE Morpheus" }
  };
  const INFRA_URLS = { Groups: URL_GROUPS, Clouds: URL_CLOUDS, Clusters: URL_VM + "/infrastructure/clusters", Compute: URL_VM + "/infrastructure/compute", Storage: URL_VM + "/infrastructure/storage" };
  Object.keys(INFRA_PAGES).forEach((k) => {
    INFRA_URLS[INFRA_PAGES[k].sub] = URL_VM + INFRA_PAGES[k].path;
  });
  const MP_NAV = {
    Operations: URL_VM + "/operations/dashboard",
    Infrastructure: URL_GROUPS,
    Administration: URL_VM + "/admin/settings/appliance"
  };
  const MP_SUB = {
    Operations: [["Dashboard", URL_VM + "/operations/dashboard"], ["Wiki"], ["Activity"]],
    Infrastructure: INFRA_ITEMS.map((l) => (INFRA_URLS[l] ? [l, INFRA_URLS[l]] : [l])),
    Administration: [["Plans"], ["Roles"], ["Users"], ["Integrations"], ["Health"], ["Settings", URL_VM + "/admin/settings/appliance"]]
  };

  // Shared Morpheus frame: the header and navigation stay pinned while the page scrolls.
  function morpheusShell(tab, area, sub, bodyHtml) {
    const u = server.user || { first: "HPE", last: "Admin" };
    const name = (u.first + " " + u.last).trim();
    const initials = ((u.first[0] || "") + (u.last[0] || "")).toUpperCase();
    const nav = ["Operations", "Provisioning", "Library", "Infrastructure", "Backups", "Tools", "Administration"];
    const sv = (body) => '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.300" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + body + "</svg>";
    const subIcons = {
      Plans: sv('<circle cx="10" cy="10" r="8"/><path d="M12.500 7.200c-.4-.8-1.400-1.200-2.500-1.200-1.400 0-2.400.7-2.400 1.800 0 2.300 5 1.200 5 3.600 0 1.100-1.100 1.800-2.600 1.800-1.200 0-2.200-.5-2.600-1.400M10 4.500v11"/>'),
      Roles: sv('<circle cx="7" cy="6.500" r="2.500"/><path d="M2 16c0-3 2.200-4.600 5-4.600s5 1.600 5 4.600"/><path d="M12.500 4.200a2.500 2.500 0 0 1 0 4.600M14.500 11.500c2 .6 3.500 2 3.500 4.500"/>'),
      Users: sv('<circle cx="10" cy="7" r="3"/><path d="M4 17c0-3.500 2.700-5.500 6-5.500s6 2 6 5.500"/><path d="M2 3.500h3M15 3.500h3"/>'),
      Integrations: sv('<circle cx="10" cy="10" r="1.800"/><circle cx="10" cy="3.500" r="1.500"/><circle cx="10" cy="16.500" r="1.500"/><circle cx="3.500" cy="10" r="1.500"/><circle cx="16.500" cy="10" r="1.500"/><path d="M10 5v3.200M10 11.800V15M5 10h3.200M11.800 10H15"/>'),
      Health: sv('<rect x="2" y="3" width="16" height="14" rx="1"/><path d="M3 10h4l1.500-4 3 8 1.500-4H17"/>'),
      Settings: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.140 12.940c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.030-1.580a.49.49 0 0 0 .12-.61l-1.920-3.320a.488.488 0 0 0-.59-.22l-2.390.96c-.5-.38-1.030-.7-1.620-.94l-.36-2.540a.484.484 0 0 0-.48-.41h-3.840c-.24 0-.43.17-.47.41l-.36 2.540c-.59.24-1.130.57-1.620.94l-2.390-.96c-.22-.08-.47 0-.59.22L2.740 8.870c-.12.21-.08.47.12.61l2.030 1.580c-.05.3-.09.63-.09.94s.02.64.07.94l-2.030 1.580a.49.49 0 0 0-.12.61l1.920 3.320c.12.22.37.29.59.22l2.390-.96c.5.38 1.030.7 1.620.94l.36 2.540c.05.24.24.41.48.41h3.840c.24 0 .44-.17.47-.41l.36-2.540c.59-.24 1.130-.56 1.620-.94l2.390.96c.22.08.47 0 .59-.22l1.920-3.320c.12-.22.07-.47-.12-.61l-2.010-1.580zM12 15.600c-1.980 0-3.600-1.620-3.600-3.600s1.620-3.600 3.600-3.600 3.600 1.620 3.600 3.600-1.620 3.600-3.600 3.600z"/></svg>',
      Dashboard: '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="9" width="4" height="9" fill="#01a982"/><rect x="8" y="3" width="4" height="15" fill="#33383f"/><rect x="14" y="7" width="4" height="11" fill="#01a982"/></svg>',
      Wiki: '<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="8" fill="none" stroke="#8a9099" stroke-width="1.300"/><path d="M5 7l2 6 3-5 3 5 2-6" fill="none" stroke="#8a9099" stroke-width="1.200"/></svg>',
      Activity: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4.500 2.500h8l3 3v12h-11z" fill="none" stroke="#8a9099" stroke-width="1.300"/><circle cx="10" cy="11" r="3" fill="none" stroke="#8a9099" stroke-width="1.200"/></svg>'
    };

    const s24 = (body) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.400" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + body + "</svg>";
    const infraIcons = {
      Groups: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.400" stroke-linejoin="round" aria-hidden="true"><path class="ico-f" d="M12 2.500a7 7 0 0 0-7 7c0 5 7 12.500 7 12.500s7-7.500 7-12.500a7 7 0 0 0-7-7z"/><circle class="ico-c" cx="12" cy="9.500" r="2.500"/></svg>',
      Clouds: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.400" stroke-linejoin="round" aria-hidden="true"><path class="ico-f" d="M7 18a4 4 0 0 1-.5-8A5.500 5.500 0 0 1 17 8.500a4.800 4.800 0 0 1 .5 9.500z"/></svg>',
      Clusters: s24('<circle cx="5.500" cy="6" r="2.200"/><circle cx="18.500" cy="6" r="2.200"/><circle cx="12" cy="18" r="2.200"/><path d="M7.500 7.500l3 8.500M16.500 7.500l-3 8.500M8 6h8"/>'),
      Compute: s24('<ellipse cx="12" cy="6" rx="6" ry="2.500"/><path d="M6 6v12c0 1.400 2.700 2.500 6 2.500s6-1.100 6-2.500V6M6 12c0 1.400 2.700 2.500 6 2.500s6-1.100 6-2.500"/>'),
      Network: s24('<circle cx="12" cy="12" r="1.600"/><path d="M8.500 8.500a5 5 0 0 0 0 7M15.500 8.500a5 5 0 0 1 0 7M5.500 5.500a9 9 0 0 0 0 13M18.500 5.500a9 9 0 0 1 0 13"/>'),
      Storage: s24('<rect x="4" y="3.500" width="16" height="17" rx="1.500"/><path d="M4 9h16M4 15h16M8 6.200h.01M8 12h.01M8 18h.01"/>'),
      Trust: s24('<rect x="5.500" y="10.500" width="13" height="10" rx="1.500"/><path d="M8.500 10.500V8a3.500 3.500 0 0 1 7 0v2.500M12 14.500v2.500"/>'),
      Systems: s24('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.500"/>')
    };
    // Hover menus under the main navigation. Only Infrastructure and Administration are captured so far.
    Object.assign(subIcons, infraIcons);
    const navMenus = {
      Infrastructure: INFRA_ITEMS.map((l) => ({
        l: l,
        icon: infraIcons[l],
        go: INFRA_URLS[l] || ""
      })),
      Administration: MP_SUB.Administration.map((s) => ({
        l: s[0],
        icon: subIcons[s[0]],
        go: s[1],
        status: s[0] === "Plans" ? URL_VM + "/admin/service-plans" : ""
      }))
    };
    const dropHtml = (menu) =>
      '<div class="dash-drop" role="menu">' +
      menu.map((i) =>
        '<button type="button" role="menuitem" class="' + (i.l === "Settings" ? "is-green" : "") + '"' +
        (i.go ? ' data-go="' + i.go + '"' : ' data-na="' + i.l + '"') + (i.status ? ' data-status="' + i.status + '"' : "") + ">" + i.icon + i.l + "</button>"
      ).join("") + "</div>";

    const el = pageEl(
      "dash",
      '<div class="dash-top"><header class="dash-head"><div class="dash-head__in">' + logoImg(false, "dash-logo") +
        '<label class="dash-search"><input type="text" placeholder="Search" aria-label="Search" autocomplete="off"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.500" cy="8.500" r="5.500" fill="none" stroke="#5f6368" stroke-width="1.500"/><path d="M13 13l4 4" stroke="#5f6368" stroke-width="1.500"/></svg></label>' +
        '<button type="button" class="dash-ico" data-na="Task list" aria-label="Task list"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 5h14M3 10h14M3 15h9" stroke="#33383f" stroke-width="1.600"/></svg></button>' +
        '<button type="button" class="dash-ico" data-na="Notifications" aria-label="Notifications"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2.500a4.500 4.500 0 0 0-4.500 4.500v3l-1.500 3h12l-1.500-3V7A4.500 4.500 0 0 0 10 2.500zM8 16h4a2 2 0 0 1-4 0z" fill="none" stroke="#33383f" stroke-width="1.400" stroke-linejoin="round"/></svg></button>' +
        '<button type="button" class="dash-link" data-na="Support">Support ' + ICON.chevron + "</button>" +
        '<div class="dash-user"><button type="button" class="dash-link" data-user aria-haspopup="true"><span class="dash-avatar">' + esc(initials) + "</span>" + esc(name) + " " + ICON.chevron +
        '</button><div class="dash-menu" hidden><button type="button" data-logout>Logout</button></div></div></div></header>' +
        '<nav class="dash-nav"><div class="dash-nav__in">' +
        nav.map((n) =>
          '<div class="dash-nav__item"><button type="button" class="' + (n === area ? "is-on" : "") + '"' +
          (MP_NAV[n] ? ' data-go="' + MP_NAV[n] + '"' : ' data-na="' + n + '"') + ">" + n + "</button>" +
          (navMenus[n] ? dropHtml(navMenus[n]) : "") + "</div>"
        ).join("") + "</div></nav>" +
        '<nav class="dash-sub"><div class="dash-sub__in">' +
        MP_SUB[area].map((s) => '<button type="button" class="' + (s[0] === sub ? "is-on" : "") + '"' + (s[1] ? ' data-go="' + s[1] + '"' : ' data-na="' + s[0] + '"') + ">" + subIcons[s[0]] + s[0] + "</button>").join("") + "</div></nav></div>" +
        '<main class="dash-main' + (area === "Administration" ? " dash-main--admin" : "") + '">' + bodyHtml + "</main>" +
        '<footer class="dash-foot"><div class="dash-foot__in">' + logoImg(false, "dash-foot__logo") +
        '<p>&copy; 2026 HEWLETT PACKARD ENTERPRISE. ALL RIGHTS RESERVED &mdash; V. 9.0.1<br><a href="#" data-na="Terms &amp; Conditions">TERMS &amp; CONDITIONS</a> | <a href="#" data-na="Privacy Policy">PRIVACY POLICY</a></p></div></footer>'
    );

    const menu = el.querySelector(".dash-menu");
    el.querySelector("[data-user]").addEventListener("click", (event) => {
      event.stopPropagation();
      menu.hidden = !menu.hidden;
    });
    el.addEventListener("click", () => {
      menu.hidden = true;
    });
    el.querySelector("[data-logout]").addEventListener("click", () => {
      server.loggedIn = false;
      load(tab, URL_VM + "/login/auth", "push");
    });
    return wirePage(el, tab);
  }

  function buildDashboard(tab) {
    const stats = [["Groups", server.groups.length], ["Clouds", server.clouds.length], ["Clusters", server.infrastructure.cluster ? 1 : 0], ["Apps", 0], ["Instances", server.infrastructure.vm.managed ? 1 : 0], ["Users", 1]];
    const statuses = ["CPU", "Memory", "Storage", "Database", "Queues", "Search"];
    const ok = '<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="9" fill="#01a982"/><path d="M5.500 10.200l3 3 6-6.400" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const stack = '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="2.500" width="16" height="4.500" rx="1" fill="#33383f"/><rect x="2" y="8" width="16" height="4.500" rx="1" fill="#33383f"/><rect x="2" y="13.500" width="16" height="4.500" rx="1" fill="#33383f"/></svg>';
    return morpheusShell(
      tab,
      "Operations",
      "Dashboard",
      '<section class="dash-card"><h2>' + stack + 'Environment</h2><div class="dash-stats">' +
        stats.map((s) => "<div><strong>" + s[1] + "</strong><span>" + s[0] + "</span></div>").join("") + "</div></section>" +
        '<section class="dash-card dash-card--sm"><h2>' + stack + 'System Status</h2><div class="dash-status">' +
        statuses.map((s) => "<span>" + ok + s + "</span>").join("") + "</div></section>" +
        '<section class="dash-card"><h2><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2.500l2.200 4.700 5.100.6-3.800 3.500 1 5.100L10 13.800l-4.500 2.600 1-5.100L2.700 7.800l5.100-.6z" fill="none" stroke="#33383f" stroke-width="1.300" stroke-linejoin="round"/></svg>Favorites</h2>' +
        '<div class="dash-table"><span>INSTANCE</span><span>TYPE</span><span>ADDRESS</span></div></section>'
    );
  }

  // ── Administration > Settings > Appliance ───────────────────────
  const DAYS_HELP = "Setting this field to 0 will disable this feature";
  const HOSTS_HELP = "Provide a comma delimited list of ips/hostnames to be ";
  const APPLIANCE_SECTIONS = [
    {
      title: "Appliance Settings",
      fields: [
        { k: "applianceUrl", l: "Appliance URL", t: "text", v: URL_VM + "/" },
        {
          k: "internalUrl", l: "Internal Appliance URL (PXE)", t: "text", v: "",
          help: "For PXE-Boot your appliance needs to be routable directly with minimal NAT masquerading. This allows one to override the default appliance url endpoint for use by the PXE Server. If this is unset, the default appliance url will be used instead."
        },
        { k: "apiOrigins", l: "API Allowed Origins", t: "text", v: "", grey: true },
        {
          k: "cloudSync", l: "Cloud Sync Interval", t: "num", v: 300,
          help: "Changing value can adversely affect sync performance. Use with caution or on environments with large numbers of clouds. The default sync interval is 5 minutes (300 seconds)."
        },
        {
          k: "clusterSync", l: "Cluster Sync Interval", t: "num", v: 60,
          help: "Changing value can adversely affect sync performance. Use with caution or on environments with large numbers of clusters. The default sync interval is set to the cloud sync interval."
        },
        { k: "usageRet", l: "Usage Retainment", t: "num", v: 1, unit: "Days" },
        { k: "invoiceRet", l: "Invoice Retainment", t: "num", v: 1, unit: "Months" },
        { k: "incidentRet", l: "Incident Retainment", t: "num", v: 30, unit: "Days" },
        {
          k: "statsRet", l: "Stats Retainment", t: "select", v: "30 Days",
          opts: ["7 Days", "14 Days", "30 Days", "60 Days", "90 Days"], help: "The number of days stats will be retained."
        },
        { k: "reportsRet", l: "Reports Retainment", t: "num", v: 90, unit: "Days" },
        { k: "deniedHosts", l: "Denied Hosts", t: "text", v: "", grey: true, help: HOSTS_HELP + "blocked when using HTTP Task Types or REST Datasource Option Lists." },
        {
          k: "approvedHosts", l: "Approved Hosts", t: "text", v: "",
          help: HOSTS_HELP + "allowed when using HTTP Task Types or REST Datasource Option Lists. If not specified, only deny list is filtered out."
        },
        {
          k: "exchangeUrl", l: "Exchange URL", t: "text", v: "https://share.morpheusdata.com",
          help: "The url used for checking if there is an update for plugins default: https://share.morpheusdata.com"
        },
        {
          k: "skipAgent", l: "Skip Agent Install", t: "toggle", v: false,
          help: "Disables Agent installation globally. This will result in a lack of guest operating system statistics. Automation scripts may also be adversely affected."
        },
        {
          k: "sslAgent", l: "Enable SSL Verification of Agent", t: "toggle", v: false,
          help: "Enabling SSL Verification of Agent Communications requires a valid Certificate be installed on the Appliance."
        },
        { k: "disableSsh", l: "Disable SSH Password Authentication", t: "toggle", v: false },
        { k: "murph", l: "Enable Murph AI chat assistant widget", t: "toggle", v: false },
        {
          k: "locale", l: "Default Appliance Locale", t: "select", v: "", opts: ["", "English (en)", "Spanish (es)", "French (fr)", "German (de)", "Japanese (ja)"],
          help: "Setting a default locale for the application will override user browser preferences."
        },
        {
          k: "consoleGw", l: "Default Console Gateway", t: "select", v: "", opts: [""],
          help: "A Worker can be used as a Console Gateway for all console routing if needed (optional)."
        },
        {
          k: "maxOptions", l: "Max Option List Size", t: "num", v: 1000, unit: "x10\u00b3",
          help: "Increasing this value can adversely affect Morpheus performance. Increase with caution."
        },
        { k: "dashboards", l: "Dashboards to Display", t: "search", v: "" }
      ]
    },
    {
      title: "Tenant Management Settings",
      fields: [
        { k: "registration", l: "Registration Enabled", t: "toggle", v: false },
        { k: "tenantRole", l: "Default Tenant Role", t: "select", v: "", opts: ["", "Tenant Admin"] },
        { k: "userRole", l: "Default User Role", t: "select", v: "", opts: ["", "User", "Read Only"] },
        { k: "dockerPriv", l: "Docker Privileged Mode", t: "toggle", v: false }
      ]
    },
    {
      title: "User Management Settings",
      fields: [
        { k: "minPw", l: "Min Password Length", t: "num", v: 8 },
        { k: "minUpper", l: "Min Password Uppercase", t: "num", v: 1 },
        { k: "minNum", l: "Min Password Numbers", t: "num", v: 1 },
        { k: "minSym", l: "Min Password Symbols", t: "num", v: 1 },
        { k: "sessionExpires", l: "Session Expires", t: "num", v: 120, unit: "Minutes", help: "Number of minutes of inactivity before browser session is forcibly logged off." },
        {
          k: "sessionWarn", l: "Session Warning", t: "num", v: 115, unit: "Minutes",
          help: "Number of minutes of inactivity before browser session timeout warning is displayed with an option to extend."
        },
        { k: "expirePw", l: "Expire Password After", t: "num", v: 0, unit: "Days", help: DAYS_HELP },
        { k: "disableAttempts", l: "Disable User After Attempts", t: "num", v: 0, help: DAYS_HELP },
        { k: "disableInactive", l: "Disable User if Inactive For", t: "num", v: 0, unit: "Days", help: DAYS_HELP },
        { k: "warnEmail", l: "Send warning email before deactivating", t: "num", v: 0, unit: "Days", help: DAYS_HELP }
      ]
    },
    {
      title: "Email Settings",
      fields: [
        { k: "fromAddress", l: "From Address", t: "text", v: "info@gomorpheus.com" },
        { k: "smtpServer", l: "SMTP Server", t: "text", v: "" },
        { k: "smtpPort", l: "SMTP Port", t: "num", v: 0 },
        { k: "smtpSsl", l: "SSL Enabled", t: "toggle", v: false },
        { k: "smtpTls", l: "TLS Encryption", t: "toggle", v: false },
        { k: "smtpUser", l: "SMTP User", t: "text", v: "", grey: true },
        { k: "smtpPass", l: "SMTP Password", t: "password", v: "", grey: true }
      ]
    },
    {
      title: "Twilio SMS Settings",
      fields: [
        { k: "twilioSid", l: "Account SID", t: "text", v: "" },
        { k: "twilioFrom", l: "SMS From #", t: "text", v: "", ph: "5555555555" },
        { k: "twilioToken", l: "Auth Token", t: "password", v: "" }
      ]
    },
    {
      title: "Proxy Settings",
      fields: [
        { k: "proxyHost", l: "Proxy Host", t: "text", v: "", grey: true },
        { k: "proxyPort", l: "Proxy Port", t: "num", v: 0 },
        { k: "proxyUser", l: "Proxy User", t: "text", v: "" },
        { k: "proxyPass", l: "Proxy Password", t: "password", v: "" },
        { k: "proxyDomain", l: "Proxy Domain", t: "text", v: "" },
        { k: "proxyWorkstation", l: "Proxy Workstation", t: "text", v: "" },
        {
          k: "noProxy", l: "No Proxy", t: "text", v: "", grey: true,
          help: "Provide a comma, space, or pipe delimited list of hosts to bypass the proxy settings. Example hosts: *example.com, example.com or IP address."
        }
      ]
    },
    {
      title: "Currency Settings",
      fields: [
        { k: "currencyProvider", l: "Currency Provider", t: "select", v: "", opts: ["", "Open Exchange Rates"] },
        { k: "currencyKey", l: "Provider API Key", t: "text", v: "" }
      ]
    },
    {
      title: "Enabled Clouds",
      pair: [
        { k: "cloudPrivate", l: "Private Cloud", t: "toggle", v: true },
        { k: "cloudVmware", l: "VMware vCenter", t: "toggle", v: true }
      ]
    }
  ];
  const PROVISIONING_SECTIONS = [
    {
      title: "Provisioning Settings",
      fields: [
        { k: "allowCloud", l: "Allow Cloud Selection", t: "toggle", v: true },
        { k: "allowDocker", l: "Allow Docker Host Selection", t: "toggle", v: false },
        { k: "requireEnv", l: "Require Environment Selection", t: "toggle", v: false },
        { k: "showPricing", l: "Show Pricing", t: "toggle", v: false },
        { k: "hideDsStats", l: "Hide Datastore Stats On Selection", t: "toggle", v: false },
        { k: "crossTenantNaming", l: "Cross-Tenant Naming Policies", t: "toggle", v: false },
        { k: "reuseNaming", l: "Reuse Naming Sequence Numbers", t: "toggle", v: false },
        { k: "consoleKeyboard", l: "Show Console Keyboard Layout Settings", t: "toggle", v: false }
      ]
    },
    {
      title: "Deployment Settings",
      fields: [{ k: "deployArchive", l: "Deployment Archive Store", t: "select", v: "", opts: [""], empty: "No options available" }]
    },
    {
      title: "Cloud-Init Settings",
      fields: [
        { k: "ciUser", l: "Username", t: "text", v: "student" },
        { k: "ciPass", l: "Password", t: "password", v: "************", noEye: true },
        { k: "ciKeyPair", l: "Key Pair", t: "search", v: "", ph: "Select" }
      ]
    },
    {
      title: "Windows Settings",
      fields: [{ k: "winAdminPass", l: "Administrator Password", t: "password", v: "************", noEye: true }]
    },
    {
      title: "Library Settings",
      fields: [
        { k: "libCatalog", l: "Enable Catalog", t: "toggle", v: true },
        { k: "libApps", l: "Enable Apps", t: "toggle", v: true },
        { k: "libInstances", l: "Enable Instances", t: "toggle", v: true },
        { k: "provOrder", l: "Provisioning Order", t: "select", v: "", opts: [""] }
      ]
    },
    {
      title: "PXE Boot Settings",
      fields: [{ k: "pxeRootPass", l: "Default Root Password", t: "text", v: "" }]
    },
    {
      title: "App Blueprint Settings",
      fields: [{ k: "blueprintType", l: "Default Blueprint Type", t: "select", v: "", opts: [""] }]
    },
    {
      title: "Terraform Settings",
      fields: [
        { k: "tfRuntime", l: "Terraform Runtime", t: "select", v: "", opts: [""] },
        { k: "tfVersion", l: "Default Terraform Version", t: "text", v: "", grey: true, help: "Specify the default Terraform version to use" }
      ]
    }
  ];
  const MORPHEUS_BRAND =
    '<svg class="st-brand__mark" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="15" fill="#e5473d"/><path d="M5 18l5-1 3-7 4 12 3-9 2 5h5" fill="none" stroke="#fff" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '<span class="st-brand__name">MORPHEUS</span>';
  const BACKUP_SECTIONS = [
    {
      title: "Backup Settings",
      group: "morpheus",
      fields: [
        { k: "bkScheduled", l: "Scheduled Backups", t: "toggle", v: false },
        { k: "bkCreate", l: "Create Backups", t: "toggle", v: false },
        {
          k: "bkAppliance", l: "Backup Appliance", t: "toggle", v: true,
          help: 'When enabled, a <a href="#" data-na="Backup">Backup</a> will be created to backup the Morpheus appliance database.'
        },
        {
          k: "bkBucket", l: "Default Backup Bucket", t: "select", v: "None", opts: ["None"],
          help: 'Buckets can be configured and managed in the <a href="#" data-na="Infrastructure Storage">Infrastructure Storage</a> section.'
        },
        { k: "bkSchedule", l: "Default Backup Schedule", t: "select", v: "None", opts: ["None"] },
        { k: "bkRetention", l: "Default Backup Retention", t: "text", v: "", help: "Number of successful backups to retain." },
        {
          k: "bkSynthetic", l: "Default Synthetic Full Backup Enabled", t: "toggle", v: false,
          help: "Enable full synthetic backups by default on supported backup types."
        },
        { k: "bkSyntheticSchedule", l: "Default Synthetic Full Backup Schedule", t: "select", v: "None", opts: ["None"] }
      ]
    }
  ];
  const ENVIRONMENTS = [
    { name: "Dev", code: "dev", description: "Development" },
    { name: "Test", code: "qa", description: "QA Test" },
    { name: "Staging", code: "staging", description: "Staging" },
    { name: "Production", code: "production", description: "Production" }
  ];
  const LICENSES = [{ key: "a89068b9", tier: "Core", start: "04/08/2026", end: "04/09/2027", sockets: 32 }];
  const APPLIANCE_ID = "73cd9f56-92df-46e0-a930-a286080579b5";
  const STATION_ID = "4bbb52a4-ccdc-4951-8374-b86dd5c47a19";
  const SUPPORT_FIELDS = [
    { k: "supBundles", l: "Daily Support Bundles", t: "toggle", v: false },
    { k: "supSend", l: "Send to HPE", t: "toggle", v: false },
    { k: "supRemote", l: "Remote Support Access", t: "toggle", v: false, disabled: true },
    { k: "supBucket", l: "Default Support Bundle Bucket", t: "select", v: "", opts: [""] }
  ];
  let maintenanceMode = false;
  const SETTINGS_PANELS = {
    Appliance: APPLIANCE_SECTIONS,
    Provisioning: PROVISIONING_SECTIONS,
    Backups: BACKUP_SECTIONS
  };
  const SETTINGS_TABS = ["Appliance", "Provisioning", "Backups", "Environments", "Utilities", "Support", "License", "Morpheus Central"];
  const SETTINGS_DEFAULTS = {};
  SUPPORT_FIELDS.forEach((f) => (SETTINGS_DEFAULTS[f.k] = f.v));
  Object.keys(SETTINGS_PANELS).forEach((name) =>
    SETTINGS_PANELS[name].forEach((s) => (s.fields || s.pair).forEach((f) => (SETTINGS_DEFAULTS[f.k] = f.v)))
  );

  function settingControl(f, v) {
    const attrs = 'id="st-' + f.k + '" data-k="' + f.k + '"';
    const cls = "st-input" + (f.grey ? " is-grey" : "");
    if (f.t === "toggle") {
      return '<label class="st-toggle' + (f.disabled ? " is-disabled" : "") + '"><input type="checkbox" ' + attrs + (v ? " checked" : "") + (f.disabled ? " disabled" : "") + '><span></span></label>';
    }
    if (f.t === "select") {
      return '<div class="st-select"><select ' + attrs + ">" +
        f.opts.map((o) => '<option value="' + esc(o) + '"' + (o === v ? " selected" : "") + ">" + esc(o || f.empty || "Select") + "</option>").join("") +
        "</select>" + ICON.chevron + "</div>";
    }
    if (f.t === "password") {
      return '<div class="st-pw"><input class="' + cls + '" type="password" ' + attrs + ' value="' + esc(v) + '" autocomplete="off">' +
        (f.noEye ? "" : '<button type="button" class="st-eye" data-eye aria-label="Show password"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.800" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/><path d="M3 3l18 18"/></svg></button>') + "</div>";
    }
    if (f.t === "num") {
      return '<div class="st-num"><div class="st-num__field"><input class="' + cls + '" type="number" min="0" ' + attrs + ' value="' + esc(v) + '">' +
        '<span class="st-step"><button type="button" data-step="1" aria-label="Increase">+</button><button type="button" data-step="-1" aria-label="Decrease">-</button></span></div>' +
        (f.unit ? '<span class="st-unit">' + f.unit + "</span>" : "") + "</div>";
    }
    if (f.t === "search") {
      return '<div class="st-search"><input class="' + cls + '" type="text" ' + attrs + ' value="' + esc(v) + '" placeholder="' + (f.ph || "Search") + '" autocomplete="off">' +
        '<button type="button" class="st-search__btn" data-na="' + esc(f.l) + ' search" aria-label="Search"><svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.800" stroke-linecap="round" aria-hidden="true"><circle cx="8.500" cy="8.500" r="5.500"/><path d="M13 13l4 4"/></svg></button></div>';
    }
    return '<input class="' + cls + '" type="text" ' + attrs + ' value="' + esc(v) + '"' + (f.ph ? ' placeholder="' + f.ph + '"' : "") + ' autocomplete="off" spellcheck="false">';
  }

  function buildSettings(tab) {
    const vals = Object.assign({}, SETTINGS_DEFAULTS, server.settings);
    const row = (f) =>
      '<div class="st-row"><label class="st-label" for="st-' + f.k + '">' + f.l + '</label><div class="st-ctl">' +
      settingControl(f, vals[f.k]) + (f.help ? '<p class="st-help">' + f.help + "</p>" : "") + "</div></div>";
    const section = (s) =>
      '<div class="st-sec"><h3 class="st-h">' + s.title + "</h3>" +
      (s.group
        ? '<button type="button" class="st-group" data-collapse aria-expanded="true">' + ICON.chevron + MORPHEUS_BRAND + "</button>"
        : "") +
      (s.pair
        ? '<div class="st-row"><span class="st-label">' + s.pair[0].l + '</span><div class="st-ctl st-pair">' +
          settingControl(s.pair[0], vals[s.pair[0].k]) + '<span class="st-label st-label--inline">' + s.pair[1].l + "</span>" +
          settingControl(s.pair[1], vals[s.pair[1].k]) + "</div></div>"
        : s.fields.map(row).join("")) + "</div>";

    const which = tab.page.which || "appliance";
    const pageInfo = SETTINGS_PAGES[which];
    const current = pageInfo.tab;
    const trash = '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M7 2h6l1 1.500h3V5H3V3.500h3zM4.500 6.500h11l-.8 11a1 1 0 0 1-1 .9H6.300a1 1 0 0 1-1-.9z"/></svg>';
    const info = '<span class="sp-info" aria-label="More information"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.400" aria-hidden="true"><circle cx="10" cy="10" r="8"/><path d="M10 9v5M10 6.200v.1" stroke-linecap="round"/></svg></span>';
    const envRow = (e) =>
      '<div class="env-row" data-env="' + esc((e.name + " " + e.code + " " + e.description).toLowerCase()) + '"><span>' + esc(e.name) +
      "</span><span>" + esc(e.code) + "</span><span>" + esc(e.description) +
      '</span><button type="button" class="env-actions" data-na="Actions">Actions ' + ICON.chevron + "</button></div>";
    const saveRow = '<div class="st-save"><button type="button" class="st-btn" data-save>Save</button></div>';
    const bodies = {
      environments: () =>
        '<div class="env-bar"><div class="st-search env-search"><input class="st-input" type="text" data-envsearch placeholder="Search" aria-label="Search environments" autocomplete="off">' +
        '<button type="button" class="st-search__btn" data-envgo aria-label="Search"><svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.800" stroke-linecap="round" aria-hidden="true"><circle cx="8.500" cy="8.500" r="5.500"/><path d="M13 13l4 4"/></svg></button></div>' +
        '<button type="button" class="st-btn st-btn--create" data-na="Create Environment">+ Create Environment</button></div>' +
        '<div class="env-table"><div class="env-head"><span>NAME</span><span>CODE</span><span>DESCRIPTION</span><span></span></div>' +
        ENVIRONMENTS.map(envRow).join("") + '<p class="env-empty" hidden>No environments found.</p></div>',
      utilities: () =>
        '<h3 class="st-h">Utilities</h3>' +
        '<div class="ut-row"><span>Reindex all searchable data</span><button type="button" class="st-btn st-btn--wide" data-util="reindex">Execute</button></div>' +
        '<div class="ut-row"><span>Toggle Maintenance Mode</span><button type="button" class="st-btn st-btn--wide" data-util="maintenance">' + (maintenanceMode ? "Disable" : "Enable") + "</button></div>",
      support: () =>
        '<h3 class="st-h">Support Settings</h3>' +
        '<div class="sp-id"><span class="sp-id__label">Appliance Identifier</span><div><span class="sp-id__val">' + APPLIANCE_ID +
        '</span><p class="st-help">Unique identifier for this Morpheus appliance. Provide this to HPE Support when requested.</p></div></div>' +
        '<div class="sp-table"><div class="sp-head"><span>Hostname</span><span>Status</span><span>Station ID</span></div>' +
        '<div class="sp-row"><span>hpe-vm</span><span class="is-ok">Connected</span><span>' + STATION_ID + "</span></div></div>" +
        SUPPORT_FIELDS.slice(0, 3).map((f) => '<div class="sp-tog"><span>' + f.l + "</span>" + info + settingControl(f, vals[f.k]) + "</div>").join("") +
        '<h3 class="st-h st-h--gap">Support Bundle Storage</h3>' +
        '<div class="sp-field"><label for="st-supBucket">' + SUPPORT_FIELDS[3].l + "</label>" + settingControl(SUPPORT_FIELDS[3], vals.supBucket) + "</div>" + saveRow,
      license: () => {
        const total = LICENSES.reduce((n, l) => n + l.sockets, 0);
        return '<h3 class="st-h">Current Licenses</h3><div class="lic-scroll"><div class="lic-table">' +
          '<div class="lic-head"><span>KEY</span><span>PRODUCT TIER</span><span>START DATE</span><span>END DATE</span><span>HVM SOCKETS</span><span></span></div>' +
          LICENSES.map((l) =>
            '<div class="lic-row"><span>' + esc(l.key) + "</span><span>" + esc(l.tier) + "</span><span>" + l.start + "</span><span>" + l.end + "</span><span>" + l.sockets +
            '</span><button type="button" class="lic-del" data-na="Delete license" aria-label="Delete license">' + trash + "</button></div>"
          ).join("") + "</div></div>" +
          '<h3 class="st-h st-h--gap">HVM Sockets</h3><div class="lic-bar" role="img" aria-label="0 of ' + total + ' HVM sockets used"><span style="width:0%"></span></div>' +
          '<div class="lic-legend"><span><i class="is-used"></i>Used HVM Sockets: 0</span><span><i></i>Unused HVM Sockets: ' + total + "</span></div>";
      },
      "morpheus-central": () =>
        '<div class="mc-bar"><button type="button" class="st-btn st-btn--create" data-na="Register Appliance">Register Appliance</button></div>' +
        '<div class="mc-table"><div class="mc-head"><span>ACTIVATION CODE</span><span>REGISTRATION STATUS</span></div>' +
        '<div class="mc-row"><span>' + STATION_ID + "</span><span>Registering</span></div></div>"
    };
    const body = bodies[which] ? bodies[which]() : SETTINGS_PANELS[current].map(section).join("") + saveRow;

    const el = morpheusShell(
      tab,
      "Administration",
      "Settings",
      '<div class="st-expandrow"><span class="st-pagetitle">' + (pageInfo.heading || "") + '</span><button type="button" class="st-expand" data-na="Expand" aria-label="Expand"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.500" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.500 3H17v5.500M8.500 17H3v-5.500M17 3l-5.500 5.500M3 17l5.500-5.500"/></svg></button></div>' +
        '<div class="st-card"><div class="st-tabs" role="tablist">' +
        SETTINGS_TABS.map((t) => {
          const slug = Object.keys(SETTINGS_PAGES).filter((k) => SETTINGS_PAGES[k].tab === t)[0];
          return '<button type="button" role="tab" class="' + (t === current ? "is-on" : "") + '" aria-selected="' + (t === current) + '"' +
            (slug ? ' data-go="' + URL_VM + "/admin/settings/" + slug + '"' : ' data-na="' + t + ' settings"') + ">" + t + "</button>";
        }).join("") +
        '</div><div class="st-panel">' + body + "</div></div>"
    );

    el.addEventListener("click", (event) => {
      const util = event.target.closest("[data-util]");
      if (util) {
        if (util.dataset.util === "maintenance") {
          maintenanceMode = !maintenanceMode;
          util.textContent = maintenanceMode ? "Disable" : "Enable";
          toast(maintenanceMode ? "Maintenance mode enabled." : "Maintenance mode disabled.");
        } else {
          util.disabled = true;
          util.textContent = "Executing...";
          setTimeout(() => {
            util.disabled = false;
            util.textContent = "Execute";
            toast("Reindex of all searchable data started.");
          }, 1200);
        }
        return;
      }
      const collapse = event.target.closest("[data-collapse]");
      if (collapse) {
        const sec = collapse.closest(".st-sec");
        const open = sec.classList.toggle("is-collapsed") === false;
        collapse.setAttribute("aria-expanded", String(open));
        return;
      }
      const step = event.target.closest("[data-step]");
      if (step) {
        const input = step.closest(".st-num__field").querySelector("input");
        input.value = Math.max(0, (parseInt(input.value, 10) || 0) + Number(step.dataset.step));
        return;
      }
      const eye = event.target.closest("[data-eye]");
      if (eye) {
        const input = eye.parentNode.querySelector("input");
        input.type = input.type === "password" ? "text" : "password";
      }
    });

    const envSearch = el.querySelector("[data-envsearch]");
    if (envSearch) {
      const filter = () => {
        const q = envSearch.value.trim().toLowerCase();
        let shown = 0;
        el.querySelectorAll(".env-row").forEach((r) => {
          const hit = !q || r.dataset.env.indexOf(q) >= 0;
          r.hidden = !hit;
          if (hit) shown++;
        });
        el.querySelector(".env-empty").hidden = shown > 0;
      };
      envSearch.addEventListener("input", filter);
      envSearch.addEventListener("keydown", (event) => {
        if (event.key === "Enter") filter();
      });
      el.querySelector("[data-envgo]").addEventListener("click", filter);
    }

    const saveBtn = el.querySelector("[data-save]");
    if (saveBtn) {
      saveBtn.addEventListener("click", () => {
        const next = {};
        el.querySelectorAll("[data-k]").forEach((c) => {
          next[c.dataset.k] = c.type === "checkbox" ? c.checked : c.value;
        });
        if (next.applianceUrl !== undefined && !/^https?:\/\/\S+$/i.test(next.applianceUrl.trim())) {
          toast("Appliance URL must start with http:// or https://.");
          el.querySelector('[data-k="applianceUrl"]').focus();
          return;
        }
        server.settings = Object.assign({}, server.settings, next);
        if (tab.page.which === "backups") server.settings.backupsSaved = true;
        saveServer();
        toast("Settings saved.");
      });
    }
    return el;
  }

  // ── Infrastructure > Clouds ─────────────────────────────────────
  const VMWARE_LOGO = '<span class="cl-vmw"><b>vm</b>ware</span>';
  const CLOUD_TYPES = [
    {
      id: "private",
      label: "Private Cloud",
      title: "PRIVATE CLOUD",
      desc: "The \u201cPrivate Cloud\u201d provides a dedicated, isolated environment where users have full control over server management and resource allocation. It offers flexibility and security, with the ability to configure and manage infrastructure according to specific organizational needs.",
      logo: '<span class="cl-brand">' + MORPHEUS_BRAND + "</span>"
    },
    { id: "vcenter", label: "VMware vCenter", title: "VMWARE VCENTER", desc: "VMware vCenter cloud", logo: VMWARE_LOGO }
  ];
  const typeOf = (cloud) => CLOUD_TYPES.filter((t) => t.id === cloud.type)[0] || CLOUD_TYPES[0];
  const groupOf = (cloud) => server.groups.filter((g) => g.id === cloud.groupId)[0];
  const cloudsIn = (group) => server.clouds.filter((c) => c.groupId === group.id);
  // A new cloud spends a few seconds initializing, like a real sync.
  const INIT_MS = 15000;
  const isInitializing = (cloud) => Date.now() - new Date(cloud.created).getTime() < INIT_MS;

  const CL_ICON = {
    donutHead: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.200" aria-hidden="true"><path d="M5.500 15.500a3.500 3.500 0 0 1-.4-7A4.500 4.500 0 0 1 14 7.500a3.800 3.800 0 0 1 .5 8z"/></svg>',
    cloudDown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.500" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 7v7M9 11.500l3 3 3-3"/></svg>',
    cloudUp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.500" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 16.500V9.500M9 12.500l3-3 3 3"/></svg>',
    pencil: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M3 14.500V17h2.500l7.300-7.300-2.500-2.500zM16.700 5.800a.7.7 0 0 0 0-1l-1.500-1.500a.7.7 0 0 0-1 0l-1.200 1.200 2.500 2.500z"/></svg>',
    trash: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M7 2h6l1 1.500h3V5H3V3.500h3zM4.500 6.500h11l-.8 11a1 1 0 0 1-.9.900H6.300a1 1 0 0 1-1-.9z"/></svg>',
    ok: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="#1f9d55"/><path d="M6.500 12.300l3.800 3.800 7.200-7.700" fill="none" stroke="#fff" stroke-width="2.400" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    wait: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="none" stroke="#c9ced6" stroke-width="3"/><path d="M12 2a10 10 0 0 1 10 10" fill="none" stroke="#01a982" stroke-width="3" stroke-linecap="round"/></svg>',
    check: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 10.500l3.200 3.200L15 6.800"/></svg>'
  };

  const mk = (tag, cls, html) => {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    if (html !== undefined) el.innerHTML = html;
    return el;
  };

  // New Cloud is a four-step dialog (Cloud, Configure, Group, Review); Edit reuses the Configure form.
  function openCloudWizard(tab) {
    const state = {
      step: 0,
      type: "",
      name: "",
      code: "",
      labels: "",
      location: "",
      enabled: true,
      powerOn: true,
      inventory: true,
      groupMode: "existing",
      groupId: "",
      newGroup: ""
    };
    const STEPS = ["Cloud", "Configure", "Group", "Review"];
    let box = null;

    const stepper = () =>
      '<ol class="wz-steps">' +
      STEPS.map((s, i) => {
        const st = i < state.step ? "is-done" : i === state.step ? "is-now" : "";
        return '<li class="wz-step ' + st + '"><span class="wz-dot">' + (i < state.step ? CL_ICON.check : "") + "</span><span>" + s + "</span></li>";
      }).join("") + "</ol>";

    const field = (key, label, help) =>
      '<div class="md__row"><label class="md__label">' + label + "</label><div>" +
      '<div class="' + (key === "labels" ? "md__narrow" : "") + '"><input class="st-input" type="text" data-w="' + key + '" value="' + esc(state[key]) + '" autocomplete="off" spellcheck="false"></div>' +
      (help ? '<p class="st-help">' + help + "</p>" : "") + "</div></div>";

    const check = (key, label) =>
      '<label class="wz-check"><input type="checkbox" data-w="' + key + '"' + (state[key] ? " checked" : "") + "><i></i><span>" + label + "</span></label>";

    function body() {
      if (state.step === 0) {
        return '<div class="wz-search"><input class="st-input" type="text" data-wsearch placeholder="Search" aria-label="Search cloud types" autocomplete="off">' +
          '<span class="wz-sync">' + CL_ICON.cloudDown + CL_ICON.cloudUp + "</span></div>" +
          '<div class="wz-types" data-types>' +
          CLOUD_TYPES.map((t) =>
            '<button type="button" class="wz-type' + (state.type === t.id ? " is-sel" : "") + '" data-type="' + t.id + '" data-q="' + esc((t.label + " " + t.desc).toLowerCase()) + '">' +
            '<span class="wz-type__logo">' + t.logo + '</span><span class="wz-type__txt"><b>' + t.title + "</b><span>" + t.desc + "</span></span></button>"
          ).join("") + '<p class="wz-none" hidden>No cloud types found.</p></div>';
      }
      if (state.step === 1) {
        return field("name", "Name") + field("code", "Code") + field("labels", "Labels", "A comma separated list of labels that can be used to group/organize items.") +
          field("location", "Location") +
          '<div class="wz-checks">' + check("enabled", "Enabled") + check("powerOn", "Automatically Power On VMs") + check("inventory", "Inventory Existing Instances") + "</div>" +
          ["Advanced Options", "Custom Logos", "Inventory Options", "Provisioning Command"].map((s) =>
            '<button type="button" class="md__adv" data-na="' + s + '"><i>&#9654;</i>' + s + "</button>"
          ).join("");
      }
      if (state.step === 2) {
        const opts = '<option value="">Select</option>' + server.groups.map((g) => '<option value="' + g.id + '"' + (String(g.id) === String(state.groupId) ? " selected" : "") + ">" + esc(g.name) + "</option>").join("");
        return '<div class="wz-radios"><label><input type="radio" name="gm" value="existing"' + (state.groupMode === "existing" ? " checked" : "") + "> USE EXISTING</label>" +
          '<label><input type="radio" name="gm" value="new"' + (state.groupMode === "new" ? " checked" : "") + "> CREATE NEW</label></div>" +
          (state.groupMode === "existing"
            ? '<div class="md__row wz-grp"><label class="md__label">Group</label><div class="st-select"><select data-w="groupId">' + opts + "</select>" + ICON.chevron + "</div></div>"
            : field("newGroup", "Group Name"));
      }
      const gName = state.groupMode === "new" ? state.newGroup.trim() : (server.groups.filter((g) => String(g.id) === String(state.groupId))[0] || {}).name || "";
      return '<dl class="wz-review"><dt>Name:</dt><dd>' + esc(state.name) + "</dd><dt>Location:</dt><dd>" + esc(state.location) +
        "</dd><dt>Domain:</dt><dd>localdomain</dd><dt>Group:</dt><dd>" + esc(gName) + "</dd><dt>Visibility:</dt><dd>private</dd></dl>";
    }

    function render() {
      box.querySelector("[data-wbody]").innerHTML = body();
      box.querySelector("[data-wstepper]").innerHTML = stepper();
      box.querySelector("[data-prev]").disabled = state.step === 0;
      box.querySelector("[data-next]").textContent = state.step === 3 ? "Complete" : "Next";
      const err = box.querySelector("[data-err]");
      err.hidden = true;
      const first = box.querySelector("[data-wsearch], [data-w='name'], [data-w='newGroup'], [data-w='groupId']");
      if (first) first.focus();
    }

    function sync() {
      box.querySelectorAll("[data-w]").forEach((c) => {
        state[c.dataset.w] = c.type === "checkbox" ? c.checked : c.value;
      });
    }

    function fail(message) {
      const err = box.querySelector("[data-err]");
      err.textContent = message;
      err.hidden = false;
    }

    function validate() {
      if (state.step === 0 && !state.type) return "Select a cloud type to continue.";
      if (state.step === 1) {
        const name = state.name.trim();
        if (!name) return "Name is required.";
        if (server.clouds.some((c) => c.name.toLowerCase() === name.toLowerCase())) return "A cloud with this name already exists.";
      }
      if (state.step === 2) {
        if (state.groupMode === "existing" && !state.groupId) return "Select a group.";
        if (state.groupMode === "new") {
          const n = state.newGroup.trim();
          if (!n) return "Group name is required.";
          if (server.groups.some((g) => g.name.toLowerCase() === n.toLowerCase())) return "A group with this name already exists.";
        }
      }
      return "";
    }

    function complete() {
      let groupId = Number(state.groupId);
      if (state.groupMode === "new") {
        groupId = nextId("group");
        server.groups.push({ id: groupId, name: state.newGroup.trim(), code: "", labels: "", location: "", created: new Date().toISOString() });
      }
      const id = nextId("cloud");
      server.clouds.push({
        id: id,
        type: state.type,
        name: state.name.trim(),
        code: state.code.trim(),
        labels: normalizeLabels(state.labels),
        location: state.location.trim(),
        enabled: state.enabled,
        powerOn: state.powerOn,
        inventory: state.inventory,
        groupId: groupId,
        created: new Date().toISOString()
      });
      saveServer();
      closeLayer();
      load(tab, URL_CLOUDS, "push");
    }

    box = openModal(
      '<div class="md md--wz" role="dialog" aria-modal="true" aria-labelledby="mdTitle">' +
        '<div class="md__head"><h2 id="mdTitle">CREATE CLOUD</h2><button type="button" class="md__x" aria-label="Close">' + ICON.close + "</button></div>" +
        '<div class="md__body wz-body"><div data-wstepper></div><div data-wbody></div><p class="mp-err md__err" data-err hidden></p></div>' +
        '<div class="md__foot"><button type="button" class="st-btn wz-btn" data-prev>Previous</button><button type="button" class="st-btn wz-btn" data-next>Next</button></div></div>'
    );

    box.addEventListener("click", (event) => {
      const t = event.target.closest("[data-type]");
      if (t) {
        state.type = t.dataset.type;
        box.querySelectorAll("[data-type]").forEach((b) => b.classList.toggle("is-sel", b === t));
        box.querySelector("[data-err]").hidden = true;
      }
    });
    box.addEventListener("dblclick", (event) => {
      if (event.target.closest("[data-type]")) box.querySelector("[data-next]").click();
    });
    box.addEventListener("input", (event) => {
      if (event.target.matches("[data-wsearch]")) {
        const q = event.target.value.trim().toLowerCase();
        let shown = 0;
        box.querySelectorAll("[data-type]").forEach((b) => {
          const hit = !q || b.dataset.q.indexOf(q) >= 0;
          b.hidden = !hit;
          if (hit) shown++;
        });
        box.querySelector(".wz-none").hidden = shown > 0;
      }
    });
    box.addEventListener("change", (event) => {
      if (event.target.name === "gm") {
        sync();
        state.groupMode = event.target.value;
        render();
      }
    });
    box.querySelector("[data-prev]").addEventListener("click", () => {
      sync();
      if (state.step > 0) {
        state.step--;
        render();
      }
    });
    box.querySelector("[data-next]").addEventListener("click", () => {
      sync();
      const error = validate();
      if (error) {
        fail(error);
        return;
      }
      if (state.step === 3) complete();
      else {
        state.step++;
        render();
      }
    });
    box.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && event.target.tagName === "INPUT" && event.target.type === "text" && !event.target.matches("[data-wsearch]")) {
        event.preventDefault();
        box.querySelector("[data-next]").click();
      }
    });
    wirePage(box, tab);
    render();
  }

  function openCloudEdit(tab, cloud) {
    const input = (k) => '<input class="st-input" type="text" data-f="' + k + '" value="' + esc(cloud[k]) + '" autocomplete="off" spellcheck="false">';
    const check = (k, l) => '<label class="wz-check"><input type="checkbox" data-f="' + k + '"' + (cloud[k] ? " checked" : "") + "><i></i><span>" + l + "</span></label>";
    const box = openModal(
      '<div class="md" role="dialog" aria-modal="true" aria-labelledby="mdTitle">' +
        '<div class="md__head"><h2 id="mdTitle">EDIT CLOUD</h2><button type="button" class="md__x" aria-label="Close">' + ICON.close + "</button></div>" +
        '<div class="md__body"><div class="md__row"><label class="md__label">Name</label><div>' + input("name") + "</div></div>" +
        '<div class="md__row"><label class="md__label">Code</label><div>' + input("code") + "</div></div>" +
        '<div class="md__row"><label class="md__label">Labels</label><div><div class="md__narrow">' + input("labels") + '</div><p class="st-help">A comma separated list of labels that can be used to group/organize items.</p></div></div>' +
        '<div class="md__row"><label class="md__label">Location</label><div>' + input("location") + "</div></div>" +
        '<div class="wz-checks">' + check("enabled", "Enabled") + check("powerOn", "Automatically Power On VMs") + check("inventory", "Inventory Existing Instances") + "</div>" +
        '<p class="mp-err md__err" data-err hidden></p></div>' +
        '<div class="md__foot"><button type="button" class="st-btn" data-save>Save Changes</button></div></div>'
    );
    const err = box.querySelector("[data-err]");
    function save() {
      const get = (k) => box.querySelector('[data-f="' + k + '"]');
      const name = get("name").value.trim();
      let error = "";
      if (!name) error = "Name is required.";
      else if (server.clouds.some((c) => c.id !== cloud.id && c.name.toLowerCase() === name.toLowerCase())) error = "A cloud with this name already exists.";
      if (error) {
        err.textContent = error;
        err.hidden = false;
        return;
      }
      Object.assign(cloud, {
        name: name,
        code: get("code").value.trim(),
        labels: normalizeLabels(get("labels").value),
        location: get("location").value.trim(),
        enabled: get("enabled").checked,
        powerOn: get("powerOn").checked,
        inventory: get("inventory").checked
      });
      saveServer();
      closeLayer();
      load(tab, tab.hist[tab.i], "replace", true);
    }
    box.querySelector("[data-save]").addEventListener("click", save);
    box.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && event.target.type === "text") {
        event.preventDefault();
        save();
      }
    });
    box.querySelector('[data-f="name"]').focus();
  }

  function confirmDeleteCloud(tab, cloud) {
    const box = openModal(
      '<div class="md md--sm" role="alertdialog" aria-modal="true" aria-labelledby="mdTitle">' +
        '<div class="md__head"><h2 id="mdTitle">CONFIRMATION</h2><button type="button" class="md__x" aria-label="Close">' + ICON.close + "</button></div>" +
        '<div class="md__body"><p>Are you sure you want to delete the cloud <b>' + esc(cloud.name) + "</b>?</p></div>" +
        '<div class="md__foot md__foot--between"><button type="button" class="st-btn st-btn--ghost" data-cancel>Cancel</button>' +
        '<button type="button" class="st-btn st-btn--danger" data-confirm>Delete</button></div></div>'
    );
    box.querySelector("[data-cancel]").addEventListener("click", closeLayer);
    box.querySelector("[data-confirm]").addEventListener("click", () => {
      if (server.infrastructure.cluster && server.infrastructure.cluster.cloudId === cloud.id) {
        toast("This cloud contains the HVM cluster and cannot be deleted in this lab.");
        return;
      }
      server.clouds = server.clouds.filter((c) => c.id !== cloud.id);
      saveServer();
      closeLayer();
      load(tab, URL_CLOUDS, "push");
    });
    box.querySelector("[data-cancel]").focus();
  }

  function donut() {
    const total = server.clouds.length;
    if (!total) return '<p class="cl-nodata">NO DATA</p>';
    const R = 52;
    const C = 2 * Math.PI * R;
    let offset = 0;
    const colors = { private: "#4f6f93", vcenter: "#8aa6c4" };
    const parts = CLOUD_TYPES.map((t) => ({ t: t, n: server.clouds.filter((c) => c.type === t.id).length })).filter((p) => p.n);
    const arcs = parts.map((p) => {
      const len = (p.n / total) * C;
      const el = '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="' + colors[p.t.id] + '" stroke-width="26" stroke-dasharray="' + len + " " + (C - len) + '" stroke-dashoffset="' + -offset + '" transform="rotate(-90 70 70)"/>';
      offset += len;
      return el;
    }).join("");
    return '<div class="cl-donut"><svg viewBox="0 0 140 140" role="img" aria-label="Cloud types">' + arcs + '<circle cx="70" cy="70" r="30" fill="#fff"/><text x="70" y="76" text-anchor="middle" font-size="16" fill="#444">' + total + "</text></svg>" +
      '<ul class="cl-legend">' + parts.map((p) => '<li><i style="background:' + colors[p.t.id] + '"></i>' + p.t.label + "</li>").join("") + "</ul></div>";
  }

  function buildClouds(tab) {
    const el = morpheusShell(
      tab,
      "Infrastructure",
      "Clouds",
      '<div class="cl-cards"><section class="cl-card"><h3>' + G_ICON.pin + "Group Workloads</h3><p class=\"cl-nodata\">NO DATA</p></section>" +
        '<section class="cl-card"><h3>' + CL_ICON.donutHead + "Cloud Types</h3>" + donut() + "</section>" +
        '<section class="cl-card"><h3>' + CL_ICON.donutHead + "Cloud Workloads</h3><p class=\"cl-nodata\">NO DATA</p></section></div>" +
        '<div class="gr-card"><h2 class="gr-title">' + CL_ICON.donutHead + "<span>CLOUDS</span></h2>" +
        '<div class="gr-tools cl-tools"><div class="st-search cl-search"><input class="st-input" type="text" data-csearch placeholder="Search" aria-label="Search clouds" autocomplete="off"><button type="button" class="st-search__btn" aria-label="Search">' + G_ICON.search + "</button></div>" +
        '<div class="st-select cl-sel"><select data-cstatus aria-label="Status"><option>All</option><option>Enabled</option><option>Disabled</option></select>' + ICON.chevron + "</div>" +
        '<div class="st-select cl-sel"><select data-ctype aria-label="Cloud type"><option value="">Select Type</option>' + CLOUD_TYPES.map((t) => '<option value="' + t.id + '">' + t.label + "</option>").join("") + "</select>" + ICON.chevron + "</div>" +
        '<label class="gr-labels cl-labels"><input class="st-input" type="text" data-clabels placeholder="Labels" aria-label="Filter by labels" autocomplete="off"><span>' + G_ICON.list + "</span></label>" +
        '<span class="gr-spacer"></span><button type="button" class="st-btn gr-create" data-add>+Add</button>' +
        '<button type="button" class="st-btn gr-gear" data-na="Cloud actions" aria-label="Cloud actions">' + G_ICON.gear + ICON.chevron + "</button></div>" +
        '<div class="cl-head"><span>TYPE</span><span>NAME ' + ICON.chevron + "</span><span>LABELS</span><span>HOSTS</span><span>VMS</span><span>BARE METAL</span><span>STATUS</span><span></span></div>" +
        '<div data-cbody></div></div>'
    );
    const body = el.querySelector("[data-cbody]");
    const q = el.querySelector("[data-csearch]");
    const st = el.querySelector("[data-cstatus]");
    const ty = el.querySelector("[data-ctype]");
    const lb = el.querySelector("[data-clabels]");
    let timer = null;

    function render() {
      clearTimeout(timer);
      const text = q.value.trim().toLowerCase();
      const labels = lb.value.trim().toLowerCase();
      const rows = server.clouds
        .filter((c) =>
          (!text || c.name.toLowerCase().indexOf(text) >= 0) &&
          (st.value === "All" || (st.value === "Enabled") === c.enabled) &&
          (!ty.value || c.type === ty.value) &&
          (!labels || c.labels.toLowerCase().indexOf(labels) >= 0)
        )
        .sort((a, b) => a.name.localeCompare(b.name));
      body.innerHTML = rows.length
        ? rows.map((c) =>
            '<div class="cl-row"><span class="cl-type">' + typeOf(c).logo + '</span><a class="gr-link" href="#" data-go="' + URL_CLOUDS + "/" + c.id + '">' + esc(c.name) + "</a><span>" + esc(c.labels) +
            "</span><span>0</span><span>0</span><span>0</span><span>" + (isInitializing(c) ? "INITIALIZING -" : "OK") + '</span><span class="cl-acts"><button type="button" data-edit="' + c.id +
            '" aria-label="Edit cloud">' + CL_ICON.pencil + '</button><button type="button" data-del="' + c.id + '" aria-label="Delete cloud">' + CL_ICON.trash + "</button></span></div>"
          ).join("")
        : '<div class="gr-empty">' + G_ICON.info + "<p>No Data Available</p></div>";
      const pending = server.clouds.filter(isInitializing).map((c) => INIT_MS - (Date.now() - new Date(c.created).getTime()));
      if (pending.length) {
        timer = setTimeout(() => {
          if (tab.view === el) render();
        }, Math.min.apply(null, pending) + 50);
      }
    }

    [q, lb].forEach((i) => i.addEventListener("input", render));
    [st, ty].forEach((s) => s.addEventListener("change", render));
    el.querySelector(".cl-search .st-search__btn").addEventListener("click", render);
    el.querySelector("[data-add]").addEventListener("click", () => openCloudWizard(tab));
    body.addEventListener("click", (event) => {
      const link = event.target.closest("[data-go]");
      const edit = event.target.closest("[data-edit]");
      const del = event.target.closest("[data-del]");
      const find = (id) => server.clouds.filter((c) => String(c.id) === id)[0];
      if (link) {
        event.preventDefault();
        load(tab, link.dataset.go, "push");
      } else if (edit) openCloudEdit(tab, find(edit.dataset.edit));
      else if (del) confirmDeleteCloud(tab, find(del.dataset.del));
    });
    render();
    return el;
  }

  function gauge(label) {
    const R = 36;
    const C = 2 * Math.PI * R;
    const arc = C * 0.75;
    return '<div class="cd-gauge"><svg viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="' + R + '" fill="none" stroke="#e3e6ea" stroke-width="5" stroke-linecap="round" stroke-dasharray="' + arc + " " + C + '" transform="rotate(135 50 50)"/></svg>' +
      '<b>0%</b><span>' + label + "</span></div>";
  }

  function buildCloud(tab) {
    const c = server.clouds.filter((x) => x.id === tab.page.cloudId)[0];
    const cluster = server.infrastructure.cluster;
    const ownsCluster = cluster && cluster.cloudId === c.id;
    const counts = { Clusters: ownsCluster ? 1 : 0, Hosts: ownsCluster ? cluster.hosts.length : 0, VMs: ownsCluster ? 1 : 0, Containers: 0, "Bare Metal": 0 };
    const links = ownsCluster ? { Clusters: URL_VM + "/infrastructure/clusters", Hosts: URL_VM + "/infrastructure/clusters/1", VMs: URL_VM + "/infrastructure/compute" } : {};
    const ready = !isInitializing(c);
    const lastSync = fmtDate(c.synced || new Date(new Date(c.created).getTime() + 15000).toISOString());
    const tabs = ["Summary", "Clusters", "Hosts", "VMs", "Containers", "Bare Metal", "Wiki"];
    const kv = (k, v) => '<div><span>' + k + ":</span> " + v + "</div>";
    const el = morpheusShell(
      tab,
      "Infrastructure",
      "Clouds",
      '<nav class="gd-crumb" aria-label="Breadcrumb"><a href="#" data-go="' + URL_CLOUDS + '">Clouds</a><span>/</span><b>' + esc(c.name) + "</b></nav>" +
        '<div class="gd-card cd-card"><div class="gd-top"><h2><span class="cd-state">' + (ready ? CL_ICON.ok : CL_ICON.wait) + "</span>" + esc(c.name) + '</h2>' +
        '<div class="gd-btns"><button type="button" class="st-btn" data-edit>Edit</button><button type="button" class="st-btn" data-refresh>Refresh ' + ICON.chevron + '</button>' +
        '<button type="button" class="st-btn st-btn--danger" data-delete>Delete</button></div></div>' +
        '<div class="cd-meta"><span><b>Location:</b> ' + esc(c.location) + "</span><span><b>Last Sync:</b> " + lastSync + "</span><span><b>Sync Duration:</b> 37 ms</span></div>" +
        '<div class="cd-gauges">' + gauge("MAX CPU") + gauge("MEMORY") + gauge("STORAGE") + "</div>" +
        '<div class="cd-counts">' + ["Clusters", "Hosts", "VMs", "Containers", "Bare Metal"].map((l) => "<div><b>" + counts[l] + "</b><span>" + l + "</span></div>").join("") + "</div>" +
        '<div class="st-tabs gd-tabs cd-tabs" role="tablist">' + tabs.map((t) => '<button type="button" role="tab" class="' + (t === "Summary" ? "is-on" : "") + '"' + (t === "Summary" ? ' aria-selected="true"' : links[t] ? ' data-go="' + links[t] + '"' : ' data-na="' + t + '"') + ">" + t + "</button>").join("") + "</div>" +
        '<div class="cd-sum"><div class="cd-logo">' + typeOf(c).logo + "</div><div class=\"cd-kv\">" +
        kv("Appliance URL", "default") + kv("Time Zone", "default") + kv("Domain", "") +
        kv("Datacenter ID", "") + kv("Agent Install Mode", "cloudInit") + kv("Network Mode", "standard") +
        kv("Local Firewall", "off") + kv("Security Server", "off") + "</div></div></div>"
    );
    el.querySelector("[data-edit]").addEventListener("click", () => openCloudEdit(tab, c));
    el.querySelector("[data-delete]").addEventListener("click", () => confirmDeleteCloud(tab, c));
    el.querySelector("[data-refresh]").addEventListener("click", () => {
      c.synced = new Date().toISOString();
      saveServer();
      toast("Cloud refresh started.");
      load(tab, tab.hist[tab.i], "replace", true);
    });
    el.addEventListener("click", (event) => {
      const link = event.target.closest(".gd-crumb [data-go]");
      if (link) {
        event.preventDefault();
        load(tab, link.dataset.go, "push");
      }
    });
    if (!ready) {
      setTimeout(() => {
        if (tab.view === el) load(tab, tab.hist[tab.i], "replace", true);
      }, INIT_MS - (Date.now() - new Date(c.created).getTime()) + 50);
    }
    return el;
  }

  // ── Infrastructure > Groups ─────────────────────────────────────
  const G_ICON = {
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.300" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.500a6.500 6.500 0 0 0-6.500 6.500c0 4.600 6.500 12 6.500 12s6.500-7.400 6.500-12A6.500 6.500 0 0 0 12 2.500z"/><circle cx="12" cy="9" r="2.300"/></svg>',
    gear: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.140 12.940c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.030-1.580a.49.49 0 0 0 .12-.61l-1.920-3.320a.488.488 0 0 0-.59-.22l-2.390.96c-.5-.38-1.030-.7-1.620-.94l-.36-2.540a.484.484 0 0 0-.48-.41h-3.840c-.24 0-.43.17-.47.41l-.36 2.540c-.59.24-1.130.57-1.620.94l-2.390-.96c-.22-.08-.47 0-.59.22L2.740 8.870c-.12.21-.08.47.12.61l2.030 1.580c-.05.3-.09.63-.09.94s.02.64.07.94l-2.030 1.580a.49.49 0 0 0-.12.61l1.920 3.320c.12.22.37.29.59.22l2.390-.96c.5.38 1.030.7 1.620.94l.36 2.540c.05.24.24.41.48.41h3.840c.24 0 .44-.17.47-.41l.36-2.540c.59-.24 1.130-.56 1.620-.94l2.390.96c.22.08.47 0 .59-.22l1.920-3.320c.12-.22.07-.47-.12-.61l-2.010-1.580zM12 15.600c-1.980 0-3.600-1.620-3.600-3.600s1.620-3.600 3.600-3.600 3.600 1.620 3.600 3.600-1.620 3.600-3.600 3.600z"/></svg>',
    search: '<svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.800" stroke-linecap="round" aria-hidden="true"><circle cx="8.500" cy="8.500" r="5.500"/><path d="M13 13l4 4"/></svg>',
    list: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.800" stroke-linecap="round" aria-hidden="true"><path d="M3 5h14M3 10h14M3 15h14"/></svg>',
    info: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.300" aria-hidden="true"><circle cx="10" cy="10" r="8"/><path d="M10 9v5M10 6.200v.1" stroke-linecap="round"/></svg>'
  };

  // Morpheus prints dates as MM/DD/YYYY h:mm AM.
  function fmtDate(iso) {
    return new Date(iso)
      .toLocaleString("en-US", { month: "2-digit", day: "2-digit", year: "numeric", hour: "numeric", minute: "2-digit" })
      .replace(",", "");
  }

  function normalizeLabels(text) {
    return text.split(",").map((s) => s.trim()).filter(Boolean).join(", ");
  }

  // New and Edit share one dialog. A saved group refreshes the page behind it.
  function openGroupForm(tab, group) {
    const g = group || { name: "", code: "", labels: "", location: "" };
    const input = (k, extra) =>
      '<input class="st-input' + (extra || "") + '" type="text" data-f="' + k + '" value="' + esc(g[k]) + '" autocomplete="off" spellcheck="false">';
    const box = openModal(
      '<div class="md" role="dialog" aria-modal="true" aria-labelledby="mdTitle">' +
        '<div class="md__head"><h2 id="mdTitle">' + (group ? "EDIT GROUP" : "NEW GROUP") + '</h2><button type="button" class="md__x" aria-label="Close">' + ICON.close + "</button></div>" +
        '<div class="md__body"><h3 class="md__sec">Configuration</h3>' +
        '<div class="md__row"><label class="md__label">Name</label><div>' + input("name") + "</div></div>" +
        '<div class="md__row"><label class="md__label">Code</label><div>' + input("code") + "</div></div>" +
        '<div class="md__row"><label class="md__label">Labels</label><div><div class="md__narrow">' + input("labels") + '</div><p class="st-help">A comma separated list of labels that can be used to group/organize items.</p></div></div>' +
        '<div class="md__row"><label class="md__label">Location</label><div>' + input("location") + "</div></div>" +
        '<button type="button" class="md__adv" data-na="Advanced Options"><i>&#9654;</i>Advanced Options</button>' +
        '<p class="mp-err" data-err hidden></p></div>' +
        '<div class="md__foot"><button type="button" class="st-btn" data-savegroup>Save Changes</button></div></div>'
    );
    const err = box.querySelector("[data-err]");
    const val = (k) => box.querySelector('[data-f="' + k + '"]').value.trim();

    function save() {
      const name = val("name");
      let error = "";
      if (!name) error = "Name is required.";
      else if (server.groups.some((x) => (!group || x.id !== group.id) && x.name.toLowerCase() === name.toLowerCase())) {
        error = "A group with this name already exists.";
      }
      if (error) {
        err.textContent = error;
        err.hidden = false;
        box.querySelector('[data-f="name"]').focus();
        return;
      }
      const fields = { name: name, code: val("code"), labels: normalizeLabels(val("labels")), location: val("location") };
      if (group) {
        Object.assign(group, fields);
      } else {
        const nextGroupId = nextId("group");
        server.groups.push(Object.assign({ id: nextGroupId, created: new Date().toISOString() }, fields));
      }
      saveServer();
      closeLayer();
      load(tab, tab.hist[tab.i], "replace", true);
    }

    box.querySelector("[data-savegroup]").addEventListener("click", save);
    box.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && event.target.tagName === "INPUT") {
        event.preventDefault();
        save();
      }
    });
    box.querySelector('[data-f="name"]').focus();
    wirePage(box, tab);
  }

  function confirmDeleteGroup(tab, group) {
    const box = openModal(
      '<div class="md md--sm" role="alertdialog" aria-modal="true" aria-labelledby="mdTitle">' +
        '<div class="md__head"><h2 id="mdTitle">CONFIRMATION</h2><button type="button" class="md__x" aria-label="Close">' + ICON.close + "</button></div>" +
        '<div class="md__body"><p>Are you sure you want to delete the group <b>' + esc(group.name) + "</b>?</p>" +
        '<p class="mp-err md__err" data-err hidden></p></div>' +
        '<div class="md__foot md__foot--between"><button type="button" class="st-btn st-btn--ghost" data-cancel>Cancel</button>' +
        '<button type="button" class="st-btn st-btn--danger" data-confirm>Delete</button></div></div>'
    );
    box.querySelector("[data-cancel]").addEventListener("click", closeLayer);
    box.querySelector("[data-confirm]").addEventListener("click", () => {
      if (cloudsIn(group).length) {
        const err = box.querySelector("[data-err]");
        err.textContent = "This group still has clouds. Remove or move them before deleting it.";
        err.hidden = false;
        return;
      }
      server.groups = server.groups.filter((x) => x.id !== group.id);
      saveServer();
      closeLayer();
      load(tab, URL_GROUPS, "push");
    });
    box.querySelector("[data-cancel]").focus();
  }

  function buildGroups(tab) {
    const el = morpheusShell(
      tab,
      "Infrastructure",
      "Groups",
      '<div class="gr-card"><h2 class="gr-title">' + G_ICON.pin + "<span>GROUPS</span></h2>" +
        '<div class="gr-tools"><div class="st-search gr-search"><input class="st-input" type="text" data-gsearch placeholder="Search" aria-label="Search groups" autocomplete="off"><button type="button" class="st-search__btn" data-gsearchgo aria-label="Search">' + G_ICON.search + "</button></div>" +
        '<label class="gr-labels"><input class="st-input" type="text" data-glabels placeholder="Labels" aria-label="Filter by labels" autocomplete="off"><span>' + G_ICON.list + "</span></label>" +
        '<span class="gr-spacer"></span><button type="button" class="st-btn gr-create" data-create>+ Create</button>' +
        '<button type="button" class="st-btn gr-gear" data-na="Group actions" aria-label="Group actions">' + G_ICON.gear + ICON.chevron + "</button></div>" +
        '<div class="gr-head"><span>NAME ' + ICON.chevron + "</span><span>LOCATION</span><span>LABELS</span><span>CLOUDS</span><span>INSTANCES</span></div>" +
        '<div class="gr-body" data-gbody></div></div>'
    );
    const body = el.querySelector("[data-gbody]");
    const qInput = el.querySelector("[data-gsearch]");
    const lInput = el.querySelector("[data-glabels]");

    function render() {
      const q = qInput.value.trim().toLowerCase();
      const l = lInput.value.trim().toLowerCase();
      const rows = server.groups
        .filter((g) => (!q || g.name.toLowerCase().indexOf(q) >= 0) && (!l || g.labels.toLowerCase().indexOf(l) >= 0))
        .sort((a, b) => a.name.localeCompare(b.name));
      body.innerHTML = rows.length
        ? rows.map((g) =>
            '<div class="gr-row"><a class="gr-link" href="#" data-go="' + URL_GROUPS + "/" + g.id + '">' + esc(g.name) + "</a><span>" + esc(g.location) +
            "</span><span>" + esc(g.labels) + "</span><span>" + cloudsIn(g).length + "</span><span>0</span></div>"
          ).join("")
        : '<div class="gr-empty">' + G_ICON.info + "<p>No Data Available</p></div>";
    }

    qInput.addEventListener("input", render);
    lInput.addEventListener("input", render);
    el.querySelector("[data-gsearchgo]").addEventListener("click", render);
    body.addEventListener("click", (event) => {
      const link = event.target.closest("[data-go]");
      if (link) {
        event.preventDefault();
        load(tab, link.dataset.go, "push");
      }
    });
    el.querySelector("[data-create]").addEventListener("click", () => openGroupForm(tab, null));
    render();
    return el;
  }

  function buildGroup(tab) {
    const g = server.groups.filter((x) => x.id === tab.page.groupId)[0];
    const el = morpheusShell(
      tab,
      "Infrastructure",
      "Groups",
      '<nav class="gd-crumb" aria-label="Breadcrumb"><a href="#" data-go="' + URL_GROUPS + '">Groups</a><span>/</span><b>' + esc(g.name) + "</b></nav>" +
        '<div class="gd-card"><div class="gd-top"><h2>' + esc(g.name) + '</h2><div class="gd-btns"><button type="button" class="st-btn" data-edit>Edit</button>' +
        '<button type="button" class="st-btn st-btn--danger" data-delete>Delete</button></div></div>' +
        '<div class="gd-meta"><span>Clouds: ' + cloudsIn(g).length + "</span><span>Instances: 0</span><span>Location: " + esc(g.location) + "</span></div>" +
        '<div class="gd-created">Created: ' + fmtDate(g.created) + "</div>" +
        '<div class="st-tabs gd-tabs" role="tablist"><button type="button" role="tab" data-na="Instances">Instances</button>' +
        '<button type="button" role="tab" class="is-on" aria-selected="true">Clouds</button><button type="button" role="tab" data-na="Wiki">Wiki</button></div>' +
        '<div class="gd-tools"><div class="st-search gd-search"><input class="st-input" type="text" placeholder="Search" aria-label="Search clouds" autocomplete="off"><button type="button" class="st-search__btn" data-na="Search" aria-label="Search">' + G_ICON.search + "</button></div>" +
        '<span class="gr-spacer"></span><button type="button" class="st-btn gd-add" data-na="Add cloud">+ Add</button>' +
        '<button type="button" class="st-btn gr-gear" data-na="Cloud actions" aria-label="Cloud actions">' + G_ICON.gear + ICON.chevron + "</button></div>" +
        '<div class="gd-head"><span>TYPE</span><span>NAME</span><span>LOCATION ' + ICON.chevron + "</span></div>" +
        cloudsIn(g).map((c) =>
          '<div class="gd-row"><span>' + typeOf(c).logo + '</span><a class="gr-link" href="#" data-go="' + URL_CLOUDS + "/" + c.id + '">' + esc(c.name) + "</a><span>" + esc(c.location) + "</span></div>"
        ).join("") + "</div>"
    );
    el.addEventListener("click", (event) => {
      const link = event.target.closest(".gd-row [data-go]");
      if (link) {
        event.preventDefault();
        load(tab, link.dataset.go, "push");
      }
    });
    el.querySelector("[data-edit]").addEventListener("click", () => openGroupForm(tab, g));
    el.querySelector("[data-delete]").addEventListener("click", () => confirmDeleteGroup(tab, g));
    return el;
  }

  // ── Infrastructure > Network, Trust, Systems ──
  // These lists are empty on a fresh lab; every control that would add or change something is a placeholder.
  const IX_ICON = {
    systems: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.300" aria-hidden="true"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.500"/></svg>'
  };

  const ixSearch = (width, focus) =>
    '<div class="st-search ix-search" style="flex:0 0 ' + width + 'px"><input class="st-input" type="text" placeholder="Search" aria-label="Search" autocomplete="off"' + (focus ? " data-autofocus" : "") + '>' +
    '<button type="button" class="st-search__btn" aria-label="Search">' + G_ICON.search + "</button></div>";
  const ixLabels = (width) =>
    '<label class="gr-labels" style="flex:0 0 ' + width + 'px"><input class="st-input" type="text" placeholder="Labels" aria-label="Filter by labels" autocomplete="off"><span>' + G_ICON.list + "</span></label>";
  const ixSelect = (width, label, text, grey) =>
    '<div class="st-select ix-sel' + (grey ? " ix-sel--grey" : "") + '" style="flex:0 0 ' + width + 'px"><select aria-label="' + label + '"><option>' + text + "</option></select>" + ICON.chevron + "</div>";
  const ixBtn = (label, na, opts) =>
    '<button type="button" class="st-btn ix-btn' + (opts && opts.grey ? " ix-btn--grey" : "") + '" data-na="' + na + '"' + (opts && opts.aria ? ' aria-label="' + na + '"' : "") + ">" + label + "</button>";
  const ixAdd = (text, na) => ixBtn(text + " " + ICON.chevron, na);
  const ixGear = (na, caret) => ixBtn(G_ICON.gear + (caret ? ICON.chevron : ""), na, { aria: true });
  const ixTabs = (names) =>
    '<div class="st-tabs ix-tabs" role="tablist">' +
    names.map((n, i) => '<button type="button" role="tab"' + (i === 0 ? ' class="is-on" aria-selected="true"' : ' data-na="' + n + '"') + ">" + n + "</button>").join("") + "</div>";
  // A leading "*" marks the sorted column; "[]" is the select-all checkbox.
  const ixHead = (cols, widths) =>
    '<div class="ix-head" style="grid-template-columns:' + widths.map((w) => w + "fr").join(" ") + '">' +
    cols.map((c) =>
      c === "[]" ? '<span><i class="ix-chk"></i></span>'
        : c.charAt(0) === "*" ? '<span class="is-sort">' + c.slice(1) + ICON.chevron + "</span>"
        : "<span>" + c + "</span>"
    ).join("") + "</div>";
  const ixEmpty = (mod) => '<div class="ix-empty' + (mod ? " " + mod : "") + '">' + G_ICON.info + "<p>No Data Available</p></div>";
  const ixBlank = (height) => '<div class="ix-blank" style="height:' + height + 'px"></div>';

  const IX_BODY = {
    systems: () =>
      '<div class="ix-card"><h2 class="gr-title">' + IX_ICON.systems + "<span>SYSTEMS</span></h2>" +
      '<div class="ix-tools">' + ixSearch(258) + ixSelect(97, "Type", "All Types") + '<span class="gr-spacer"></span>' + ixBtn("Create", "Create system") + ixGear("System actions", false) + "</div>" +
      ixHead(["STATUS", "NAME", "TYPE", "LAYOUT", "ENABLED"], [152, 185, 139, 139, 63]) + ixEmpty() + "</div>",
    trust: () =>
      '<div class="ix-card">' + ixTabs(["Credentials", "Key Pairs"]) +
      '<div class="ix-tools">' + ixSearch(198, true) + ixSelect(173, "Type", "All Types") + '<span class="gr-spacer"></span>' + ixAdd("+ Add", "Add credential") + ixGear("Credential actions", true) + "</div>" +
      ixHead(["*NAME", "TYPE"], [1, 1]) + ixEmpty("ix-empty--lg") + "</div>",
    network: () =>
      '<div class="ix-card">' + ixTabs(["Networks", "Network Groups", "Routers", "IP Pools", "Floating IPs", "Domains", "Proxies", "Integrations"]) +
      '<div class="ix-tools ix-tools--stack">' + ixSearch(198, true) + ixLabels(196) + ixSelect(136, "Cloud", "", false) + ixSelect(175, "Type", "All Types") +
      '<div class="ix-right">' + ixGear("Network actions", true) + ixAdd("+ Add", "Add network") + "</div></div>" +
      ixHead(["STATUS", "*NAME", "LABELS", "TYPE", "GROUP", "CLOUD", "IPV4 CIDR", "POOL", "DHCP"], [81, 73, 83, 64, 69, 90, 103, 65, 80]) + ixBlank(90) + "</div>"
  };

  function buildInfra(tab) {
    const meta = INFRA_PAGES[tab.page.which];
    return morpheusShell(tab, "Infrastructure", meta.sub, IX_BODY[tab.page.which]());
  }

  const BUILDERS = {
    newtab: buildNewTab,
    cert: buildCert,
    loading: buildLoading,
    setup: buildSetup,
    login: buildLogin,
    dashboard: buildDashboard,
    settings: buildSettings,
    groups: buildGroups,
    group: buildGroup,
    clouds: buildClouds,
    cloud: buildCloud,
    infrastructure: infrastructure.build,
    infra: buildInfra,
    neterr: buildNetErr
  };

  view.addEventListener("click", (event) => {
    if (event.target.closest("a")) event.preventDefault();
  });

  view.addEventListener("mouseover", (event) => {
    const link = event.target.closest("[data-go], [data-status]");
    const text = link && (link.dataset.status || link.dataset.go);
    statusBubble.textContent = text || "";
    statusBubble.hidden = !text;
  });
  view.addEventListener("mouseleave", () => {
    statusBubble.hidden = true;
  });

  // ── Window chrome ───────────────────────────────────────────────
  function setTaskbarState() {
    taskbarBtn.classList.toggle("is-open", !win.hidden || win.dataset.minimized === "true" || launching);
    taskbarBtn.classList.toggle("is-active", !win.hidden);
  }

  function raise() {
    win.style.zIndex = "7";
    if (explorerWin) explorerWin.style.zIndex = "";
    if (mobaWin) mobaWin.style.zIndex = "";
  }

  function resetPosition() {
    win.style.left = win.style.top = win.style.right = win.style.bottom = "";
    win.style.width = win.style.height = "";
  }

  function openWindow() {
    win.hidden = false;
    delete win.dataset.minimized;
    raise();
    show(active);
    setTaskbarState();
  }

  // First launch takes a moment, like a real machine; restoring a minimized window is instant.
  function launch() {
    if (!win.hidden) {
      raise();
      return;
    }
    if (win.dataset.minimized === "true") {
      openWindow();
      return;
    }
    if (launching) return;
    launching = true;
    setTaskbarState();
    const done = () => {
      launching = false;
      openWindow();
    };
    if (window.VmeDesktop) window.VmeDesktop.busy(700, 1100, done);
    else done();
  }

  function minimizeWindow() {
    win.hidden = true;
    win.dataset.minimized = "true";
    setTaskbarState();
  }

  function resetBrowser() {
    tabs.forEach((tab) => {
      tab.token++;
      clearTimeout(tab.timer);
    });
    session.certAccepted = false;
    closeLayer();
    tabs = [createTab()];
    active = tabs[0];
    view.replaceChildren();
    renderBookmarks();
  }

  function closeWindow() {
    win.hidden = true;
    delete win.dataset.minimized;
    win.classList.remove("is-maximized");
    resetPosition();
    resetBrowser();
    setTaskbarState();
  }

  function toggleMaximize() {
    win.classList.toggle("is-maximized");
    resetPosition();
  }

  document.addEventListener("vme:open-chrome", launch);

  taskbarBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    if (win.hidden) launch();
    else minimizeWindow();
  });

  $("crMin").addEventListener("click", minimizeWindow);
  $("crMax").addEventListener("click", toggleMaximize);
  $("crClose").addEventListener("click", closeWindow);
  strip.addEventListener("dblclick", (event) => {
    if (!event.target.closest("button, .cr-tab")) toggleMaximize();
  });

  // Clicks inside the window must not reach the desktop (which clears icon selection).
  win.addEventListener("click", (event) => {
    event.stopPropagation();
    const startMenu = $("vmeStartMenu");
    if (startMenu && !startMenu.hidden) $("vmeStartBtn").click();
  });

  win.addEventListener("pointerdown", raise);
  [explorerWin, mobaWin].forEach((other) => {
    if (other) other.addEventListener("pointerdown", () => (win.style.zIndex = "4"));
  });

  strip.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || event.target.closest("button, .cr-tab") || win.classList.contains("is-maximized")) return;
    const deskRect = desktop.getBoundingClientRect();
    const rect = win.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    const width = rect.width;
    const height = rect.height;

    win.style.width = width + "px";
    win.style.height = height + "px";
    win.style.right = "auto";
    win.style.bottom = "auto";
    strip.setPointerCapture(event.pointerId);

    function move(e) {
      const maxLeft = deskRect.width - width;
      const maxTop = deskRect.height - 50 - height;
      win.style.left = Math.min(Math.max(e.clientX - deskRect.left - offsetX, 0), Math.max(maxLeft, 0)) + "px";
      win.style.top = Math.min(Math.max(e.clientY - deskRect.top - offsetY, 0), Math.max(maxTop, 0)) + "px";
    }

    function stop() {
      strip.removeEventListener("pointermove", move);
      strip.removeEventListener("pointerup", stop);
      strip.removeEventListener("pointercancel", stop);
    }

    strip.addEventListener("pointermove", move);
    strip.addEventListener("pointerup", stop);
    strip.addEventListener("pointercancel", stop);
  });

  resetBrowser();
})();
