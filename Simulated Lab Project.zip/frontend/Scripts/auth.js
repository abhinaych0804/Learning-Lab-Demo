(function () {
  const request = window.SimLabsApi.request;
  const $ = (id) => document.getElementById(id);

  const VERIFY_PATHS = {
    login: "/api/auth/login/verify",
    register: "/api/auth/register/verify"
  };
  const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const MANAGER_PANEL_URL = "Manager/index.html";

  let currentUser = null;
  let pendingOtp = null; // { pendingToken, purpose }
  let lastTrigger = null;
  const changeListeners = [];

  function showMessage(el, message) {
    el.textContent = message;
    el.hidden = false;
  }

  function hideMessage(el) {
    el.textContent = "";
    el.hidden = true;
  }

  async function withBusy(button, busyLabel, task) {
    const label = button.textContent;
    button.disabled = true;
    button.textContent = busyLabel;
    try {
      await task();
    } finally {
      button.disabled = false;
      button.textContent = label;
    }
  }

  // ── Session state ───────────────────────────────────────────────
  function setUser(user) {
    currentUser = user;
    $("loginOpenBtn").hidden = Boolean(user);
    $("userInfo").hidden = !user;
    $("usernameDisplay").textContent = user ? user.username : "";
    $("managerPanelBtn").hidden = !user || user.role !== "manager";
    closeDropdown();
    changeListeners.forEach((listener) => listener(user));
  }

  async function restoreSession() {
    const { ok, data } = await request("/api/me");
    setUser(ok ? data.user : null);
  }

  async function logout() {
    await request("/api/auth/logout", { method: "POST" });
    setUser(null);
  }

  function closeDropdown() {
    $("dropdownMenu").hidden = true;
    $("profileBtn").setAttribute("aria-expanded", "false");
  }

  function toggleDropdown() {
    const menu = $("dropdownMenu");
    menu.hidden = !menu.hidden;
    $("profileBtn").setAttribute("aria-expanded", String(!menu.hidden));
  }

  // ── Modal panels ────────────────────────────────────────────────
  function showPanel(panel) {
    $("loginForm").hidden = panel !== "login";
    $("registerForm").hidden = panel !== "register";
    $("managerRegisterForm").hidden = panel !== "manager";
    $("otpForm").hidden = panel !== "otp";
    $("authTabs").hidden = panel === "otp";

    const tabs = { login: "loginTab", register: "registerTab", manager: "managerRegisterTab" };
    Object.keys(tabs).forEach((name) => {
      const tab = $(tabs[name]);
      tab.classList.toggle("active", panel === name);
      tab.setAttribute("aria-selected", String(panel === name));
    });

    hideMessage($("loginError"));
    hideMessage($("registerError"));
    hideMessage($("mgrRegisterError"));
    hideMessage($("otpError"));
  }

  function showOtp(pendingToken, purpose, message) {
    pendingOtp = { pendingToken, purpose };
    $("otpStepMessage").textContent = message;
    $("otpCode").value = "";
    showPanel("otp");
    $("otpCode").focus();
  }

  function resetForms() {
    $("loginForm").reset();
    $("registerForm").reset();
    $("managerRegisterForm").reset();
    $("otpForm").reset();
    hideMessage($("loginNotice"));
    syncRegisterRules();
    pendingOtp = null;
  }

  function openModal(trigger) {
    lastTrigger = trigger || document.activeElement;
    resetForms();
    showPanel("login");
    $("overlay").classList.add("show");
    $("loginUsername").focus();
  }

  function closeModal() {
    $("overlay").classList.remove("show");
    resetForms();
    showPanel("login");
    if (lastTrigger && typeof lastTrigger.focus === "function") lastTrigger.focus();
  }

  function completeLogin(user) {
    lastTrigger = null;
    closeModal();
    setUser(user);
    if (user.role === "manager") {
      window.location.href = MANAGER_PANEL_URL;
    }
  }

  function completeRegistration(message) {
    resetForms();
    showPanel("login");
    showMessage($("loginNotice"), message || "Registration successful. Please log in.");
    $("loginUsername").focus();
  }

  // ── Registration rules ──────────────────────────────────────────
  function passwordState(password) {
    return {
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      special: /[^A-Za-z0-9]/.test(password),
      length: password.length >= 8
    };
  }

  function setRule(id, met) {
    $(id).classList.toggle("is-met", met);
  }

  function syncRegisterRules() {
    const password = $("password").value;
    const state = passwordState(password);

    setRule("ruleEmailValid", EMAIL_PATTERN.test($("email").value.trim()));
    setRule("ruleUppercase", state.uppercase);
    setRule("ruleLowercase", state.lowercase);
    setRule("ruleSpecial", state.special);
    setRule("ruleLength", state.length);
    setRule("rulePasswordMatch", password.length > 0 && password === $("confirmPassword").value);
  }

  // ── Form handlers ───────────────────────────────────────────────
  async function onLogin(event) {
    event.preventDefault();
    const errorEl = $("loginError");
    hideMessage(errorEl);
    hideMessage($("loginNotice"));

    const username = $("loginUsername").value.trim();
    const password = $("loginPassword").value;

    if (!username || !password) {
      showMessage(errorEl, "Enter your username and password.");
      return;
    }
    if (!$("loginConsent").checked) {
      showMessage(errorEl, "Please accept the Terms of Use and Privacy Policy.");
      return;
    }

    await withBusy(event.submitter || event.target.querySelector("button[type=submit]"), "Logging in...", async () => {
      const { ok, data } = await request("/api/auth/login", { method: "POST", body: { username, password } });

      if (!ok) {
        showMessage(errorEl, data.message || "Login failed. Please try again.");
        $("loginPassword").value = "";
        return;
      }

      if (!data.pendingToken) {
        completeLogin(data.user);
        return;
      }

      showOtp(data.pendingToken, "login", data.message || "Enter the 6-digit code sent to your email.");
    });
  }

  // Element ids for each sign-up form. Learner and manager forms share the same validation and request code.
  const REGISTER_FORMS = {
    learner: {
      fullName: "fullName", username: "username", email: "email", password: "password",
      confirm: "confirmPassword", consent: "registerConsent", error: "registerError"
    },
    manager: {
      fullName: "mgrFullName", username: "mgrUsername", email: "mgrEmail", password: "mgrPassword",
      confirm: "mgrConfirmPassword", consent: "mgrConsent", error: "mgrRegisterError"
    }
  };

  async function onRegister(event, accountType = "learner") {
    event.preventDefault();
    const ids = REGISTER_FORMS[accountType];
    const errorEl = $(ids.error);
    hideMessage(errorEl);

    const fullName = $(ids.fullName).value.trim();
    const username = $(ids.username).value.trim();
    const email = $(ids.email).value.trim();
    const password = $(ids.password).value;
    const managerEmail = accountType === "learner" ? $("managerEmail").value.trim() : "";

    const state = passwordState(password);
    let problem = "";

    if (!fullName || !username) {
      problem = "Enter your full name and a username.";
    } else if (!/^[A-Za-z0-9._-]{3,50}$/.test(username)) {
      problem = "Username must be 3-50 characters: letters, numbers, dot, underscore or hyphen.";
    } else if (!EMAIL_PATTERN.test(email)) {
      problem = "Enter a valid email address.";
    } else if (accountType === "learner" && !EMAIL_PATTERN.test(managerEmail)) {
      problem = "Enter your reporting manager's email address.";
    } else if (!(state.uppercase && state.lowercase && state.special && state.length)) {
      problem = "Password must include an uppercase letter, a lowercase letter, a special character and at least 8 characters.";
    } else if (password !== $(ids.confirm).value) {
      problem = "Passwords do not match.";
    } else if (!$(ids.consent).checked) {
      problem = "Please accept the Terms of Use and Privacy Policy.";
    }

    if (problem) {
      showMessage(errorEl, problem);
      return;
    }

    const body = { fullName, username, email, password, accountType };
    if (accountType === "learner") body.managerEmail = managerEmail;

    await withBusy(event.submitter || event.target.querySelector("button[type=submit]"), "Registering...", async () => {
      const { ok, data } = await request("/api/auth/register", { method: "POST", body });

      if (!ok) {
        showMessage(errorEl, data.message || "Registration failed. Please try again.");
        return;
      }

      if (!data.pendingToken) {
        completeRegistration(data.message);
        return;
      }

      showOtp(data.pendingToken, "register", data.message || `Enter the 6-digit code sent to ${email}.`);
    });
  }

  async function onOtp(event) {
    event.preventDefault();
    if (!pendingOtp) return;

    const errorEl = $("otpError");
    hideMessage(errorEl);

    const otp = $("otpCode").value.trim();
    if (!/^\d{6}$/.test(otp)) {
      showMessage(errorEl, "Enter the 6-digit verification code.");
      return;
    }

    await withBusy(event.submitter || event.target.querySelector("button[type=submit]"), "Verifying...", async () => {
      const { purpose, pendingToken } = pendingOtp;
      const { ok, data } = await request(VERIFY_PATHS[purpose], { method: "POST", body: { pendingToken, otp } });

      if (!ok) {
        showMessage(errorEl, data.message || "Verification failed. Please try again.");
        $("otpCode").value = "";
        return;
      }

      if (purpose === "login") {
        completeLogin(data.user);
      } else {
        completeRegistration(data.message);
      }
    });
  }

  // ── Wiring ──────────────────────────────────────────────────────
  function init() {
    $("loginOpenBtn").addEventListener("click", (event) => openModal(event.currentTarget));
    $("closeModalBtn").addEventListener("click", closeModal);
    $("overlay").addEventListener("click", (event) => {
      if (event.target === $("overlay")) closeModal();
    });
    document.addEventListener("keydown", (event) => {
      if (event.key !== "Escape") return;
      if ($("overlay").classList.contains("show")) closeModal();
      else closeDropdown();
    });

    $("loginTab").addEventListener("click", () => showPanel("login"));
    $("registerTab").addEventListener("click", () => {
      showPanel("register");
      syncRegisterRules();
    });
    $("managerRegisterTab").addEventListener("click", () => {
      showPanel("manager");
      syncRegisterRules();
    });
    $("otpBackBtn").addEventListener("click", () => {
      pendingOtp = null;
      showPanel("login");
    });

    $("loginForm").addEventListener("submit", onLogin);
    $("registerForm").addEventListener("submit", (event) => onRegister(event, "learner"));
    $("managerRegisterForm").addEventListener("submit", (event) => onRegister(event, "manager"));
    $("otpForm").addEventListener("submit", onOtp);

    ["email", "password", "confirmPassword"].forEach((id) => $(id).addEventListener("input", syncRegisterRules));
    ["loginUsername", "loginPassword"].forEach((id) =>
      $(id).addEventListener("input", () => hideMessage($("loginError")))
    );

    document.querySelectorAll(".disabled-nav-link").forEach((link) =>
      link.addEventListener("click", (event) => event.preventDefault())
    );

    $("profileBtn").addEventListener("click", toggleDropdown);
    $("managerPanelBtn").addEventListener("click", () => {
      window.location.href = MANAGER_PANEL_URL;
    });
    $("logoutBtn").addEventListener("click", logout);
    document.addEventListener("click", (event) => {
      if (!event.target.closest("#userInfo")) closeDropdown();
    });

    syncRegisterRules();
    return restoreSession();
  }

  window.SimLabsAuth = {
    init,
    openModal,
    getUser: () => currentUser,
    onChange: (listener) => changeListeners.push(listener)
  };
})();
