(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const desktop = $("vmeDesktop");
  const win = $("vmeExplorer");
  const taskbarBtn = $("vmeExplorerBtn");
  if (!desktop || !win || !taskbarBtn) return;

  const titlebar = $("xpTitlebar");
  const titleText = $("xpTitle");
  const ribbonEl = $("xpRibbon");
  const list = $("xpList");
  const pane = $("xpPane");
  const crumbsEl = $("xpCrumbs");
  const addrInput = $("xpAddressInput");
  const addrIcon = $("xpAddressIcon");
  const search = $("xpSearch");
  const statusEl = $("xpStatus");
  const menu = $("xpMenu");
  const dlg = $("xpDialog");
  const toastEl = $("vmeToast");

  function h(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null && text !== "") e.textContent = text;
    return e;
  }

  // ── Virtual file system ─────────────────────────────────────────
  let uid = 0;
  const registry = new Map();

  function N(name, props) {
    const n = Object.assign(
      { kind: "folder", icon: "folder", modified: "5/8/2021 1:20 AM", size: null, children: [], parent: null, hidden: false, system: false },
      props,
      { id: ++uid, name: name }
    );
    registry.set(n.id, n);
    return n;
  }

  function add(parent) {
    for (let i = 1; i < arguments.length; i++) {
      arguments[i].parent = parent;
      parent.children.push(arguments[i]);
    }
    return parent;
  }

  const D_SYS = "7/27/2026 10:41 AM";
  const lib = (name, icon) => N(name, { icon: icon, system: true, typeText: "System Folder", group: "Folders", modified: D_SYS });
  const l3d = lib("3D Objects", "3d");
  const lDesktop = lib("Desktop", "desktop");
  const lDocs = lib("Documents", "docs");
  const lDown = lib("Downloads", "download");
  const lMusic = lib("Music", "music");
  const lPics = lib("Pictures", "pictures");
  const lVideos = lib("Videos", "video");
  const libs = [l3d, lDesktop, lDocs, lDown, lMusic, lPics, lVideos];

  const shortcut = (name, icon, p) =>
    N(name, Object.assign({ kind: "shortcut", icon: icon, shortcut: true, size: 2, modified: "7/27/2026 10:52 AM" }, p));
  add(
    lDesktop,
    shortcut("Google Chrome", "chrome", { img: "../Images/ChromeIcon.webp", opens: "chrome" }),
    shortcut("MobaXterm", "moba", { img: "../Images/MobaXtermIcon.webp", opens: "moba" }),
    shortcut("Morpheus Management", "morpheus"),
    shortcut("This PC", "pc", { opens: "pc" })
  );

  const F = (name, modified, extra) => N(name, Object.assign({ modified: modified }, extra));
  const sysHidden = { hidden: true, system: true };

  const hpe = F("HPE", "7/27/2026 2:27 PM");
  add(
    hpe,
    F("Morpheus Manager Installer-win32-x64", "7/27/2026 2:27 PM"),
    N("HPE_VM_Essentials_SW_image_v9.0.1_0_S5Q83-11083.iso", { kind: "iso", icon: "iso", size: 3755648, modified: "7/27/2026 1:28 PM" })
  );

  const admin = F("Administrator", D_SYS);
  add(
    admin,
    ...libs.map((l) => N(l.name, { alias: l, icon: l.icon, typeText: "File folder", modified: l.modified, system: true }))
  );
  const pub = F("Public", "5/8/2021 1:20 AM");
  add(pub, F("Documents"), F("Downloads"), F("Music"), F("Pictures"), F("Videos"));
  const users = add(F("Users", D_SYS), admin, pub);

  const progFiles = add(F("Program Files", "7/27/2026 11:02 AM"), F("Common Files"), F("Windows Defender"), F("Windows NT"));
  const progFiles86 = add(F("Program Files (x86)", "5/8/2021 2:52 AM"), F("Common Files"), F("Microsoft"));
  const winDir = add(F("Windows", "7/27/2026 11:15 AM"), F("Fonts"), F("System32"), F("SysWOW64"), F("Temp"));

  const cDrive = N("Windows 2022 (C:)", {
    kind: "drive", icon: "drive-c", letter: "C", group: "Devices and drives", typeText: "Local Disk", system: true, modified: "", total: 127, free: 85.6
  });
  add(
    cDrive,
    F("$Recycle.Bin", D_SYS, sysHidden),
    hpe,
    F("PerfLogs", "5/8/2021 1:20 AM"),
    progFiles,
    progFiles86,
    F("ProgramData", D_SYS, sysHidden),
    F("System Volume Information", D_SYS, sysHidden),
    users,
    winDir
  );
  const dDrive = N("Local Disk (D:)", {
    kind: "drive", icon: "drive", letter: "D", group: "Devices and drives", typeText: "Local Disk", system: true, modified: "", total: 32, free: 31.9
  });

  const pc = N("This PC", { kind: "pc", icon: "pc", layout: "pc", system: true, modified: "" });
  add(pc, ...libs, cDrive, dDrive);

  const qa = N("Quick access", { kind: "qa", icon: "star", system: true, modified: "" });
  add(
    qa,
    ...[lDesktop, lDown, lDocs, lPics].map((l) =>
      N(l.name, { alias: l, icon: l.icon, group: "Frequent folders", typeText: "System Folder", modified: l.modified, system: true })
    )
  );
  const net = N("Network", { kind: "network", icon: "network", system: true, modified: "", emptyText: "No network computers were found." });
  const roots = [qa, pc, net];

  const real = (n) => n.alias || n;
  const isContainer = (n) => ["folder", "drive", "pc", "qa", "network"].indexOf(n.kind) >= 0;
  const isDir = (n) => isContainer(real(n));
  const hasExt = (n) => n.kind === "iso" || n.kind === "zip" || n.kind === "file";

  function chain(n) {
    const out = [];
    while (n) {
      out.unshift(n);
      n = n.parent;
    }
    return out;
  }

  // Read-only media (the mounted ISO) and anything inside it.
  const inRO = (n) => chain(n).some((x) => x.ro);
  const isDvd = (n) => chain(n).some((x) => x.optical);
  const writable = (n) => (n.kind === "folder" || n.kind === "drive") && !inRO(n);

  let dvd = null;
  function buildDvd() {
    const f = (name, mod, size, type, icon) => N(name, { kind: "file", icon: icon || "file", modified: mod, size: size, typeText: type, ro: true });
    const e = N("DVD Drive (E:)", {
      kind: "drive", icon: "dvd", letter: "E", group: "Devices and drives", typeText: "DVD Drive",
      system: true, modified: "", total: 3.58, free: 0, ro: true, optical: true
    });
    return add(
      e,
      f("hpe-vm_1.0.15-1_amd64.deb", "6/15/2026 4:57 PM", 33724, "DEB File"),
      f("hpe-vm-essentials-9.0.1-1.qcow2.gz", "7/21/2026 7:59 PM", 3463405, "GZ File"),
      f("Morpheus_Manager_Installer-1.0.0-x64.dmg", "7/21/2026 7:57 PM", 117340, "DMG File"),
      N("Morpheus_Manager_Installer-win32-x64-1.0.0.zip", { kind: "zip", icon: "zip", modified: "7/21/2026 7:57 PM", size: 141175, ro: true }),
      f("README", "7/21/2026 7:54 PM", 3, "File"),
      f("SHA256.txt", "7/21/2026 8:00 PM", 1, "Text Document", "txt")
    );
  }

  function pathText(n) {
    const ch = chain(n);
    const di = ch.findIndex((x) => x.kind === "drive");
    if (di >= 0) {
      const rest = ch.slice(di + 1).map((x) => x.name);
      return ch[di].letter + ":\\" + rest.join("\\");
    }
    return ch.map((x) => x.name).join("\\");
  }

  function resolvePath(text) {
    const t = text.trim().replace(/\//g, "\\").replace(/\\+$/, "");
    if (!t) return null;
    const parts = t.split("\\").filter(Boolean);
    const first = parts[0].toLowerCase();
    let cur = null;
    if (first === "this pc") cur = pc;
    else if (first === "quick access") cur = qa;
    else if (first === "network") cur = net;
    else if (/^[a-z]:$/.test(first)) cur = pc.children.find((c) => c.kind === "drive" && c.letter.toLowerCase() === first[0]);
    else cur = pc.children.find((c) => c.name.toLowerCase() === first);
    if (!cur) return null;
    for (const seg of parts.slice(1)) {
      const next = cur.children.find((c) => c.name.toLowerCase() === seg.toLowerCase());
      if (!next || !isDir(next)) return null;
      cur = real(next);
    }
    return cur;
  }

  function attached(n) {
    let x = n;
    while (x.parent) {
      if (x.parent.children.indexOf(x) < 0) return false;
      x = x.parent;
    }
    return roots.indexOf(x) >= 0;
  }

  function contains(ancestor, node) {
    for (let x = node; x; x = x.parent) if (x === ancestor) return true;
    return false;
  }

  function folderStats(n) {
    let size = 0, files = 0, folders = 0;
    n.children.forEach((c) => {
      if (c.alias) return;
      if (isContainer(c)) {
        folders++;
        const s = folderStats(c);
        size += s.size;
        files += s.files;
        folders += s.folders;
      } else {
        files++;
        size += c.size || 0;
      }
    });
    return { size: size, files: files, folders: folders };
  }

  function nowStr() {
    return new Date().toLocaleString("en-US", { year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "2-digit" }).replace(", ", " ");
  }

  function typeText(n) {
    return n.typeText || { folder: "File folder", iso: "Disc Image File", zip: "Compressed (zipped) Folder", shortcut: "Shortcut", drive: "Local Disk", file: "File" }[n.kind] || "";
  }

  const fmtKB = (kb) => kb.toLocaleString("en-US") + " KB";
  function fmtBig(kb) {
    if (kb >= 1048576) return (kb / 1048576).toFixed(2) + " GB";
    if (kb >= 1024) return (kb / 1024).toFixed(1) + " MB";
    return kb + " KB";
  }

  function uniqueName(parent, base, ext) {
    const taken = new Set(parent.children.map((c) => c.name.toLowerCase()));
    let name = base + ext;
    let i = 1;
    while (taken.has(name.toLowerCase())) {
      i++;
      name = base + " (" + i + ")" + ext;
    }
    return name;
  }

  function splitExt(n) {
    if (!hasExt(n)) return [n.name, ""];
    const m = n.name.match(/(\.[^.]+)$/);
    return m ? [n.name.slice(0, -m[1].length), m[1]] : [n.name, ""];
  }

  function cloneNode(n) {
    const c = N(n.name, Object.assign({}, n, { children: [], parent: null, system: false, ro: false, optical: false }));
    n.children.forEach((k) => add(c, cloneNode(k)));
    return c;
  }

  // ── Window state ────────────────────────────────────────────────
  let current, hist, hi, via, query, sortKey, sortDir, view, showExt, showHidden;
  let ribbonTab, ribbonOpen, ribbonPinned, anchor, renaming, clip, order, menuOwner, committing;
  const sel = new Set();

  function resetState() {
    current = qa;
    hist = [qa];
    hi = 0;
    via = null;
    query = "";
    search.value = "";
    sortKey = "name";
    sortDir = 1;
    view = "details";
    showExt = true;
    showHidden = false;
    sel.clear();
    anchor = null;
    renaming = null;
    order = [];
    menuOwner = null;
    ribbonTab = "home";
    ribbonOpen = false;
    ribbonPinned = false;
    win.classList.remove("xp-nopane");
  }

  const selNodes = () => Array.from(sel).map((id) => registry.get(id)).filter(Boolean);

  let toastTimer = null;
  function toast(message) {
    toastEl.textContent = message;
    toastEl.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("is-visible"), 2000);
  }

  // ── Icons ───────────────────────────────────────────────────────
  function icon(n, large) {
    const w = h("span", "xp-icon" + (large ? " xp-icon--lg" : ""));
    if (n.img) {
      const im = document.createElement("img");
      im.src = n.img;
      im.alt = "";
      w.appendChild(im);
    } else {
      w.innerHTML = '<svg><use href="#xp-' + n.icon + '"/></svg>';
    }
    if (n.shortcut) {
      w.insertAdjacentHTML("beforeend", '<svg class="xp-icon__arrow" viewBox="0 0 16 16"><path d="M3 13V6h2v3.6L10.6 4 12 5.4 6.4 11H10v2z" fill="#1f6fd1"/></svg>');
    }
    return w;
  }

  // ── Listing ─────────────────────────────────────────────────────
  const COLS = {
    normal: [["name", "Name"], ["date", "Date modified"], ["type", "Type"], ["size", "Size", true]],
    pc: [["name", "Name"], ["type", "Type"], ["total", "Total size", true], ["free", "Free space", true]]
  };

  function displayName(n) {
    if (!showExt && hasExt(n)) return n.name.replace(/\.[^.]+$/, "") || n.name;
    return n.name;
  }

  function sortValue(n, key) {
    switch (key) {
      case "date": return Date.parse(n.modified) || 0;
      case "type": return typeText(n).toLowerCase();
      case "size": return n.size == null ? -1 : n.size;
      case "total": return n.total || 0;
      case "free": return n.free || 0;
      default: return n.kind === "drive" ? n.letter : n.name.toLowerCase();
    }
  }

  function getItems() {
    const q = query.trim().toLowerCase();
    let items;
    if (q) {
      items = [];
      (function walk(n, depth) {
        n.children.forEach((c) => {
          if (c.alias || (!showHidden && c.hidden)) return;
          if (c.name.toLowerCase().indexOf(q) >= 0) items.push(c);
          if (c.children.length && depth < 8) walk(c, depth + 1);
        });
      })(current, 0);
    } else {
      items = current.children.filter((c) => showHidden || !c.hidden);
    }

    const cols = q ? "normal" : current.layout === "pc" ? "pc" : "normal";
    const key = COLS[cols].some((c) => c[0] === sortKey) ? sortKey : "name";
    items.sort((a, b) => {
      if (isDir(a) !== isDir(b)) return isDir(a) ? -1 : 1;
      const x = sortValue(a, key);
      const y = sortValue(b, key);
      let r = typeof x === "string" ? x.localeCompare(y, undefined, { numeric: true, sensitivity: "base" }) : x - y;
      if (r === 0 && key !== "name") r = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" });
      return r * sortDir;
    });

    const groups = [];
    const byLabel = new Map();
    items.forEach((n) => {
      const g = q ? "" : n.group || "";
      if (!byLabel.has(g)) {
        const o = { label: g, items: [] };
        byLabel.set(g, o);
        groups.push(o);
      }
      byLabel.get(g).items.push(n);
    });
    return { items: items, groups: groups, cols: cols, key: key };
  }

  function cellText(n, k) {
    switch (k) {
      case "date": return n.modified || "";
      case "type": return typeText(n);
      case "size": return n.size == null ? "" : fmtKB(n.size);
      case "total": return n.total ? n.total + " GB" : "";
      case "free": return n.free != null ? n.free + " GB" : "";
      default: return "";
    }
  }

  function renameInput(n) {
    const inp = h("input", "xp-rename");
    inp.type = "text";
    inp.value = n.name;
    inp.spellcheck = false;
    inp.setAttribute("aria-label", "Rename");
    inp.onkeydown = (e) => {
      e.stopPropagation();
      if (e.key === "Enter") commitRename(inp.value);
      else if (e.key === "Escape") {
        renaming = null;
        renderList();
        list.focus({ preventScroll: true });
      }
    };
    inp.onblur = () => commitRename(inp.value);
    return inp;
  }

  function renderList() {
    const old = list.querySelector(".xp-rename");
    if (old) old.onblur = null;

    if (loadTimer !== null) {
      order = [];
      list.textContent = "";
      list.appendChild(h("div", "xp-empty", "Working on it..."));
      statusEl.textContent = "";
      refreshControls();
      return;
    }

    const data = getItems();
    order = data.items.map((n) => n.id);
    list.textContent = "";
    list.classList.toggle("xp-list--icons", view === "icons");

    if (view === "details") {
      const head = h("div", "xp-list__head");
      COLS[data.cols].forEach((c) => {
        const cell = h("div", "xp-hcol xp-col--" + c[0] + (c[2] ? " xp-col--r" : ""), c[1]);
        cell.dataset.sort = c[0];
        if (c[0] === data.key) cell.appendChild(h("span", "xp-sort", sortDir === 1 ? "\u25B4" : "\u25BE"));
        head.appendChild(cell);
      });
      list.appendChild(head);
    }

    data.groups.forEach((g) => {
      if (g.label) list.appendChild(h("div", "xp-group", g.label + " (" + g.items.length + ")"));
      const grid = view === "icons" ? h("div", "xp-grid") : null;
      g.items.forEach((n) => {
        const cut = clip && clip.cut && clip.nodes.indexOf(n) >= 0 ? " is-cut" : "";
        const nameEl = renaming === n.id ? renameInput(n) : null;
        if (view === "icons") {
          const t = h("div", "xp-tile" + cut);
          t.dataset.id = n.id;
          t.title = displayName(n);
          t.appendChild(icon(n, true));
          if (nameEl) t.appendChild(nameEl);
          else t.appendChild(h("span", "xp-tile__name", displayName(n)));
          grid.appendChild(t);
        } else {
          const r = h("div", "xp-row" + cut);
          r.dataset.id = n.id;
          COLS[data.cols].forEach((c) => {
            const cell = h("div", "xp-col xp-col--" + c[0] + (c[2] ? " xp-col--r" : ""));
            if (c[0] === "name") {
              cell.appendChild(icon(n, false));
              cell.appendChild(nameEl || h("span", "", displayName(n)));
            } else {
              cell.textContent = cellText(n, c[0]);
            }
            r.appendChild(cell);
          });
          list.appendChild(r);
        }
      });
      if (grid) list.appendChild(grid);
    });

    if (!data.items.length) {
      list.appendChild(h("div", "xp-empty", query.trim() ? "No items match your search." : current.emptyText || "This folder is empty."));
    }

    const inp = list.querySelector(".xp-rename");
    if (inp) {
      inp.focus();
      const n = registry.get(renaming);
      const dot = n && hasExt(n) ? n.name.lastIndexOf(".") : -1;
      inp.setSelectionRange(0, dot > 0 ? dot : inp.value.length);
      inp.scrollIntoView({ block: "nearest" });
    }
    applySelection();
  }

  function applySelection() {
    list.querySelectorAll("[data-id]").forEach((el) => el.classList.toggle("is-selected", sel.has(+el.dataset.id)));
    const s = selNodes();
    let text;
    if (s.length) {
      text = s.length + (s.length === 1 ? " item selected" : " items selected");
      if (s.every((n) => n.size != null)) text += "\u00A0\u00A0\u00A0" + fmtBig(s.reduce((a, n) => a + n.size, 0));
    } else {
      text = order.length + (order.length === 1 ? " item" : " items");
    }
    statusEl.textContent = text;
    refreshControls();
  }

  // ── Navigation pane ─────────────────────────────────────────────
  function buildPane() {
    const p = [
      { n: qa },
      { n: lDesktop, l: 1, v: "qa", pin: 1 },
      { n: lDown, l: 1, v: "qa", pin: 1 },
      { n: lDocs, l: 1, v: "qa", pin: 1 },
      { n: lPics, l: 1, v: "qa", pin: 1 },
      { gap: 1 },
      { n: pc }
    ]
      .concat(libs.map((n) => ({ n: n, l: 1 })))
      .concat([{ n: cDrive, l: 1 }, { n: dDrive, l: 1 }]);
    if (dvd) p.push({ n: dvd, l: 1 });
    p.push({ gap: 1 }, { n: dDrive, v: "root" });
    if (dvd) p.push({ n: dvd, v: "root" });
    p.push({ gap: 1 }, { n: net });
    return p;
  }
  let PANE = buildPane();

  function activePane() {
    for (let node = current; node; node = node.parent) {
      const c = PANE.map((p, i) => [p, i]).filter((x) => x[0].n === node);
      if (c.length) return (c.find((x) => x[0].v && x[0].v === via) || c.find((x) => !x[0].v) || c[0])[1];
    }
    return -1;
  }

  function renderPane() {
    const top = pane.scrollTop;
    pane.textContent = "";
    const ul = h("ul");
    const act = activePane();
    PANE.forEach((p, i) => {
      if (p.gap) {
        ul.appendChild(h("li", "xp-pane__gap"));
        return;
      }
      const li = h("li", "xp-pane__item" + (p.l ? " xp-pane__item--l1" : "") + (i === act ? " is-current" : ""));
      li.dataset.i = i;
      li.tabIndex = 0;
      li.appendChild(icon(p.n, false));
      li.appendChild(h("span", "", p.n.name));
      if (p.pin) li.appendChild(h("span", "xp-pin", "\uD83D\uDCCC"));
      ul.appendChild(li);
    });
    pane.appendChild(ul);
    pane.scrollTop = top;
  }

  // ── Address bar ─────────────────────────────────────────────────
  function renderAddress() {
    addrIcon.textContent = "";
    addrIcon.appendChild(icon(current, false));
    crumbsEl.textContent = "";
    const ch = chain(current);
    ch.forEach((n, i) => {
      const arrow = h("button", "xp-crumb-arrow", "\u203A");
      arrow.type = "button";
      arrow.tabIndex = -1;
      arrow.setAttribute("data-menu-opener", "");
      arrow.addEventListener("click", () => {
        const entries = (i === 0 ? roots : ch[i - 1].children.filter((c) => isDir(c) && (showHidden || !c.hidden)).map(real)).map((r) => ({
          label: r.name, node: r, run: () => navigate(r)
        }));
        if (entries.length) showMenu(arrow, entries);
      });
      const crumb = h("button", "xp-crumb", n.name);
      crumb.type = "button";
      crumb.tabIndex = -1;
      crumb.addEventListener("click", () => navigate(n));
      crumbsEl.appendChild(arrow);
      crumbsEl.appendChild(crumb);
    });
  }

  function startAddressEdit() {
    crumbsEl.hidden = true;
    addrInput.hidden = false;
    addrInput.value = pathText(current);
    addrInput.focus();
    addrInput.select();
  }

  function endAddressEdit() {
    addrInput.hidden = true;
    crumbsEl.hidden = false;
  }

  crumbsEl.addEventListener("click", (e) => {
    if (e.target === crumbsEl) startAddressEdit();
  });
  addrIcon.addEventListener("click", startAddressEdit);
  addrInput.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Enter") {
      const text = addrInput.value;
      const target = resolvePath(text);
      endAddressEdit();
      if (target) navigate(target);
      else message("File Explorer", "Windows can't find '" + text + "'. Check the spelling and try again.");
    } else if (e.key === "Escape") {
      endAddressEdit();
    }
  });
  addrInput.addEventListener("blur", endAddressEdit);

  // ── Navigation ──────────────────────────────────────────────────
  // ── Simulated lag ───────────────────────────────────────────────
  const rand = (min, max) => min + Math.random() * (max - min);
  const lag = (min, max, done) => window.VmeDesktop.busy(min, max, done);
  let loadTimer = null;
  let launching = false;
  let mounting = false;

  function beginLoad(min, max) {
    clearTimeout(loadTimer);
    const ms = rand(min, max);
    const addr = $("xpAddress");
    addr.style.setProperty("--load-ms", Math.round(ms) + "ms");
    addr.classList.remove("is-loading");
    void addr.offsetWidth;
    addr.classList.add("is-loading");
    win.classList.add("is-loading");
    loadTimer = setTimeout(endLoad, ms);
  }

  function endLoad() {
    clearTimeout(loadTimer);
    loadTimer = null;
    $("xpAddress").classList.remove("is-loading");
    win.classList.remove("is-loading");
    renderList();
  }

  function renderAll() {
    titleText.textContent = current.name;
    win.setAttribute("aria-label", current.name + " - File Explorer");
    search.placeholder = "Search " + current.name;
    const dv = isDvd(current);
    $("xpManageTab").hidden = !dv;
    $("xpCtxHead").hidden = !dv;
    if (!dv && ribbonTab === "manage") ribbonTab = "home";
    renderAddress();
    renderPane();
    renderList();
    setRibbon(ribbonOpen);
  }

  function navigate(n, v, keepHistory) {
    n = real(n);
    if (!keepHistory && hist[hi] !== n) {
      hist.splice(hi + 1);
      hist.push(n);
      hi = hist.length - 1;
    }
    current = n;
    via = v || null;
    query = "";
    search.value = "";
    sel.clear();
    anchor = null;
    renaming = null;
    closeMenu();
    beginLoad(80, 220);
    renderAll();
    list.scrollTop = 0;
    document.dispatchEvent(new CustomEvent("vme:track", { detail: { name: "explorer-folder", path: pathText(n) } }));
  }

  function go(i) {
    if (i < 0 || i >= hist.length) return;
    hi = i;
    navigate(hist[i], null, true);
  }

  const goUp = () => current.parent && navigate(current.parent);

  function cleanHistory() {
    hist = hist.filter(attached);
    if (!hist.length) hist = [current];
    hi = Math.max(0, hist.lastIndexOf(current));
  }

  function openNode(n) {
    const via2 = n.alias && n.parent === qa ? "qa" : null;
    const r = real(n);
    if (isContainer(r)) navigate(r, via2);
    else if (r.kind === "shortcut" && r.opens === "pc") navigate(pc);
    else if (r.kind === "shortcut" && r.opens === "moba") document.dispatchEvent(new CustomEvent("vme:open-moba"));
    else if (r.kind === "shortcut" && r.opens === "chrome") document.dispatchEvent(new CustomEvent("vme:open-chrome"));
    else if (r.kind === "iso") openIso(r);
    else toast(displayName(r) + " is not available yet.");
  }

  // ── ISO mounting ────────────────────────────────────────────────
  const sec = $("xpSec");
  let skipWarning = false;

  function mountIso() {
    if (dvd) {
      navigate(dvd, "root");
      document.dispatchEvent(new CustomEvent("vme:track", { detail: { name: "iso-mounted" } }));
      return;
    }
    if (mounting) return;
    mounting = true;
    lag(600, 1000, () => {
      mounting = false;
      dvd = buildDvd();
      add(pc, dvd);
      PANE = buildPane();
      navigate(dvd, "root");
      document.dispatchEvent(new CustomEvent("vme:track", { detail: { name: "iso-mounted" } }));
    });
  }

  function openIso(n) {
    if (dvd || skipWarning) {
      mountIso();
      return;
    }
    if (!sec.hidden) return;
    lag(150, 300, () => {
      $("xpSecName").textContent = n.name.length > 45 ? "..." + n.name : n.name;
      $("xpSecType").textContent = typeText(n);
      $("xpSecFrom").textContent = pathText(n);
      $("xpSecAsk").checked = true;
      sec.hidden = false;
      $("xpSecCancel").focus();
    });
  }

  function closeSecurity() {
    sec.hidden = true;
    list.focus({ preventScroll: true });
  }

  function ejectDvd() {
    if (!dvd) return;
    const d = dvd;
    const inside = contains(d, current);
    d.parent.children.splice(d.parent.children.indexOf(d), 1);
    d.parent = null;
    dvd = null;
    PANE = buildPane();
    if (clip) clip.nodes = clip.nodes.filter(attached);
    if (inside) navigate(pc);
    cleanHistory();
    renderAll();
  }

  $("xpSecOpen").addEventListener("click", () => {
    if (!$("xpSecAsk").checked) skipWarning = true;
    closeSecurity();
    mountIso();
  });
  $("xpSecCancel").addEventListener("click", closeSecurity);
  $("xpSecClose").addEventListener("click", closeSecurity);
  $("xpSecRisk").addEventListener("click", (e) => {
    e.preventDefault();
    toast("Online help is not available in this lab.");
  });
  sec.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Escape") closeSecurity();
  });
  sec.addEventListener("click", (e) => e.stopPropagation());

  $("xpBack").addEventListener("click", () => go(hi - 1));
  $("xpFwd").addEventListener("click", () => go(hi + 1));
  $("xpUp").addEventListener("click", goUp);
  $("xpRefresh").addEventListener("click", () => {
    beginLoad(120, 250);
    renderList();
  });

  function recentMenu(anchorEl) {
    const seen = new Set();
    const entries = [];
    for (let i = hist.length - 1; i >= 0; i--) {
      if (seen.has(hist[i])) continue;
      seen.add(hist[i]);
      const idx = i;
      entries.push({ label: pathText(hist[i]), node: hist[i], run: () => go(idx) });
    }
    showMenu(anchorEl, entries);
  }
  $("xpRecent").addEventListener("click", (e) => recentMenu(e.currentTarget));
  $("xpAddressDrop").addEventListener("click", (e) => recentMenu(e.currentTarget));

  pane.addEventListener("click", (e) => {
    const li = e.target.closest(".xp-pane__item");
    if (!li) return;
    const p = PANE[+li.dataset.i];
    navigate(p.n, p.v);
  });
  pane.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target.classList.contains("xp-pane__item")) e.target.click();
  });

  search.addEventListener("input", () => {
    query = search.value;
    sel.clear();
    anchor = null;
    renderList();
  });

  // ── Selection and list events ───────────────────────────────────
  list.addEventListener("click", (e) => {
    if (e.target.closest(".xp-rename")) return;
    list.focus({ preventScroll: true });
    const head = e.target.closest(".xp-hcol");
    if (head) {
      setSort(head.dataset.sort, head.dataset.sort === sortKey ? -sortDir : 1);
      return;
    }
    const item = e.target.closest("[data-id]");
    if (!item) {
      sel.clear();
      anchor = null;
      applySelection();
      return;
    }
    const id = +item.dataset.id;
    if (e.shiftKey && anchor != null && order.indexOf(anchor) >= 0) {
      const a = order.indexOf(anchor);
      const b = order.indexOf(id);
      if (!(e.ctrlKey || e.metaKey)) sel.clear();
      for (let i = Math.min(a, b); i <= Math.max(a, b); i++) sel.add(order[i]);
    } else if (e.ctrlKey || e.metaKey) {
      if (sel.has(id)) sel.delete(id);
      else sel.add(id);
      anchor = id;
    } else {
      sel.clear();
      sel.add(id);
      anchor = id;
    }
    applySelection();
  });

  list.addEventListener("dblclick", (e) => {
    if (e.target.closest(".xp-rename")) return;
    const item = e.target.closest("[data-id]");
    if (item) openNode(registry.get(+item.dataset.id));
  });

  function setSort(key, dir) {
    sortKey = key;
    sortDir = dir || 1;
    renderList();
  }

  function setView(v) {
    view = v;
    renderList();
  }

  $("xpViewDetails").addEventListener("click", () => setView("details"));
  $("xpViewIcons").addEventListener("click", () => setView("icons"));

  // ── Rename, create, delete, copy, paste ─────────────────────────
  function commitRename(value) {
    if (renaming == null || committing) return;
    const n = registry.get(renaming);
    const v = value.trim();
    if (!n || !v || v === n.name) {
      renaming = null;
      renderList();
      return;
    }
    if (/[\\/:*?"<>|]/.test(v)) {
      committing = true;
      message("Rename", 'A file name can\'t contain any of the following characters:\n\\ / : * ? " < > |', () => {
        committing = false;
        renderList();
      });
      return;
    }
    if (n.parent.children.some((c) => c !== n && c.name.toLowerCase() === v.toLowerCase())) {
      committing = true;
      message("Rename " + (isDir(n) ? "Folder" : "File"), "The destination already has an item named '" + v + "'. Specify a different name.", () => {
        committing = false;
        renderList();
      });
      return;
    }
    n.name = v;
    n.modified = n.modified || nowStr();
    renaming = null;
    renderAll();
  }

  function startRename() {
    const s = selNodes();
    if (s.length !== 1) return;
    renaming = s[0].id;
    renderList();
  }

  function newFolder() {
    const n = N(uniqueName(current, "New folder", ""), { modified: nowStr() });
    add(current, n);
    sel.clear();
    sel.add(n.id);
    anchor = n.id;
    renaming = n.id;
    renderList();
  }

  function setClip(cut) {
    clip = { nodes: selNodes(), cut: cut };
    renderList();
  }

  function paste() {
    if (!clip || !writable(current)) return;
    const made = [];
    clip.nodes.forEach((n) => {
      if (!attached(n)) return;
      if (contains(n, current)) {
        toast("The destination folder is a subfolder of the source folder.");
        return;
      }
      const parts = splitExt(n);
      const clash = current.children.some((c) => c.name.toLowerCase() === n.name.toLowerCase());
      const name = clash ? uniqueName(current, parts[0] + " - Copy", parts[1]) : n.name;
      if (clip.cut) {
        if (n.parent === current) return;
        n.parent.children.splice(n.parent.children.indexOf(n), 1);
        n.name = name;
        add(current, n);
        made.push(n);
      } else {
        const c = cloneNode(n);
        c.name = name;
        add(current, c);
        made.push(c);
      }
    });
    if (clip.cut) {
      clip = null;
      cleanHistory();
    }
    sel.clear();
    made.forEach((n) => sel.add(n.id));
    anchor = made.length ? made[0].id : null;
    renderAll();
  }

  function askDelete() {
    const s = selNodes();
    if (!s.length) return;
    const one = s.length === 1;
    const kind = one && isDir(s[0]) ? "folder" : "file";
    confirmBox(
      one ? (kind === "folder" ? "Delete Folder" : "Delete File") : "Delete Multiple Items",
      one ? "Are you sure you want to permanently delete this " + kind + "?\n" + displayName(s[0]) : "Are you sure you want to permanently delete these " + s.length + " items?",
      () => {
        s.forEach((n) => {
          if (n.parent) n.parent.children.splice(n.parent.children.indexOf(n), 1);
          n.parent = null;
        });
        if (clip) clip.nodes = clip.nodes.filter(attached);
        sel.clear();
        anchor = null;
        cleanHistory();
        renderAll();
      }
    );
  }

  function zipSelection() {
    const s = selNodes();
    if (!s.length || !writable(current)) return;
    const base = s[0].kind === "folder" ? s[0].name : s[0].name.replace(/\.[^.]+$/, "");
    const total = s.reduce((a, n) => a + (isContainer(n) ? folderStats(n).size : n.size || 0), 0);
    const z = N(uniqueName(current, base, ".zip"), { kind: "zip", icon: "zip", size: Math.max(1, Math.round(total * 0.55)), modified: nowStr() });
    add(current, z);
    sel.clear();
    sel.add(z.id);
    anchor = z.id;
    renaming = z.id;
    renderList();
  }

  function showProperties() {
    const s = selNodes();
    const rows = [];
    const kv = (k, v) => rows.push([k, v]);
    if (s.length > 1) {
      kv("Selection", s.length + " items");
      kv("Location", pathText(current));
      if (s.every((n) => n.size != null)) kv("Size", fmtBig(s.reduce((a, n) => a + n.size, 0)));
      message("Properties", rows);
      return;
    }
    const n = s.length ? real(s[0]) : current;
    kv("Name", n.name);
    kv("Type", typeText(n) || n.name);
    if (n.parent) kv("Location", pathText(n.parent));
    if (n.kind === "drive") {
      kv("Capacity", n.total + " GB");
      kv("Free space", n.free + " GB");
    } else if (isContainer(n) && writable(n)) {
      const st = folderStats(n);
      kv("Size", fmtBig(st.size));
      kv("Contains", st.files + " Files, " + st.folders + " Folders");
    } else if (n.size != null) {
      kv("Size", fmtBig(n.size) + " (" + (n.size * 1024).toLocaleString("en-US") + " bytes)");
    }
    if (n.modified) kv("Modified", n.modified);
    if (n.hidden) kv("Attributes", "Hidden");
    message("Properties", rows);
  }

  // ── Dialogs and menus ───────────────────────────────────────────
  let dialogClose = null;

  function closeDialog() {
    dlg.hidden = true;
    const cb = dialogClose;
    dialogClose = null;
    if (cb) cb();
  }

  function openDialog(title, bodyBuilder, buttons, onClose) {
    $("xpDialogTitle").textContent = title;
    const body = $("xpDialogBody");
    body.textContent = "";
    bodyBuilder(body);
    const actions = $("xpDialogActions");
    actions.textContent = "";
    buttons.forEach((b, i) => {
      const btn = h("button", i === 0 ? "is-primary" : "", b[0]);
      btn.type = "button";
      btn.addEventListener("click", () => {
        dialogClose = onClose || null;
        const fn = b[1];
        dlg.hidden = true;
        const cb = dialogClose;
        dialogClose = null;
        if (fn) fn();
        if (cb) cb();
      });
      actions.appendChild(btn);
    });
    dialogClose = onClose || null;
    dlg.hidden = false;
    actions.firstChild.focus();
  }

  function message(title, content, onClose) {
    openDialog(
      title,
      (body) => {
        if (Array.isArray(content)) {
          content.forEach((r) => {
            const row = h("div", "xp-kv");
            row.appendChild(h("b", "", r[0]));
            row.appendChild(h("span", "", r[1]));
            body.appendChild(row);
          });
        } else {
          String(content).split("\n").forEach((line) => body.appendChild(h("div", "", line)));
        }
      },
      [["OK"]],
      onClose
    );
  }

  function confirmBox(title, text, onYes) {
    openDialog(
      title,
      (body) => text.split("\n").forEach((line) => body.appendChild(h("div", "", line))),
      [["Yes", onYes], ["No"]]
    );
  }

  dlg.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Escape") closeDialog();
  });

  function closeMenu() {
    menu.hidden = true;
    menuOwner = null;
  }

  function showMenu(anchorEl, entries) {
    if (!menu.hidden && menuOwner === anchorEl) {
      closeMenu();
      return;
    }
    menu.textContent = "";
    entries.forEach((en) => {
      const b = h("button");
      b.type = "button";
      b.setAttribute("role", "menuitem");
      if (en.node) b.appendChild(icon(en.node, false));
      b.appendChild(h("span", "", en.label));
      b.disabled = !!en.disabled;
      b.addEventListener("click", () => {
        closeMenu();
        if (en.run) en.run();
      });
      menu.appendChild(b);
    });
    menu.hidden = false;
    menuOwner = anchorEl;
    const wr = win.getBoundingClientRect();
    const ar = anchorEl.getBoundingClientRect();
    const left = Math.max(0, Math.min(ar.left - wr.left, wr.width - menu.offsetWidth - 4));
    menu.style.left = left + "px";
    menu.style.top = ar.bottom - wr.top + "px";
  }

  $("xpFileTab").addEventListener("click", (e) => {
    showMenu(e.currentTarget, [
      { label: "Open new window", run: () => toast("Opening a new window is not available yet.") },
      { label: "Open Windows PowerShell", run: () => toast("PowerShell is not available yet.") },
      { label: "Close", run: closeWindow }
    ]);
  });
  $("xpHelp").addEventListener("click", () => message("Windows Help", "Help is not available in this lab environment."));

  // ── Ribbon ──────────────────────────────────────────────────────
  const ICONS = {
    copy: "M8 8h11v13H8z M5 16V3h11",
    paste: "M6 5h12v16H6z M9 3h6v4H9z",
    cut: "M6 3a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z M6 16a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z M8 7.5l12 11 M8 17l12-11",
    delete: "M4 7h16 M9 7V4h6v3 M6 7l1 14h10l1-14 M10 11v6 M14 11v6",
    rename: "M4 20h4L19 9l-4-4L4 16z M13 7l4 4",
    newfolder: "M3 6h6l2 2h10v12H3z M12 11v6 M9 14h6",
    properties: "M5 3h14v18H5z M8 8h8 M8 12h8 M8 16h5",
    selectall: "M4 4h16v16H4z M8 12l3 3 5-6",
    selectnone: "M4 4h16v16H4z",
    invert: "M4 4h16v16H4z M4 4l16 16",
    share: "M18 5a2 2 0 1 0 .01 0z M6 10a2 2 0 1 0 .01 0z M18 19a2 2 0 1 0 .01 0z M8 11l8-5 M8 13l8 5",
    email: "M3 6h18v12H3z M3 7l9 7 9-7",
    zip: "M5 3h14v18H5z M12 3v6 M10 6h4 M10 9h4 M10 12h4 M10 15h4v4h-4z",
    print: "M7 8V3h10v5 M5 8h14v8H5z M7 14h10v7H7z",
    navpane: "M3 4h18v16H3z M9 4v16",
    icons: "M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z",
    details: "M4 6h2 M9 6h11 M4 12h2 M9 12h11 M4 18h2 M9 18h11",
    sortname: "M8 4v16 M4 16l4 4 4-4 M16 20V4 M12 8l4-4 4 4",
    sortdate: "M8 4v16 M4 16l4 4 4-4 M16 20V4 M12 8l4-4 4 4",
    sorttype: "M8 4v16 M4 16l4 4 4-4 M16 20V4 M12 8l4-4 4 4",
    sortsize: "M8 4v16 M4 16l4 4 4-4 M16 20V4 M12 8l4-4 4 4",
    exts: "M4 4h16v16H4z M8 12l3 3 5-6",
    hidden: "M4 4h16v16H4z M8 12l3 3 5-6",
    eject: "M5 15h14v4H5z M12 4l7 8H5z",
    autoplay: "M4 4h16v16H4z M10 8l6 4-6 4z"
  };

  const RIBBON = {
    home: [
      { label: "Clipboard", items: [["copy", "Copy"], ["paste", "Paste"], ["cut", "Cut"]] },
      { label: "Organize", items: [["delete", "Delete"], ["rename", "Rename"]] },
      { label: "New", items: [["newfolder", "New folder"]] },
      { label: "Open", items: [["properties", "Properties"]] },
      { label: "Select", small: true, items: [["selectall", "Select all"], ["selectnone", "Select none"], ["invert", "Invert selection"]] }
    ],
    share: [{ label: "Send", items: [["share", "Share"], ["email", "E-mail"], ["zip", "Zip"], ["print", "Print"]] }],
    manage: [{ label: "Media", items: [["eject", "Eject"], ["autoplay", "AutoPlay"], ["properties", "Properties"]] }],
    view: [
      { label: "Panes", items: [["navpane", "Navigation pane"]] },
      { label: "Layout", items: [["icons", "Large icons"], ["details", "Details"]] },
      { label: "Sort by", small: true, items: [["sortname", "Name"], ["sortdate", "Date modified"], ["sorttype", "Type"], ["sortsize", "Size"]] },
      { label: "Show/hide", small: true, items: [["exts", "File name extensions"], ["hidden", "Hidden items"]] }
    ]
  };

  const sortCmd = (cmd, key) => ({ chk: () => sortKey === key, run: () => setSort(key, 1), en: () => current.layout !== "pc" || key === "name" });
  const movable = () => selNodes().every((n) => !n.system && !inRO(n));
  const unavailable = (text) => ({ run: () => toast(text) });

  const cmds = {
    copy: { en: () => sel.size > 0 && selNodes().every((n) => !n.system), run: () => setClip(false) },
    cut: { en: () => sel.size > 0 && movable(), run: () => setClip(true) },
    paste: { en: () => !!clip && writable(current), run: paste },
    delete: { en: () => sel.size > 0 && movable(), run: askDelete },
    rename: { en: () => sel.size === 1 && movable(), run: startRename },
    newfolder: { en: () => writable(current) && !query.trim(), run: newFolder },
    properties: { run: showProperties },
    selectall: { en: () => order.length > 0, run: () => { order.forEach((id) => sel.add(id)); applySelection(); } },
    selectnone: { en: () => sel.size > 0, run: () => { sel.clear(); applySelection(); } },
    invert: { en: () => order.length > 0, run: () => { const keep = new Set(sel); sel.clear(); order.forEach((id) => { if (!keep.has(id)) sel.add(id); }); applySelection(); } },
    share: unavailable("Sharing is not available in this lab."),
    email: unavailable("E-mail is not available in this lab."),
    print: unavailable("No printer is installed."),
    zip: { en: () => sel.size > 0 && movable() && writable(current), run: zipSelection },
    navpane: { chk: () => !win.classList.contains("xp-nopane"), run: () => win.classList.toggle("xp-nopane") },
    icons: { chk: () => view === "icons", run: () => setView("icons") },
    details: { chk: () => view === "details", run: () => setView("details") },
    sortname: sortCmd("sortname", "name"),
    sortdate: sortCmd("sortdate", "date"),
    sorttype: sortCmd("sorttype", "type"),
    sortsize: sortCmd("sortsize", "size"),
    exts: { chk: () => showExt, run: () => { showExt = !showExt; renderList(); } },
    hidden: { chk: () => showHidden, run: () => { showHidden = !showHidden; renderAll(); } },
    eject: { en: () => isDvd(current), run: () => lag(200, 350, ejectDvd) },
    autoplay: { en: () => isDvd(current), run: () => toast("AutoPlay is not available in this lab.") }
  };

  const ribbonBtns = {};
  Object.keys(RIBBON).forEach((tab) => {
    const panel = h("div", "xp-rpanel");
    panel.dataset.tab = tab;
    RIBBON[tab].forEach((g) => {
      const grp = h("div", "xp-rgroup");
      const items = h("div", "xp-rgroup__items" + (g.small ? " xp-rgroup__items--small" : ""));
      g.items.forEach((it) => {
        const b = h("button", "xp-rbtn" + (g.small ? " xp-rbtn--small" : ""));
        b.type = "button";
        b.dataset.cmd = it[0];
        b.title = it[1];
        const checkbox = it[0] === "exts" || it[0] === "hidden";
        b.innerHTML = '<svg viewBox="0 0 24 24"><path d="' + (checkbox ? "M4 4h16v16H4z" : ICONS[it[0]]) + '"/>' + (checkbox ? '<path class="xp-chk" d="M8 12l3 3 5-6"/>' : "") + "</svg>";
        b.appendChild(h("span", "", it[1]));
        items.appendChild(b);
        ribbonBtns[it[0]] = b;
      });
      grp.appendChild(items);
      grp.appendChild(h("div", "xp-rgroup__label", g.label));
      panel.appendChild(grp);
    });
    ribbonEl.appendChild(panel);
  });

  function runCmd(id) {
    const c = cmds[id];
    if (c && (!c.en || c.en())) c.run();
  }

  ribbonEl.addEventListener("click", (e) => {
    const b = e.target.closest(".xp-rbtn");
    if (!b || b.disabled) return;
    runCmd(b.dataset.cmd);
    if (!ribbonPinned) setRibbon(false);
  });

  function setRibbon(open, tab) {
    if (tab) ribbonTab = tab;
    ribbonOpen = open;
    ribbonEl.hidden = !open;
    win.classList.toggle("has-ribbon", ribbonPinned);
    $("xpRibbonToggle").setAttribute("aria-expanded", String(ribbonPinned));
    win.querySelectorAll(".xp-tab[data-tab]").forEach((t) => t.classList.toggle("is-active", open && t.dataset.tab === ribbonTab));
    ribbonEl.querySelectorAll(".xp-rpanel").forEach((p) => p.classList.toggle("is-active", p.dataset.tab === ribbonTab));
  }

  win.querySelectorAll(".xp-tab[data-tab]").forEach((t) => {
    t.addEventListener("click", () => {
      if (ribbonOpen && ribbonTab === t.dataset.tab && !ribbonPinned) setRibbon(false);
      else setRibbon(true, t.dataset.tab);
    });
  });
  $("xpRibbonToggle").addEventListener("click", () => {
    ribbonPinned = !ribbonPinned;
    setRibbon(ribbonPinned);
  });

  function refreshControls() {
    Object.keys(ribbonBtns).forEach((id) => {
      const c = cmds[id];
      ribbonBtns[id].disabled = !!(c.en && !c.en());
      ribbonBtns[id].classList.toggle("is-on", !!(c.chk && c.chk()));
    });
    $("xpBack").disabled = hi <= 0;
    $("xpFwd").disabled = hi >= hist.length - 1;
    $("xpUp").disabled = !current.parent;
    $("xpViewDetails").classList.toggle("is-on", view === "details");
    $("xpViewIcons").classList.toggle("is-on", view === "icons");
  }

  // ── Window chrome ───────────────────────────────────────────────
  function setTaskbarState() {
    taskbarBtn.classList.toggle("is-open", !win.hidden || win.dataset.minimized === "true" || launching);
    taskbarBtn.classList.toggle("is-active", !win.hidden);
  }

  function resetPosition() {
    win.style.left = win.style.top = win.style.right = win.style.bottom = "";
    win.style.width = win.style.height = "";
  }

  function openWindow() {
    win.hidden = false;
    delete win.dataset.minimized;
    const mobaWin = $("vmeMoba");
    const chromeWin = $("vmeChrome");
    if (mobaWin) mobaWin.style.zIndex = "4";
    if (chromeWin) chromeWin.style.zIndex = "4";
    setTaskbarState();
    list.focus({ preventScroll: true });
  }

  // First launch takes a moment, like a real machine; restoring a minimized window is instant.
  function launchExplorer(then) {
    if (!win.hidden) {
      if (then) then();
      return;
    }
    if (win.dataset.minimized === "true") {
      openWindow();
      if (then) then();
      return;
    }
    if (launching) return;
    launching = true;
    setTaskbarState();
    lag(400, 700, () => {
      launching = false;
      openWindow();
      beginLoad(150, 300);
      renderList();
      if (then) then();
    });
  }

  function minimizeWindow() {
    win.hidden = true;
    win.dataset.minimized = "true";
    setTaskbarState();
  }

  function closeWindow() {
    win.hidden = true;
    delete win.dataset.minimized;
    win.classList.remove("is-maximized");
    resetPosition();
    closeMenu();
    dlg.hidden = true;
    sec.hidden = true;
    dialogClose = null;
    clearTimeout(loadTimer);
    loadTimer = null;
    $("xpAddress").classList.remove("is-loading");
    win.classList.remove("is-loading");
    resetState();
    renderAll();
    setTaskbarState();
  }

  function toggleMaximize() {
    win.classList.toggle("is-maximized");
    resetPosition();
  }

  taskbarBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    if (win.hidden) launchExplorer();
    else minimizeWindow();
  });

  document.addEventListener("vme:open-explorer", (e) => {
    launchExplorer(() => {
      if (e.detail && e.detail.target === "pc") navigate(pc);
    });
  });

  $("xpMin").addEventListener("click", minimizeWindow);
  $("xpMax").addEventListener("click", toggleMaximize);
  $("xpClose").addEventListener("click", closeWindow);
  titlebar.addEventListener("dblclick", (event) => {
    if (!event.target.closest("button")) toggleMaximize();
  });

  // Clicks inside the window must not reach the desktop (which clears icon selection).
  win.addEventListener("click", (event) => {
    event.stopPropagation();
    const startMenu = $("vmeStartMenu");
    if (startMenu && !startMenu.hidden) $("vmeStartBtn").click();
    if (!event.target.closest("[data-menu-opener], .xp-menu")) closeMenu();
    if (ribbonOpen && !ribbonPinned && !event.target.closest(".xp-ribbon, .xp-tabs")) setRibbon(false);
  });

  win.addEventListener("keydown", (e) => {
    if (!dlg.hidden) return;
    if (e.target.tagName === "INPUT") {
      if (e.key === "Escape" && e.target === search && search.value) {
        search.value = "";
        query = "";
        renderList();
      }
      return;
    }
    const ctrl = e.ctrlKey || e.metaKey;
    const k = e.key.toLowerCase();
    if (e.key === "Delete") runCmd("delete");
    else if (e.key === "F2") runCmd("rename");
    else if (ctrl && k === "a") { e.preventDefault(); runCmd("selectall"); }
    else if (ctrl && k === "c") runCmd("copy");
    else if (ctrl && k === "x") runCmd("cut");
    else if (ctrl && k === "v") runCmd("paste");
    else if (e.key === "Enter") {
      const s = selNodes();
      if (s.length === 1 && e.target === list) openNode(s[0]);
    } else if (e.key === "Backspace") { e.preventDefault(); goUp(); }
    else if (e.key === "Escape") closeMenu();
  });

  titlebar.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || event.target.closest("button") || win.classList.contains("is-maximized")) return;
    const deskRect = desktop.getBoundingClientRect();
    const rect = win.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    const width = rect.width;
    const height = rect.height;

    win.style.width = width + "px";
    win.style.height = height + "px";
    win.style.right = "auto";
    win.style.bottom = "auto";
    titlebar.setPointerCapture(event.pointerId);

    function move(e) {
      const maxLeft = deskRect.width - width;
      const maxTop = deskRect.height - 50 - height;
      win.style.left = Math.min(Math.max(e.clientX - deskRect.left - offsetX, 0), Math.max(maxLeft, 0)) + "px";
      win.style.top = Math.min(Math.max(e.clientY - deskRect.top - offsetY, 0), Math.max(maxTop, 0)) + "px";
    }

    function stop() {
      titlebar.removeEventListener("pointermove", move);
      titlebar.removeEventListener("pointerup", stop);
      titlebar.removeEventListener("pointercancel", stop);
    }

    titlebar.addEventListener("pointermove", move);
    titlebar.addEventListener("pointerup", stop);
    titlebar.addEventListener("pointercancel", stop);
  });

  resetState();
  renderAll();
})();
