// Learning mode for the VME labs.
// On the lab list it asks which mode to use; on a lab page (data-role="lab") it reads the choice.
(function () {
  "use strict";

  const MODES = [
    { id: "guided", title: "Guided Mode", text: "Step-by-step walkthrough with instant feedback on every action." },
    { id: "practice", title: "Practice Mode", text: "Troubleshoot an installation fault and configure the manager and HVM cluster. An expandable setup reference is available; your score covers diagnosis, resolution, efficiency and hints." }
  ];
  const script = document.currentScript;
  const isLab = !!script && script.dataset.role === "lab";

  if (isLab) {
    const mode = new URLSearchParams(window.location.search).get("mode");
    if (!MODES.some((m) => m.id === mode)) {
      window.location.replace("index.html");
      return;
    }
    document.documentElement.dataset.labMode = mode;
    // Ctrl+R and Ctrl+Shift+R would reload and lose the lab session.
    document.addEventListener("keydown", (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "r") event.preventDefault();
    });
    return;
  }

  let overlay = null;
  let opener = null;

  function close() {
    if (!overlay) return;
    overlay.remove();
    overlay = null;
    document.removeEventListener("keydown", onKey);
    if (opener) opener.focus();
  }

  function onKey(event) {
    if (event.key === "Escape") close();
  }

  function open(card) {
    close();
    opener = card;
    const href = card.getAttribute("href");
    const title = card.querySelector(".vme-card__title");

    overlay = document.createElement("div");
    overlay.className = "overlay show";
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) close();
    });

    const modal = document.createElement("div");
    modal.className = "modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "modeTitle");

    const x = document.createElement("button");
    x.type = "button";
    x.className = "close";
    x.setAttribute("aria-label", "Close");
    x.innerHTML = "&times;";
    x.addEventListener("click", close);

    const content = document.createElement("div");
    content.className = "modal-content";

    const heading = document.createElement("h2");
    heading.id = "modeTitle";
    heading.className = "modal__title";
    heading.textContent = "Choose a learning mode";

    const intro = document.createElement("p");
    intro.className = "modal__intro";
    intro.textContent = title ? title.textContent : "";

    const options = document.createElement("div");
    options.className = "mode-options";
    MODES.forEach((mode) => {
      const option = document.createElement("button");
      option.type = "button";
      option.className = "mode-option";
      const name = document.createElement("span");
      name.className = "mode-option__title";
      name.textContent = mode.title;
      const text = document.createElement("span");
      text.className = "mode-option__text";
      text.textContent = mode.text;
      option.append(name, text);
      option.addEventListener("click", () => {
        window.location.href = href + "?mode=" + mode.id;
      });
      options.appendChild(option);
    });

    content.append(heading, intro, options);
    modal.append(x, content);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", onKey);
    options.firstElementChild.focus();
  }

  document.querySelectorAll("a.vme-card").forEach((card) => {
    card.addEventListener("click", (event) => {
      event.preventDefault();
      open(card);
    });
  });
})();
