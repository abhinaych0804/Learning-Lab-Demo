/* Simulated bash shell and in-memory filesystem used by the MobaXterm SSH terminal. */
(function (root) {
  "use strict";

  const ERR = {
    ENOENT: "No such file or directory",
    ENOTDIR: "Not a directory",
    EACCES: "Permission denied",
    EEXIST: "File exists",
    EISDIR: "Is a directory",
    ENOTEMPTY: "Directory not empty",
    ELOOP: "Too many levels of symbolic links",
    EPERM: "Operation not permitted"
  };
  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const FULL_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const FULL_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const BASE_TIME = new Date(2026, 9, 15, 0, 5);
  const USERS = ["root", "daemon", "bin", "sys", "sync", "games", "man", "lp", "mail", "news", "uucp", "proxy", "www-data", "backup", "list", "irc", "nobody", "syslog", "sshd", "ubuntu"];
  const BUILTINS = ["cd", "export", "unset", "history", "exit", "logout", "type", "source", "alias", "read"];
  // Real tools that exist on the lab server but are not simulated here.
  const UNSUPPORTED = ["nano", "vi", "vim", "top", "htop", "man", "ssh", "scp", "systemctl", "journalctl", "ping", "curl", "wget", "ip", "ifconfig", "ss", "netstat", "docker", "python3", "tar", "gzip", "gunzip", "unzip", "zip", "dpkg", "service", "reboot", "shutdown"];

  const padL = (s, w) => String(s).padStart(w, " ");
  const padR = (s, w) => String(s).padEnd(w, " ");
  const pad2 = (n) => String(n).padStart(2, "0");
  const byteLen = (s) => (typeof TextEncoder !== "undefined" ? new TextEncoder().encode(s).length : s.length);
  const H = (f, ...keys) => keys.some((k) => f[k]);

  function human(bytes) {
    if (bytes < 1024) return String(bytes);
    let v = bytes / 1024;
    let unit = "K";
    for (const u of ["M", "G", "T"]) {
      if (v < 1024) break;
      v /= 1024;
      unit = u;
    }
    return (v < 10 ? (Math.ceil(v * 10) / 10).toFixed(1) : String(Math.ceil(v))) + unit;
  }

  function fmtDate(d, fmt) {
    const h12 = d.getHours() % 12 || 12;
    const ampm = d.getHours() < 12 ? "AM" : "PM";
    const tz = d.toLocaleTimeString("en-US", { timeZoneName: "short" }).split(" ").pop();
    if (!fmt) return DAYS[d.getDay()] + " " + MONTHS[d.getMonth()] + " " + padL(d.getDate(), 2) + " " + pad2(h12) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()) + " " + ampm + " " + tz + " " + d.getFullYear();
    const map = {
      Y: d.getFullYear(), y: pad2(d.getFullYear() % 100), m: pad2(d.getMonth() + 1), d: pad2(d.getDate()), e: padL(d.getDate(), 2),
      H: pad2(d.getHours()), I: pad2(h12), M: pad2(d.getMinutes()), S: pad2(d.getSeconds()), p: ampm,
      A: FULL_DAYS[d.getDay()], a: DAYS[d.getDay()], B: FULL_MONTHS[d.getMonth()], b: MONTHS[d.getMonth()], h: MONTHS[d.getMonth()],
      Z: tz, s: Math.floor(d.getTime() / 1000), n: "\n", t: "\t", "%": "%",
      F: d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()),
      T: pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()),
      D: pad2(d.getMonth() + 1) + "/" + pad2(d.getDate()) + "/" + pad2(d.getFullYear() % 100)
    };
    return fmt.replace(/%(.)/g, (m, c) => (c in map ? String(map[c]) : m));
  }

  function fmtLsDate(d) {
    const age = Date.now() - d.getTime();
    const day = MONTHS[d.getMonth()] + " " + padL(d.getDate(), 2);
    if (age > 182 * 864e5 || age < -864e5) return day + "  " + d.getFullYear();
    return day + " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes());
  }

  function modeStr(n) {
    let s = n.t === "d" ? "d" : n.t === "l" ? "l" : "-";
    const mode = n.t === "l" ? 0o777 : n.mode;
    for (let sh = 6; sh >= 0; sh -= 3) {
      const b = (mode >> sh) & 7;
      s += (b & 4 ? "r" : "-") + (b & 2 ? "w" : "-") + (b & 1 ? "x" : "-");
    }
    if (mode & 0o1000) s = s.slice(0, -1) + (mode & 1 ? "t" : "T");
    return s;
  }

  // ── Filesystem ─────────────────────────────────────────────────
  const mkDir = (owner, mode, m) => ({ t: "d", o: owner || "root", mode: mode == null ? 0o755 : mode, m: m || BASE_TIME, c: Object.create(null) });
  const mkFile = (data, owner, mode, m) => ({ t: "f", o: owner || "root", mode: mode == null ? 0o644 : mode, m: m || BASE_TIME, data: data || "" });
  const mkLink = (target) => ({ t: "l", o: "root", mode: 0o777, m: BASE_TIME, target: target });

  const PROFILE = '# ~/.profile: executed by the command interpreter for login shells.\n\nif [ -n "$BASH_VERSION" ]; then\n    if [ -f "$HOME/.bashrc" ]; then\n        . "$HOME/.bashrc"\n    fi\nfi\n';
  const BASHRC = "# ~/.bashrc: executed by bash(1) for non-login shells.\n\n# If not running interactively, don't do anything\ncase $- in\n    *i*) ;;\n      *) return;;\nesac\n\nHISTSIZE=1000\nHISTFILESIZE=2000\n\nalias ll='ls -alF'\nalias la='ls -A'\nalias l='ls -CF'\n";
  const OS_RELEASE = 'PRETTY_NAME="Ubuntu 24.04.4 LTS"\nNAME="Ubuntu"\nVERSION_ID="24.04"\nVERSION="24.04.4 LTS (Noble Numbat)"\nVERSION_CODENAME=noble\nID=ubuntu\nID_LIKE=debian\nHOME_URL="https://www.ubuntu.com/"\nSUPPORT_URL="https://help.ubuntu.com/"\nBUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"\nPRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"\nUBUNTU_CODENAME=noble\nLOGO=ubuntu-logo\n';

  function createFs(hostname) {
    const fs = { root: mkDir(), users: new Set(USERS) };

    fs.normalize = (p) => {
      const out = [];
      p.split("/").forEach((s) => {
        if (!s || s === ".") return;
        if (s === "..") out.pop();
        else out.push(s);
      });
      return "/" + out.join("/");
    };
    fs.resolve = (p, cwd) => fs.normalize(p.charAt(0) === "/" ? p : cwd + "/" + p);
    fs.split = (abs) => {
      const i = abs.lastIndexOf("/");
      return [i <= 0 ? "/" : abs.slice(0, i), abs.slice(i + 1)];
    };

    function walk(abs, follow, depth) {
      if ((depth || 0) > 8) return { err: "ELOOP" };
      const parts = abs.split("/").filter(Boolean);
      let node = fs.root;
      for (let i = 0; i < parts.length; i++) {
        if (node.t !== "d") return { err: "ENOTDIR" };
        const next = node.c[parts[i]];
        if (!next) return { err: "ENOENT" };
        if (next.t === "l" && (i < parts.length - 1 || follow)) {
          const base = "/" + parts.slice(0, i).join("/");
          const target = fs.resolve(next.target, base);
          return walk(fs.normalize(target + "/" + parts.slice(i + 1).join("/")), follow, (depth || 0) + 1);
        }
        node = next;
      }
      return { node: node };
    }
    fs.stat = (abs, follow) => walk(abs, follow !== false, 0);

    fs.parentOf = (abs) => {
      const sp = fs.split(abs);
      const r = walk(sp[0], true, 0);
      if (r.err) return { err: r.err };
      if (r.node.t !== "d") return { err: "ENOTDIR" };
      return { dir: r.node, name: sp[1] };
    };

    fs.canAccess = (node, user, bit) => {
      if (user === "root") return true;
      if (node.o === user) return !!((node.mode >> 6) & bit);
      return !!(node.mode & bit);
    };

    fs.create = (abs, node, user) => {
      const p = fs.parentOf(abs);
      if (p.err) return p.err;
      if (!p.name) return "EEXIST";
      if (p.dir.c[p.name]) return "EEXIST";
      if (!fs.canAccess(p.dir, user, 2)) return "EACCES";
      node.o = user;
      node.g = undefined;
      node.m = new Date();
      p.dir.c[p.name] = node;
      p.dir.m = new Date();
      return null;
    };

    fs.put = (abs, node) => {
      const parts = abs.split("/").filter(Boolean);
      let dir = fs.root;
      for (let i = 0; i < parts.length - 1; i++) {
        if (!dir.c[parts[i]]) dir.c[parts[i]] = mkDir();
        dir = dir.c[parts[i]];
      }
      dir.c[parts[parts.length - 1]] = node;
      return node;
    };

    fs.remove = (abs) => {
      const p = fs.parentOf(abs);
      if (p.err || !p.dir.c[p.name]) return;
      delete p.dir.c[p.name];
      p.dir.m = new Date();
    };

    fs.writeFile = (abs, text, append, user) => {
      if (abs === "/dev/null") return null;
      const r = walk(abs, true, 0);
      if (r.node) {
        if (r.node.t === "d") return "EISDIR";
        if (!fs.canAccess(r.node, user, 2)) return "EACCES";
        r.node.data = append ? r.node.data + text : text;
        r.node.size = undefined;
        r.node.m = new Date();
        return null;
      }
      if (r.err !== "ENOENT") return r.err;
      return fs.create(abs, mkFile(text), user);
    };

    fs.size = (n) => (n.t === "d" ? 4096 : n.t === "l" ? n.target.length : n.size != null ? n.size : byteLen(n.data));
    fs.names = (dir) => Object.keys(dir.c);

    fs.clone = (node, user) => {
      const c = Object.assign({}, node, { o: user, g: undefined, m: new Date() });
      if (node.t === "d") {
        c.c = Object.create(null);
        Object.keys(node.c).forEach((k) => {
          c.c[k] = fs.clone(node.c[k], user);
        });
      }
      return c;
    };

    fs.addUserHome = (user) => {
      if (user === "root" || fs.root.c.home.c[user]) return;
      fs.users.add(user);
      const home = mkDir(user, 0o750);
      home.m = new Date();
      ["bash_logout", "bashrc", "profile"].forEach((n) => {
        home.c["." + n] = mkFile(n === "bashrc" ? BASHRC : n === "profile" ? PROFILE : "", user, 0o644);
      });
      home.c[".cache"] = mkDir(user, 0o700);
      fs.root.c.home.c[user] = home;
      const pw = fs.stat("/etc/passwd").node;
      pw.data += user + ":x:1000:1000:" + user + ":/home/" + user + ":/bin/bash\n";
    };

    seedFs(fs, hostname || "manager");
    return fs;
  }

  function seedFs(fs, hostname) {
    ["bin", "boot", "dev", "etc", "home", "media", "mnt", "opt", "proc", "root", "run", "sbin", "snap", "srv", "sys", "tmp",
      "usr/bin", "usr/games", "usr/include", "usr/lib", "usr/local/bin", "usr/local/etc", "usr/local/share", "usr/sbin", "usr/share", "usr/src",
      "var/backups", "var/cache", "var/crash", "var/lib", "var/local", "var/log/apt", "var/mail", "var/opt", "var/spool", "var/tmp", "etc/apt", "etc/ssh", "etc/default"
    ].forEach((p) => fs.put("/" + p, mkDir()));
    fs.root.c.bin = mkLink("usr/bin");
    fs.root.c.sbin = mkLink("usr/sbin");
    fs.root.c.lib = mkLink("usr/lib");
    fs.root.c.tmp.mode = 0o1777;
    fs.root.c.var.c.tmp.mode = 0o1777;
    fs.root.c.root.mode = 0o700;
    fs.root.c.boot.m = fs.root.c.dev.m = new Date(2026, 5, 24, 14, 10);

    const home = fs.root.c.root;
    home.m = new Date(2026, 5, 24, 14, 15);
    home.c[".cache"] = mkDir("root", 0o700);
    home.c[".ssh"] = mkDir("root", 0o700);
    home.c.ta = mkDir("root", 0o755);
    home.c[".bash_history"] = mkFile("", "root", 0o600);
    home.c[".bashrc"] = mkFile(BASHRC);
    home.c[".profile"] = mkFile(PROFILE);
    home.c[".wget-hsts"] = mkFile("", "root", 0o644);

    const etc = {
      hostname: hostname + "\n",
      hosts: "127.0.0.1 localhost\n127.0.1.1 " + hostname + "\n\n# The following lines are desirable for IPv6 capable hosts\n::1     ip6-localhost ip6-loopback\nfe00::0 ip6-localnet\nff00::0 ip6-mcastprefix\nff02::1 ip6-allnodes\nff02::2 ip6-allrouters\n",
      "os-release": OS_RELEASE,
      issue: "Ubuntu 24.04.4 LTS \\n \\l\n\n",
      "lsb-release": "DISTRIB_ID=Ubuntu\nDISTRIB_RELEASE=24.04\nDISTRIB_CODENAME=noble\nDISTRIB_DESCRIPTION=\"Ubuntu 24.04.4 LTS\"\n",
      passwd: "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\nbin:x:2:2:bin:/bin:/usr/sbin/nologin\nsys:x:3:3:sys:/dev:/usr/sbin/nologin\nsync:x:4:65534:sync:/bin:/bin/sync\ngames:x:5:60:games:/usr/games:/usr/sbin/nologin\nwww-data:x:33:33:www-data:/var/www:/usr/sbin/nologin\nnobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin\nsyslog:x:101:102::/nonexistent:/usr/sbin/nologin\nsshd:x:105:65534::/run/sshd:/usr/sbin/nologin\n",
      group: "root:x:0:\ndaemon:x:1:\nsys:x:3:\nadm:x:4:syslog\nsudo:x:27:\nusers:x:100:\nnogroup:x:65534:\n",
      shells: "# /etc/shells: valid login shells\n/bin/sh\n/bin/bash\n/usr/bin/bash\n/bin/rbash\n/usr/bin/rbash\n/usr/bin/sh\n/bin/dash\n/usr/bin/dash\n",
      "resolv.conf": "nameserver 127.0.0.53\noptions edns0 trust-ad\nsearch .\n"
    };
    Object.keys(etc).forEach((k) => {
      fs.put("/etc/" + k, mkFile(etc[k]));
    });
    fs.put("/etc/shadow", mkFile("root:*:20000:0:99999:7:::\n", "root", 0o640));
    fs.put("/etc/ssh/sshd_config", mkFile("Include /etc/ssh/sshd_config.d/*.conf\nPort 22\nPermitRootLogin yes\nPasswordAuthentication yes\nUsePAM yes\n"));
    fs.put("/etc/apt/sources.list", mkFile("# See http://help.ubuntu.com/community/UpgradeNotes for how to upgrade to\n# newer versions of the distribution.\n"));

    const logs = {
      syslog: "Oct 15 00:05:01 " + hostname + " CRON[1822]: (root) CMD (command -v debian-sa1 > /dev/null && debian-sa1 1 1)\nOct 15 00:05:56 " + hostname + " sshd[1840]: Accepted password for root from 172.16.3.9 port 52214 ssh2\nOct 15 00:05:56 " + hostname + " systemd-logind[712]: New session 3 of user root.\n",
      "auth.log": "Oct 15 00:05:56 " + hostname + " sshd[1840]: Accepted password for root from 172.16.3.9 port 52214 ssh2\nOct 15 00:05:56 " + hostname + " sshd[1840]: pam_unix(sshd:session): session opened for user root(uid=0) by (uid=0)\n",
      "dpkg.log": "2026-06-24 14:08:11 status installed base-files:amd64 13ubuntu10.4\n",
      "cloud-init.log": "2026-06-24 14:07:02,114 - main.py[DEBUG]: Closing stdin.\n"
    };
    Object.keys(logs).forEach((k) => {
      fs.put("/var/log/" + k, mkFile(logs[k], "syslog", 0o640));
    });
    fs.put("/var/log/apt/history.log", mkFile("", "root", 0o644));

    ["null", "zero", "tty", "random", "urandom"].forEach((n) => fs.put("/dev/" + n, mkFile("", "root", 0o666)));
    fs.put("/proc/meminfo", mkFile("MemTotal:       16380920 kB\nMemFree:        13912344 kB\nMemAvailable:   15004212 kB\nBuffers:           98304 kB\nCached:          1131520 kB\nSwapTotal:             0 kB\nSwapFree:              0 kB\n"));
    fs.put("/proc/cpuinfo", mkFile("processor\t: 0\nvendor_id\t: GenuineIntel\nmodel name\t: Intel(R) Xeon(R) Gold 6338 CPU @ 2.00GHz\ncpu MHz\t\t: 2000.000\ncpu cores\t: 4\n"));

    const bins = Object.keys(COMMANDS).filter((n) => BUILTINS.indexOf(n) < 0).concat(UNSUPPORTED, ["apt", "apt-get", "sudo", "bash", "sh", "clear"]);
    bins.forEach((n, i) => {
      const bin = fs.put("/usr/bin/" + n, mkFile("", "root", 0o755));
      bin.size = 31000 + ((i * 7919) % 90000);
    });
  }

  // ── Parsing ────────────────────────────────────────────────────
  function matchParen(line, open) {
    let depth = 0;
    for (let i = open; i < line.length; i++) {
      if (line[i] === "(") depth++;
      else if (line[i] === ")" && --depth === 0) return i;
    }
    return -1;
  }

  function tokenize(line) {
    const toks = [];
    let word = null;
    let i = 0;
    const push = (s, q) => {
      if (!word) word = [];
      const last = word[word.length - 1];
      if (last && last.q === q) last.s += s;
      else word.push({ s: s, q: q });
    };
    const flush = () => {
      if (word) toks.push({ w: word });
      word = null;
    };
    const eof = (c) => ({ err: "unexpected EOF while looking for matching `" + c + "'" });
    while (i < line.length) {
      const c = line[i];
      if (c === " " || c === "\t") {
        flush();
        i++;
      } else if (c === "#" && !word) {
        break;
      } else if (c === "'") {
        const j = line.indexOf("'", i + 1);
        if (j < 0) return eof("'");
        push(line.slice(i + 1, j), "s");
        i = j + 1;
      } else if (c === '"') {
        i++;
        let buf = "";
        while (i < line.length && line[i] !== '"') {
          if (line[i] === "\\" && i + 1 < line.length && '$"\\`'.indexOf(line[i + 1]) >= 0) {
            push(buf, "d");
            buf = "";
            push(line[i + 1], "s");
            i += 2;
          } else if (line[i] === "$" && line[i + 1] === "(" && matchParen(line, i + 1) > 0) {
            const j = matchParen(line, i + 1);
            buf += line.slice(i, j + 1);
            i = j + 1;
          } else {
            buf += line[i++];
          }
        }
        if (i >= line.length) return eof('"');
        push(buf, "d");
        i++;
      } else if (c === "\\") {
        if (i + 1 < line.length) push(line[i + 1], "s");
        i += 2;
      } else if (c === "$" && line[i + 1] === "(") {
        const j = matchParen(line, i + 1);
        if (j < 0) return eof("(");
        push(line.slice(i, j + 1), "n");
        i = j + 1;
      } else if (c === "|" || c === "&" || c === ";" || c === ">" || c === "<" || ((c === "2" || c === "1") && line[i + 1] === ">" && !word)) {
        let op = c;
        if ((c === "2" || c === "1") && line[i + 1] === ">") {
          op = c + ">";
          i++;
        }
        const nx = line[i + 1];
        if ((c === "|" || c === "&") && nx === c) op = c + c, i++;
        else if (op === ">" && nx === ">") op = ">>", i++;
        else if (op === "2>" && nx === ">") op = "2>>", i++;
        else if (op === "2>" && nx === "&" && line[i + 2] === "1") op = "2>&1", i += 2;
        else if (op === "&" && nx === ">") op = "&>", i++;
        else if (op === "1>") op = nx === ">" ? (i++, ">>") : ">";
        i++;
        flush();
        toks.push({ op: op });
      } else {
        push(c, "n");
        i++;
      }
    }
    flush();
    return { toks: toks };
  }

  function parse(toks) {
    const items = [];
    const REDIR = ["<", ">", ">>", "2>", "2>>", "&>"];
    let cmd = { words: [], redirs: [] };
    let pipeline = [];
    let prevSep = null;
    let pending = null;
    let afterPipe = false;
    const syntax = (t) => ({ err: "syntax error near unexpected token `" + t + "'" });
    const endCmd = () => {
      if (!cmd.words.length && !cmd.redirs.length) return false;
      pipeline.push(cmd);
      cmd = { words: [], redirs: [] };
      afterPipe = false;
      return true;
    };
    for (let k = 0; k < toks.length; k++) {
      const t = toks[k];
      if (t.w) {
        afterPipe = false;
        if (pending) {
          cmd.redirs.push({ op: pending, w: t.w });
          pending = null;
        } else {
          cmd.words.push(t.w);
        }
        continue;
      }
      if (pending) return syntax(t.op);
      if (t.op === "|") {
        if (!endCmd()) return syntax("|");
        afterPipe = true;
      } else if (t.op === "2>&1") {
        cmd.redirs.push({ op: "2>&1" });
      } else if (REDIR.indexOf(t.op) >= 0) {
        pending = t.op;
      } else {
        if (afterPipe) return syntax(t.op);
        const had = endCmd();
        if (!had && !pipeline.length) return syntax(t.op);
        items.push({ pipeline: pipeline, sep: prevSep });
        pipeline = [];
        prevSep = t.op === "&" ? ";" : t.op;
      }
    }
    if (pending) return syntax("newline");
    if (afterPipe) return { err: "syntax error: unexpected end of file" };
    endCmd();
    if (pipeline.length) items.push({ pipeline: pipeline, sep: prevSep });
    else if (prevSep === "&&" || prevSep === "||") return { err: "syntax error: unexpected end of file" };
    return { items: items };
  }

  // ── Expansion ──────────────────────────────────────────────────
  function getVar(st, name) {
    if (name === "?") return String(st.code);
    if (name === "PWD") return st.cwd;
    if (name === "OLDPWD") return st.oldpwd;
    if (name === "HOME") return st.home;
    if (name === "USER" || name === "LOGNAME") return st.user;
    if (name === "HOSTNAME") return st.host;
    if (Object.prototype.hasOwnProperty.call(st.vars, name)) return st.vars[name];
    return Object.prototype.hasOwnProperty.call(st.env, name) ? st.env[name] : "";
  }

  function expandVars(str, st, sub) {
    let out = "";
    for (let i = 0; i < str.length; i++) {
      const ch = str[i];
      const nx = str[i + 1];
      if (ch !== "$") {
        out += ch;
      } else if (nx === "(") {
        const j = matchParen(str, i + 1);
        out += sub(str.slice(i + 2, j)).replace(/\n+$/, "");
        i = j;
      } else if (nx === "{") {
        const j = str.indexOf("}", i);
        out += getVar(st, str.slice(i + 2, j));
        i = j;
      } else if (nx === "?") {
        out += getVar(st, "?");
        i++;
      } else if (nx && /[A-Za-z_]/.test(nx)) {
        const name = /^[A-Za-z_]\w*/.exec(str.slice(i + 1))[0];
        out += getVar(st, name);
        i += name.length;
      } else {
        out += "$";
      }
    }
    return out;
  }

  function globRegex(seg) {
    let re = "";
    for (let i = 0; i < seg.length; i++) {
      const c = seg[i];
      if (c === "\\") re += seg[++i].replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");
      else if (c === "*") re += "[^/]*";
      else if (c === "?") re += "[^/]";
      else if (c === "[") {
        const j = seg.indexOf("]", i + 2);
        if (j < 0) re += "\\[";
        else {
          re += "[" + seg.slice(i + 1, j).replace(/^!/, "^") + "]";
          i = j;
        }
      } else re += c.replace(/[.+^${}()|\]/]/g, "\\$&");
    }
    return new RegExp("^" + re + "$");
  }

  function hasMeta(pat) {
    return /(^|[^\\])[*?[]/.test(pat);
  }

  function globExpand(pat, st, fs) {
    const abs = pat.charAt(0) === "/";
    const segs = pat.split("/").filter((s) => s !== "");
    let cands = [abs ? "/" : ""];
    for (let si = 0; si < segs.length; si++) {
      const seg = segs[si];
      const next = [];
      cands.forEach((base) => {
        const dirAbs = fs.resolve(base || ".", st.cwd);
        if (!hasMeta(seg)) {
          const lit = seg.replace(/\\(.)/g, "$1");
          const p = base + (base && base !== "/" ? "/" : "") + lit;
          if (fs.stat(fs.resolve(p, st.cwd), false).node) next.push(p);
          return;
        }
        const r = fs.stat(dirAbs);
        if (!r.node || r.node.t !== "d") return;
        const re = globRegex(seg);
        fs.names(r.node).sort().forEach((n) => {
          if (n.charAt(0) === "." && seg.charAt(0) !== ".") return;
          if (re.test(n)) next.push(base + (base && base !== "/" ? "/" : "") + n);
        });
      });
      cands = next;
    }
    return cands;
  }

  function expandWord(word, st, fs, sub) {
    let text = "";
    let pat = "";
    let meta = false;
    word.forEach((p, idx) => {
      let s = p.s;
      if (p.q !== "s") s = expandVars(s, st, sub);
      if (p.q === "n" && idx === 0 && /^~(\/|$)/.test(s)) s = st.home + s.slice(1);
      text += s;
      if (p.q === "n") {
        if (/[*?[]/.test(s)) meta = true;
        pat += s;
      } else {
        pat += s.replace(/[*?[\\]/g, "\\$&");
      }
    });
    if (meta) {
      const hits = globExpand(pat, st, fs);
      if (hits.length) return hits;
    }
    return [text];
  }

  // ── Output chunks ──────────────────────────────────────────────
  const flatten = (chunks) => chunks.map((c) => (Array.isArray(c) ? c[0] : c && c.clear ? "" : c)).join("");

  function errMsg(code) {
    return ERR[code] || code;
  }

  function opts(args, valued) {
    const f = {};
    const rest = [];
    for (let i = 0; i < args.length; i++) {
      const a = args[i];
      if (a === "--") {
        rest.push.apply(rest, args.slice(i + 1));
        break;
      }
      if (a.length > 1 && a[0] === "-" && a[1] !== "-") {
        for (let k = 1; k < a.length; k++) {
          const ch = a[k];
          if (valued.indexOf(ch) >= 0) {
            f[ch] = a.slice(k + 1) || args[++i] || "";
            break;
          }
          f[ch] = true;
        }
      } else if (a.slice(0, 2) === "--") {
        const eq = a.indexOf("=");
        if (eq > 0) f[a.slice(2, eq)] = a.slice(eq + 1);
        else f[a.slice(2)] = true;
      } else {
        rest.push(a);
      }
    }
    return { f: f, rest: rest };
  }

  const COMMANDS = Object.create(null);
  const C = COMMANDS;

  function inputText(io) {
    return io.in == null ? "" : io.in;
  }

  // Reads each file operand (or stdin) and calls fn(text, label); returns an exit code.
  function eachInput(names, io, cx, cmd, fn) {
    let code = 0;
    if (!names.length) {
      fn(inputText(io), "-");
      return 0;
    }
    names.forEach((n) => {
      if (n === "-") {
        fn(inputText(io), "-");
        return;
      }
      const r = cx.fs.stat(cx.abs(n));
      if (r.err) {
        io.err(cmd + ": " + n + ": " + errMsg(r.err) + "\n");
        code = 1;
      } else if (r.node.t === "d") {
        io.err(cmd + ": " + n + ": " + ERR.EISDIR + "\n");
        code = 1;
      } else if (!cx.fs.canAccess(r.node, cx.user, 4)) {
        io.err(cmd + ": " + n + ": " + ERR.EACCES + "\n");
        code = 1;
      } else {
        fn(r.node.data, n);
      }
    });
    return code;
  }

  const splitLines = (text) => (text ? text.match(/[^\n]*\n|[^\n]+$/g) || [] : []);

  // ── Navigation ─────────────────────────────────────────────────
  C.pwd = (args, io, cx) => {
    io.out(cx.st.cwd + "\n");
    return 0;
  };

  C.cd = (args, io, cx) => {
    const st = cx.st;
    const arg = args.filter((a) => a[0] !== "-" || a === "-")[0];
    let target = arg === undefined ? st.home : arg;
    if (target === "-") {
      target = st.oldpwd;
      io.out(target + "\n");
    }
    const abs = cx.abs(target);
    const r = cx.fs.stat(abs);
    if (r.err || r.node.t !== "d") {
      io.err("bash: cd: " + arg + ": " + errMsg(r.err || "ENOTDIR") + "\n");
      return 1;
    }
    if (!cx.fs.canAccess(r.node, cx.user, 1)) {
      io.err("bash: cd: " + arg + ": " + ERR.EACCES + "\n");
      return 1;
    }
    st.oldpwd = st.cwd;
    st.cwd = abs;
    return 0;
  };

  // ── ls ─────────────────────────────────────────────────────────
  function lsName(e, o, io) {
    let text = e.name;
    let cls = null;
    const n = e.node;
    if (io.tty) cls = n.t === "d" ? "t-dir" : n.t === "l" ? "t-lnk" : n.mode & 0o111 ? "t-exe" : null;
    if (o.classify) text += n.t === "d" ? "/" : n.t === "l" ? "@" : n.mode & 0o111 ? "*" : "";
    return { text: text, cls: cls };
  }

  function lsEmit(list, o, io, cx) {
    if (!list.length) return;
    const emitName = (nm) => io.out(nm.text, nm.cls);
    if (o.long) {
      const rows = list.map((e) => {
        const n = e.node;
        const size = cx.fs.size(n);
        return {
          e: e,
          perm: modeStr(n),
          links: String(n.t === "d" ? 2 + cx.fs.names(n).filter((k) => n.c[k].t === "d").length : 1),
          own: n.o,
          grp: n.g || n.o,
          size: o.human ? human(size) : String(size),
          date: fmtLsDate(n.m)
        };
      });
      const w = (k) => Math.max.apply(null, rows.map((r) => r[k].length));
      const wl = w("links");
      const wo = w("own");
      const wg = w("grp");
      const ws = w("size");
      rows.forEach((r) => {
        io.out(r.perm + " " + padL(r.links, wl) + " " + padR(r.own, wo) + " " + padR(r.grp, wg) + " " + padL(r.size, ws) + " " + r.date + " ");
        emitName(lsName(r.e, o, io));
        if (r.e.node.t === "l") io.out(" -> " + r.e.node.target);
        io.out("\n");
      });
      return;
    }
    const items = list.map((e) => lsName(e, o, io));
    if (!io.tty || o.one) {
      items.forEach((nm) => {
        emitName(nm);
        io.out("\n");
      });
      return;
    }
    const width = Math.max(20, cx.st.cols || 80);
    const n = items.length;
    let rowsN = n;
    let widths = [];
    for (let c = n; c >= 1; c--) {
      const rn = Math.ceil(n / c);
      const cn = Math.ceil(n / rn);
      const ws = [];
      for (let k = 0; k < cn; k++) {
        let m = 0;
        for (let r = 0; r < rn && k * rn + r < n; r++) m = Math.max(m, items[k * rn + r].text.length);
        ws.push(m + 2);
      }
      const total = ws.reduce((a, b) => a + b, 0) - 2;
      if (total <= width || cn === 1) {
        rowsN = rn;
        widths = ws;
        break;
      }
    }
    for (let r = 0; r < rowsN; r++) {
      for (let k = 0; k < widths.length; k++) {
        const idx = k * rowsN + r;
        if (idx >= n) break;
        emitName(items[idx]);
        if (idx + rowsN < n) io.out(" ".repeat(widths[k] - items[idx].text.length));
      }
      io.out("\n");
    }
  }

  C.ls = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const o = {
      all: H(f, "a", "all"), almost: H(f, "A", "almost-all"), long: H(f, "l"), human: H(f, "h", "human-readable"), one: H(f, "1"),
      dirOnly: H(f, "d", "directory"), rec: H(f, "R", "recursive"), rev: H(f, "r", "reverse"), time: H(f, "t"), bySize: H(f, "S"), classify: H(f, "F")
    };
    const fs = cx.fs;
    const sorter = (list) => {
      const key = (n) => n.replace(/^\.+/, "").toLowerCase();
      list.sort((a, b) => {
        if (o.bySize) return fs.size(b.node) - fs.size(a.node);
        if (o.time) return b.node.m - a.node.m;
        const ka = key(a.name);
        const kb = key(b.name);
        return ka < kb ? -1 : ka > kb ? 1 : a.name < b.name ? -1 : 1;
      });
      if (o.rev) list.reverse();
      return list;
    };
    const targets = rest.length ? rest : ["."];
    let code = 0;
    const files = [];
    const dirs = [];
    targets.forEach((t) => {
      const r = fs.stat(cx.abs(t), !o.long);
      if (r.err) {
        io.err("ls: cannot access '" + t + "': " + errMsg(r.err) + "\n");
        code = 2;
      } else if (r.node.t === "d" && !o.dirOnly) dirs.push({ name: t, abs: cx.abs(t), node: r.node });
      else files.push({ name: t, node: r.node });
    });
    let first = true;
    if (files.length) {
      lsEmit(sorter(files), o, io, cx);
      first = false;
    }
    const listDir = (d, label, header) => {
      if (!fs.canAccess(d.node, cx.user, 4)) {
        io.err("ls: cannot open directory '" + label + "': " + ERR.EACCES + "\n");
        code = 2;
        return;
      }
      if (!first) io.out("\n");
      first = false;
      if (header) io.out(label + ":\n");
      const entries = [];
      if (o.all) {
        entries.push({ name: ".", node: d.node });
        const pr = fs.stat(fs.split(d.abs)[0]);
        entries.push({ name: "..", node: pr.node || d.node });
      }
      fs.names(d.node).forEach((n) => {
        if (n.charAt(0) === "." && !o.all && !o.almost) return;
        entries.push({ name: n, node: d.node.c[n] });
      });
      sorter(entries);
      if (o.long) {
        const blocks = entries.reduce((a, e) => a + (e.node.t === "d" ? 4 : Math.ceil(fs.size(e.node) / 4096) * 4), 0);
        io.out("total " + (o.human ? blocks + "K" : blocks) + "\n");
      }
      lsEmit(entries, o, io, cx);
      if (o.rec) {
        entries.forEach((e) => {
          if (e.node.t === "d" && e.name !== "." && e.name !== "..") listDir({ node: e.node, abs: fs.normalize(d.abs + "/" + e.name) }, label.replace(/\/$/, "") + "/" + e.name, true);
        });
      }
    };
    dirs.sort((a, b) => (a.name < b.name ? -1 : 1)).forEach((d) => listDir(d, d.name, targets.length > 1 || o.rec));
    return code;
  };

  // ── Create / remove ────────────────────────────────────────────
  C.mkdir = (args, io, cx) => {
    const { f, rest } = opts(args, "m");
    if (!rest.length) {
      io.err("mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
      return 1;
    }
    const parents = H(f, "p", "parents");
    const verbose = H(f, "v", "verbose");
    let code = 0;
    rest.forEach((a) => {
      const abs = cx.abs(a);
      const made = (p, label) => {
        if (verbose) io.out("mkdir: created directory '" + label + "'\n");
      };
      if (parents) {
        const parts = abs.split("/").filter(Boolean);
        let cur = "";
        for (let i = 0; i < parts.length; i++) {
          cur += "/" + parts[i];
          const r = cx.fs.stat(cur);
          if (r.node) {
            if (r.node.t !== "d") {
              io.err("mkdir: cannot create directory '" + a + "': " + ERR.ENOTDIR + "\n");
              code = 1;
              return;
            }
            continue;
          }
          const err = cx.fs.create(cur, mkDir(), cx.user);
          if (err) {
            io.err("mkdir: cannot create directory '" + a + "': " + errMsg(err) + "\n");
            code = 1;
            return;
          }
          made(cur, i === parts.length - 1 ? a : cur);
        }
        return;
      }
      const err = cx.fs.create(abs, mkDir(), cx.user);
      if (err) {
        io.err("mkdir: cannot create directory '" + a + "': " + errMsg(err) + "\n");
        code = 1;
      } else {
        made(abs, a);
        if (/^[0-7]{3,4}$/.test(f.m || "")) cx.fs.stat(abs).node.mode = parseInt(f.m, 8);
      }
    });
    return code;
  };

  C.rmdir = (args, io, cx) => {
    const { rest } = opts(args, "");
    if (!rest.length) {
      io.err("rmdir: missing operand\nTry 'rmdir --help' for more information.\n");
      return 1;
    }
    let code = 0;
    rest.forEach((a) => {
      const abs = cx.abs(a);
      const r = cx.fs.stat(abs, false);
      let err = r.err;
      if (!err && r.node.t !== "d") err = "ENOTDIR";
      else if (!err && cx.fs.names(r.node).length) err = "ENOTEMPTY";
      else if (!err && !cx.fs.canAccess(cx.fs.parentOf(abs).dir, cx.user, 2)) err = "EACCES";
      if (err) {
        io.err("rmdir: failed to remove '" + a + "': " + errMsg(err) + "\n");
        code = 1;
      } else {
        cx.fs.remove(abs);
      }
    });
    return code;
  };

  C.touch = (args, io, cx) => {
    const { f, rest } = opts(args, "dtr");
    if (!rest.length) {
      io.err("touch: missing file operand\nTry 'touch --help' for more information.\n");
      return 1;
    }
    let code = 0;
    rest.forEach((a) => {
      const abs = cx.abs(a);
      const r = cx.fs.stat(abs);
      if (r.node) {
        if (!cx.fs.canAccess(r.node, cx.user, 2)) {
          io.err("touch: cannot touch '" + a + "': " + ERR.EACCES + "\n");
          code = 1;
        } else r.node.m = new Date();
      } else if (!H(f, "c", "no-create")) {
        const err = cx.fs.create(abs, mkFile(""), cx.user);
        if (err) {
          io.err("touch: cannot touch '" + a + "': " + errMsg(err) + "\n");
          code = 1;
        }
      }
    });
    return code;
  };

  C.rm = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const rec = H(f, "r", "R", "recursive");
    const force = H(f, "f", "force");
    const verbose = H(f, "v", "verbose");
    if (!rest.length) {
      if (!force) io.err("rm: missing operand\nTry 'rm --help' for more information.\n");
      return force ? 0 : 1;
    }
    let code = 0;
    const del = (abs, label) => {
      if ((cx.fs.domains || []).some((d) => {
        const disk = "/var/morpheus/kvm/local/" + d.name + ".qcow2";
        return abs === disk || (rec && disk.indexOf(abs + "/") === 0);
      })) {
        io.err("rm: cannot remove '" + label + "': disk belongs to a defined VM; undefine the failed VM first\n");
        code = 1;
        return;
      }
      const r = cx.fs.stat(abs, false);
      if (r.err) {
        if (!force) {
          io.err("rm: cannot remove '" + label + "': " + errMsg(r.err) + "\n");
          code = 1;
        }
        return;
      }
      const p = cx.fs.parentOf(abs);
      if (r.node.t === "d") {
        if (!rec && !H(f, "d", "dir")) {
          io.err("rm: cannot remove '" + label + "': " + ERR.EISDIR + "\n");
          code = 1;
          return;
        }
        if (!cx.fs.canAccess(r.node, cx.user, 2) && cx.fs.names(r.node).length && !force) {
          io.err("rm: cannot remove '" + label + "/" + cx.fs.names(r.node)[0] + "': " + ERR.EACCES + "\n");
          code = 1;
          return;
        }
        if (rec) cx.fs.names(r.node).forEach((n) => del(abs + "/" + n, label + "/" + n));
        else if (cx.fs.names(r.node).length) {
          io.err("rm: cannot remove '" + label + "': " + ERR.ENOTEMPTY + "\n");
          code = 1;
          return;
        }
      }
      if (p.dir && !cx.fs.canAccess(p.dir, cx.user, 2)) {
        io.err("rm: cannot remove '" + label + "': " + ERR.EACCES + "\n");
        code = 1;
        return;
      }
      cx.fs.remove(abs);
      if (verbose) io.out((r.node.t === "d" ? "removed directory '" : "removed '") + label + "'\n");
    };
    rest.forEach((a) => {
      const base = a.replace(/\/+$/, "").split("/").pop();
      if (base === "." || base === "..") {
        io.err("rm: refusing to remove '.' or '..' directory: skipping '" + a + "'\n");
        code = 1;
      } else if (cx.abs(a) === "/" && rec) {
        io.err("rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe\n");
        code = 1;
      } else del(cx.abs(a), a);
    });
    return code;
  };

  function destFor(cx, dst, srcArg) {
    const abs = cx.abs(dst);
    const r = cx.fs.stat(abs);
    if (r.node && r.node.t === "d") return { path: cx.fs.normalize(abs + "/" + srcArg.replace(/\/+$/, "").split("/").pop()), isDir: true };
    return { path: abs, isDir: false, trailing: /\/$/.test(dst) };
  }

  C.cp = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const rec = H(f, "r", "R", "a", "recursive", "archive");
    const verbose = H(f, "v", "verbose");
    if (!rest.length) {
      io.err("cp: missing file operand\nTry 'cp --help' for more information.\n");
      return 1;
    }
    if (rest.length === 1) {
      io.err("cp: missing destination file operand after '" + rest[0] + "'\nTry 'cp --help' for more information.\n");
      return 1;
    }
    const dst = rest[rest.length - 1];
    const srcs = rest.slice(0, -1);
    const dr = cx.fs.stat(cx.abs(dst));
    if (srcs.length > 1 && !(dr.node && dr.node.t === "d")) {
      io.err("cp: target '" + dst + "' is not a directory\n");
      return 1;
    }
    let code = 0;
    srcs.forEach((s) => {
      const sabs = cx.abs(s);
      const sr = cx.fs.stat(sabs);
      if (sr.err) {
        io.err("cp: cannot stat '" + s + "': " + errMsg(sr.err) + "\n");
        code = 1;
        return;
      }
      if (sr.node.t === "d" && !rec) {
        io.err("cp: -r not specified; omitting directory '" + s + "'\n");
        code = 1;
        return;
      }
      if (!cx.fs.canAccess(sr.node, cx.user, 4)) {
        io.err("cp: cannot open '" + s + "' for reading: " + ERR.EACCES + "\n");
        code = 1;
        return;
      }
      const d = destFor(cx, dst, s);
      if (d.trailing && !d.isDir) {
        io.err("cp: cannot create regular file '" + dst + "': " + (cx.fs.stat(d.path).node ? ERR.ENOTDIR : ERR.ENOENT) + "\n");
        code = 1;
        return;
      }
      if (d.path === sabs) {
        io.err("cp: '" + s + "' and '" + (d.isDir ? dst + "/" + s : dst) + "' are the same file\n");
        code = 1;
        return;
      }
      if (sr.node.t === "d" && (d.path + "/").indexOf(sabs + "/") === 0) {
        io.err("cp: cannot copy a directory, '" + s + "', into itself, '" + dst + (d.isDir ? "/" + s : "") + "'\n");
        code = 1;
        return;
      }
      const existing = cx.fs.stat(d.path);
      if (existing.node) {
        if (existing.node.t === "d" && sr.node.t !== "d") {
          io.err("cp: cannot overwrite directory '" + dst + "' with non-directory\n");
          code = 1;
          return;
        }
        if (!cx.fs.canAccess(existing.node, cx.user, 2)) {
          io.err("cp: cannot create regular file '" + dst + "': " + ERR.EACCES + "\n");
          code = 1;
          return;
        }
        cx.fs.remove(d.path);
      }
      const err = cx.fs.create(d.path, cx.fs.clone(sr.node, cx.user), cx.user);
      if (err) {
        io.err("cp: cannot create " + (sr.node.t === "d" ? "directory" : "regular file") + " '" + dst + "': " + errMsg(err) + "\n");
        code = 1;
      } else if (verbose) io.out("'" + s + "' -> '" + (d.isDir ? dst.replace(/\/$/, "") + "/" + s.split("/").pop() : dst) + "'\n");
    });
    return code;
  };

  C.mv = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const verbose = H(f, "v", "verbose");
    if (!rest.length) {
      io.err("mv: missing file operand\nTry 'mv --help' for more information.\n");
      return 1;
    }
    if (rest.length === 1) {
      io.err("mv: missing destination file operand after '" + rest[0] + "'\nTry 'mv --help' for more information.\n");
      return 1;
    }
    const dst = rest[rest.length - 1];
    const srcs = rest.slice(0, -1);
    const dr = cx.fs.stat(cx.abs(dst));
    if (srcs.length > 1 && !(dr.node && dr.node.t === "d")) {
      io.err("mv: target '" + dst + "' is not a directory\n");
      return 1;
    }
    let code = 0;
    srcs.forEach((s) => {
      const sabs = cx.abs(s);
      const sr = cx.fs.stat(sabs, false);
      if (sr.err) {
        io.err("mv: cannot stat '" + s + "': " + errMsg(sr.err) + "\n");
        code = 1;
        return;
      }
      const d = destFor(cx, dst, s);
      if (d.path === sabs) {
        io.err("mv: '" + s + "' and '" + (d.isDir ? dst + "/" + s : dst) + "' are the same file\n");
        code = 1;
        return;
      }
      if (sr.node.t === "d" && (d.path + "/").indexOf(sabs + "/") === 0) {
        io.err("mv: cannot move '" + s + "' to a subdirectory of itself, '" + dst + (d.isDir ? "/" + s : "") + "'\n");
        code = 1;
        return;
      }
      const sp = cx.fs.parentOf(sabs);
      if (sp.dir && !cx.fs.canAccess(sp.dir, cx.user, 2)) {
        io.err("mv: cannot move '" + s + "' to '" + dst + "': " + ERR.EACCES + "\n");
        code = 1;
        return;
      }
      const existing = cx.fs.stat(d.path, false);
      if (existing.node) {
        if (existing.node.t === "d" && sr.node.t !== "d") {
          io.err("mv: cannot overwrite directory '" + dst + "' with non-directory\n");
          code = 1;
          return;
        }
        if (sr.node.t === "d" && existing.node.t !== "d") {
          io.err("mv: cannot overwrite non-directory '" + dst + "' with directory '" + s + "'\n");
          code = 1;
          return;
        }
        if (existing.node.t === "d" && cx.fs.names(existing.node).length) {
          io.err("mv: cannot move '" + s + "' to '" + dst + (d.isDir ? "/" + s : "") + "': " + ERR.ENOTEMPTY + "\n");
          code = 1;
          return;
        }
        cx.fs.remove(d.path);
      }
      const dp = cx.fs.parentOf(d.path);
      if (dp.err || !cx.fs.canAccess(dp.dir, cx.user, 2)) {
        io.err("mv: cannot move '" + s + "' to '" + dst + "': " + errMsg(dp.err || "EACCES") + "\n");
        code = 1;
        return;
      }
      cx.fs.remove(sabs);
      dp.dir.c[dp.name] = sr.node;
      if (verbose) io.out("renamed '" + s + "' -> '" + dst + "'\n");
    });
    return code;
  };

  C.ln = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    if (rest.length < 2) {
      io.err("ln: missing file operand\nTry 'ln --help' for more information.\n");
      return 1;
    }
    const target = rest[0];
    const name = rest[1];
    const d = destFor(cx, name, target);
    if (H(f, "f", "force") && cx.fs.stat(d.path, false).node) cx.fs.remove(d.path);
    let node;
    if (H(f, "s", "symbolic")) node = mkLink(target);
    else {
      const sr = cx.fs.stat(cx.abs(target));
      if (sr.err) {
        io.err("ln: failed to access '" + target + "': " + errMsg(sr.err) + "\n");
        return 1;
      }
      if (sr.node.t === "d") {
        io.err("ln: " + target + ": hard link not allowed for directory\n");
        return 1;
      }
      node = sr.node;
    }
    const keepOwner = node.o;
    const err = cx.fs.create(d.path, node, cx.user);
    if (err) {
      io.err("ln: failed to create " + (H(f, "s", "symbolic") ? "symbolic" : "hard") + " link '" + name + "': " + errMsg(err) + "\n");
      return 1;
    }
    if (!H(f, "s", "symbolic")) node.o = keepOwner;
    return 0;
  };

  C.chmod = (args, io, cx) => {
    const { f, rest } = opts(args.map((a) => (/^-[rwxXst+=,ugo]/.test(a) && !/^-[Rcvf]+$/.test(a) ? " " + a : a)), "");
    const items = rest.map((a) => a.trim());
    if (items.length < 2) {
      io.err(items.length ? "chmod: missing operand after '" + items[0] + "'\nTry 'chmod --help' for more information.\n" : "chmod: missing operand\nTry 'chmod --help' for more information.\n");
      return 1;
    }
    const spec = items[0];
    const compute = (node) => {
      if (/^[0-7]{1,4}$/.test(spec)) return parseInt(spec, 8);
      let mode = node.mode;
      const clauses = spec.split(",");
      for (const cl of clauses) {
        const m = /^([ugoa]*)([-+=])([rwxXst]*)$/.exec(cl);
        if (!m) return null;
        const who = m[1] || "a";
        let bits = 0;
        for (const ch of m[3]) bits |= ch === "r" ? 4 : ch === "w" ? 2 : ch === "x" ? 1 : ch === "X" ? (node.t === "d" || node.mode & 0o111 ? 1 : 0) : 0;
        let mask = 0;
        if (who.indexOf("u") >= 0 || who.indexOf("a") >= 0) mask |= bits << 6;
        if (who.indexOf("g") >= 0 || who.indexOf("a") >= 0) mask |= bits << 3;
        if (who.indexOf("o") >= 0 || who.indexOf("a") >= 0) mask |= bits;
        if (m[2] === "+") mode |= mask;
        else if (m[2] === "-") mode &= ~mask;
        else {
          let clear = 0;
          if (who.indexOf("u") >= 0 || who.indexOf("a") >= 0) clear |= 0o700;
          if (who.indexOf("g") >= 0 || who.indexOf("a") >= 0) clear |= 0o070;
          if (who.indexOf("o") >= 0 || who.indexOf("a") >= 0) clear |= 0o007;
          mode = (mode & ~clear) | mask;
        }
        if (m[3].indexOf("t") >= 0) mode = m[2] === "-" ? mode & ~0o1000 : mode | 0o1000;
      }
      return mode;
    };
    if (compute({ mode: 0, t: "f" }) === null) {
      io.err("chmod: invalid mode: '" + spec + "'\nTry 'chmod --help' for more information.\n");
      return 1;
    }
    let code = 0;
    const apply = (abs, label) => {
      const r = cx.fs.stat(abs);
      if (r.err) {
        io.err("chmod: cannot access '" + label + "': " + errMsg(r.err) + "\n");
        code = 1;
        return;
      }
      if (cx.user !== "root" && r.node.o !== cx.user) {
        io.err("chmod: changing permissions of '" + label + "': " + ERR.EPERM + "\n");
        code = 1;
        return;
      }
      r.node.mode = compute(r.node);
      if (H(f, "R", "recursive") && r.node.t === "d") cx.fs.names(r.node).forEach((n) => apply(abs + "/" + n, label + "/" + n));
    };
    items.slice(1).forEach((a) => apply(cx.abs(a), a));
    return code;
  };

  C.chown = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    if (rest.length < 2) {
      io.err(rest.length ? "chown: missing operand after '" + rest[0] + "'\nTry 'chown --help' for more information.\n" : "chown: missing operand\nTry 'chown --help' for more information.\n");
      return 1;
    }
    const m = /^([^:.]*)(?:[:.](.*))?$/.exec(rest[0]);
    const owner = m[1];
    const group = m[2];
    if (owner && !cx.fs.users.has(owner)) {
      io.err("chown: invalid user: '" + rest[0] + "'\n");
      return 1;
    }
    let code = 0;
    const apply = (abs, label) => {
      const r = cx.fs.stat(abs);
      if (r.err) {
        io.err("chown: cannot access '" + label + "': " + errMsg(r.err) + "\n");
        code = 1;
        return;
      }
      if (cx.user !== "root") {
        io.err("chown: changing ownership of '" + label + "': " + ERR.EPERM + "\n");
        code = 1;
        return;
      }
      if (owner) r.node.o = owner;
      if (group) r.node.g = group;
      if (H(f, "R", "recursive") && r.node.t === "d") cx.fs.names(r.node).forEach((n) => apply(abs + "/" + n, label + "/" + n));
    };
    rest.slice(1).forEach((a) => apply(cx.abs(a), a));
    return code;
  };

  // ── Reading and text ───────────────────────────────────────────
  C.cat = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    let n = 0;
    return eachInput(rest, io, cx, "cat", (text) => {
      if (!H(f, "n", "number")) {
        io.out(text);
        return;
      }
      splitLines(text).forEach((l) => io.out(padL(++n, 6) + "\t" + l));
    });
  };
  C.less = C.more = C.cat;

  C.tac = (args, io, cx) => eachInput(args, io, cx, "tac", (text) => io.out(splitLines(text).reverse().map((l) => (l.endsWith("\n") ? l : l + "\n")).join("")));

  C.echo = (args, io) => {
    let nl = true;
    let esc = false;
    while (args.length && /^-[neE]+$/.test(args[0])) {
      if (args[0].indexOf("n") >= 0) nl = false;
      if (args[0].indexOf("e") >= 0) esc = true;
      args = args.slice(1);
    }
    let s = args.join(" ");
    if (esc) s = s.replace(/\\(n|t|\\|r)/g, (m, c) => (c === "n" ? "\n" : c === "t" ? "\t" : c === "r" ? "\r" : "\\"));
    io.out(s + (nl ? "\n" : ""));
    return 0;
  };

  C.printf = (args, io) => {
    if (!args.length) {
      io.err("printf: usage: printf [-v var] format [arguments]\n");
      return 2;
    }
    const unesc = (s) => s.replace(/\\(n|t|\\|r|")/g, (m, c) => (c === "n" ? "\n" : c === "t" ? "\t" : c === "r" ? "\r" : c));
    const fmt = args[0];
    const vals = args.slice(1);
    let out = "";
    let used = 0;
    do {
      out += unesc(fmt).replace(/%(-?)(\d*)(?:\.(\d+))?([sdifxXc%])/g, (m, left, w, prec, c) => {
        if (c === "%") return "%";
        const v = vals[used++];
        let s;
        if (c === "s") s = v == null ? "" : prec ? String(v).slice(0, +prec) : String(v);
        else if (c === "c") s = v == null ? "" : String(v)[0];
        else if (c === "f") s = (parseFloat(v) || 0).toFixed(prec ? +prec : 6);
        else if (c === "x" || c === "X") s = (parseInt(v, 10) || 0).toString(16);
        else s = String(parseInt(v, 10) || 0);
        if (c === "X") s = s.toUpperCase();
        return left ? padR(s, +w || 0) : padL(s, +w || 0);
      });
    } while (used < vals.length && /%[-\d.]*[sdifxXc]/.test(fmt));
    io.out(out);
    return 0;
  };

  function headTailArgs(args) {
    return args.map((a) => (/^-\d+$/.test(a) ? "-n" + a.slice(1) : a));
  }

  C.head = (args, io, cx) => {
    const { f, rest } = opts(headTailArgs(args), "nc");
    const n = f.n != null ? parseInt(f.n, 10) : 10;
    const multi = rest.length > 1;
    let first = true;
    return eachInput(rest, io, cx, "head", (text, label) => {
      if (multi) io.out((first ? "" : "\n") + "==> " + label + " <==\n");
      first = false;
      if (f.c != null) io.out(text.slice(0, parseInt(f.c, 10)));
      else io.out(splitLines(text).slice(0, n >= 0 ? n : Math.max(0, splitLines(text).length + n)).join(""));
    });
  };

  C.tail = (args, io, cx) => {
    const { f, rest } = opts(headTailArgs(args), "nc");
    const spec = f.n != null ? String(f.n) : "10";
    const multi = rest.length > 1;
    let first = true;
    return eachInput(rest, io, cx, "tail", (text, label) => {
      if (multi) io.out((first ? "" : "\n") + "==> " + label + " <==\n");
      first = false;
      const lines = splitLines(text);
      if (f.c != null) io.out(text.slice(-parseInt(f.c, 10)));
      else if (spec[0] === "+") io.out(lines.slice(Math.max(0, parseInt(spec.slice(1), 10) - 1)).join(""));
      else io.out(lines.slice(Math.max(0, lines.length - parseInt(spec, 10))).join(""));
    });
  };

  C.wc = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    let cols = ["l", "w", "c"].filter((k) => f[k]);
    if (f.m) cols = cols.concat("m");
    if (!cols.length) cols = ["l", "w", "c"];
    const rows = [];
    const code = eachInput(rest, io, cx, "wc", (text, label) => {
      const t = text.trim();
      rows.push({ label: label === "-" && !rest.length ? "" : label, v: { l: (text.match(/\n/g) || []).length, w: t ? t.split(/\s+/).length : 0, c: byteLen(text), m: text.length } });
    });
    if (rows.length > 1) rows.push({ label: "total", v: { l: 0, w: 0, c: 0, m: 0 } }), rows.slice(0, -1).forEach((r) => Object.keys(r.v).forEach((k) => (rows[rows.length - 1].v[k] += r.v[k])));
    const width = cols.length === 1 && rows.length === 1 ? 0 : rest.length ? Math.max.apply(null, rows.map((r) => Math.max.apply(null, cols.map((k) => String(r.v[k]).length)))) : 7;
    rows.forEach((r) => io.out(cols.map((k) => padL(r.v[k], width)).join(" ") + (r.label ? " " + r.label : "") + "\n"));
    return code;
  };

  C.grep = (args, io, cx) => {
    const { f, rest } = opts(args, "e");
    let pattern = f.e;
    if (pattern === undefined) pattern = rest.shift();
    if (pattern === undefined) {
      io.err("Usage: grep [OPTION]... PATTERNS [FILE]...\nTry 'grep --help' for more information.\n");
      return 2;
    }
    let src = H(f, "F", "fixed-strings") ? pattern.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : pattern;
    if (H(f, "w", "word-regexp")) src = "\\b(?:" + src + ")\\b";
    let re;
    try {
      re = new RegExp(src, (H(f, "i", "ignore-case") ? "i" : "") + "g");
    } catch (e) {
      io.err("grep: Unmatched ( or \\(\n");
      return 2;
    }
    const inv = H(f, "v", "invert-match");
    const rec = H(f, "r", "R", "recursive");
    const names = rest.slice();
    let paths = names;
    if (rec) {
      paths = [];
      const gather = (abs, label) => {
        const r = cx.fs.stat(abs);
        if (r.err) return paths.push(label);
        if (r.node.t === "d") cx.fs.names(r.node).sort().forEach((n) => gather(abs + "/" + n, label.replace(/\/$/, "") + "/" + n));
        else paths.push(label);
      };
      (names.length ? names : ["."]).forEach((n) => gather(cx.abs(n), n));
    }
    const prefix = !H(f, "h", "no-filename") && (paths.length > 1 || rec);
    let matched = false;
    let code = 0;
    const colorOn = io.tty && !H(f, "c", "count", "l", "files-with-matches");
    const emitMatchLine = (line, label, num) => {
      if (prefix) {
        io.out(label, colorOn ? "t-mag" : null);
        io.out(":", colorOn ? "t-cyan" : null);
      }
      if (H(f, "n", "line-number")) {
        io.out(String(num), colorOn ? "t-green" : null);
        io.out(":", colorOn ? "t-cyan" : null);
      }
      if (inv || !colorOn) {
        io.out(line + "\n");
        return;
      }
      let last = 0;
      let m;
      re.lastIndex = 0;
      while ((m = re.exec(line)) && m[0] !== "") {
        io.out(line.slice(last, m.index));
        io.out(m[0], "t-red");
        last = m.index + m[0].length;
      }
      io.out(line.slice(last) + "\n");
    };
    const scan = (text, label) => {
      let count = 0;
      splitLines(text).forEach((raw, i) => {
        const line = raw.replace(/\n$/, "");
        re.lastIndex = 0;
        const hit = re.test(line);
        if (hit === inv) return;
        count++;
        matched = true;
        if (H(f, "c", "count", "l", "files-with-matches")) return;
        if (H(f, "o", "only-matching") && !inv) {
          re.lastIndex = 0;
          let m;
          while ((m = re.exec(line)) && m[0] !== "") io.out((prefix ? label + ":" : "") + m[0] + "\n");
          return;
        }
        emitMatchLine(line, label, i + 1);
      });
      if (H(f, "c", "count")) io.out((prefix ? label + ":" : "") + count + "\n");
      else if (H(f, "l", "files-with-matches") && count) io.out(label + "\n");
    };
    if (!paths.length) scan(inputText(io), "(standard input)");
    else {
      code = 0;
      paths.forEach((n) => {
        const r = cx.fs.stat(cx.abs(n));
        if (r.err) {
          if (!H(f, "s")) io.err("grep: " + n + ": " + errMsg(r.err) + "\n");
          code = 2;
        } else if (r.node.t === "d") {
          io.err("grep: " + n + ": " + ERR.EISDIR + "\n");
          code = 2;
        } else if (!cx.fs.canAccess(r.node, cx.user, 4)) {
          io.err("grep: " + n + ": " + ERR.EACCES + "\n");
          code = 2;
        } else scan(r.node.data, n);
      });
    }
    return code === 2 ? 2 : matched ? 0 : 1;
  };

  C.sort = (args, io, cx) => {
    const { f, rest } = opts(args, "kt");
    let lines = [];
    const code = eachInput(rest, io, cx, "sort", (text) => {
      lines = lines.concat(splitLines(text).map((l) => l.replace(/\n$/, "")));
    });
    const num = H(f, "n", "numeric-sort");
    lines.sort((a, b) => (num ? (parseFloat(a) || 0) - (parseFloat(b) || 0) : H(f, "f") ? a.toLowerCase().localeCompare(b.toLowerCase()) : a.localeCompare(b)));
    if (H(f, "r", "reverse")) lines.reverse();
    if (H(f, "u", "unique")) lines = lines.filter((l, i) => i === 0 || l !== lines[i - 1]);
    lines.forEach((l) => io.out(l + "\n"));
    return code;
  };

  C.uniq = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const groups = [];
    const code = eachInput(rest.slice(0, 1), io, cx, "uniq", (text) => {
      splitLines(text).map((l) => l.replace(/\n$/, "")).forEach((l) => {
        const g = groups[groups.length - 1];
        if (g && g.l === l) g.n++;
        else groups.push({ l: l, n: 1 });
      });
    });
    groups.forEach((g) => {
      if (H(f, "d") && g.n < 2) return;
      if (H(f, "u") && g.n > 1) return;
      io.out((H(f, "c") ? padL(g.n, 7) + " " : "") + g.l + "\n");
    });
    return code;
  };

  C.cut = (args, io, cx) => {
    const { f, rest } = opts(args, "dfc");
    const delim = f.d != null ? f.d : "\t";
    const spec = f.f != null ? f.f : f.c;
    if (spec == null) {
      io.err("cut: you must specify a list of bytes, characters, or fields\nTry 'cut --help' for more information.\n");
      return 1;
    }
    const picks = [];
    String(spec).split(",").forEach((p) => {
      const m = /^(\d*)-(\d*)$/.exec(p);
      if (m) picks.push([m[1] ? +m[1] : 1, m[2] ? +m[2] : Infinity]);
      else picks.push([+p, +p]);
    });
    const inRange = (i) => picks.some((p) => i >= p[0] && i <= p[1]);
    return eachInput(rest, io, cx, "cut", (text) => {
      splitLines(text).forEach((raw) => {
        const line = raw.replace(/\n$/, "");
        if (f.f != null) {
          if (line.indexOf(delim) < 0) return io.out(line + "\n");
          io.out(line.split(delim).filter((x, i) => inRange(i + 1)).join(delim) + "\n");
        } else io.out(line.split("").filter((x, i) => inRange(i + 1)).join("") + "\n");
      });
    });
  };

  C.tr = (args, io) => {
    const { f, rest } = opts(args, "");
    const expand = (s) => {
      const classes = { "[:upper:]": "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "[:lower:]": "abcdefghijklmnopqrstuvwxyz", "[:digit:]": "0123456789", "[:space:]": " \t\n", "[:alpha:]": "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz" };
      Object.keys(classes).forEach((k) => {
        s = s.split(k).join(classes[k]);
      });
      return s.replace(/(.)-(.)/g, (m, a, b) => {
        let r = "";
        for (let c = a.charCodeAt(0); c <= b.charCodeAt(0); c++) r += String.fromCharCode(c);
        return r;
      }).replace(/\\n/g, "\n").replace(/\\t/g, "\t");
    };
    if (!rest.length) {
      io.err("tr: missing operand\nTry 'tr --help' for more information.\n");
      return 1;
    }
    const a = expand(rest[0]);
    const b = rest[1] ? expand(rest[1]) : "";
    const out = inputText(io).split("").map((ch) => {
      const i = a.indexOf(ch);
      if (H(f, "d")) return i >= 0 ? "" : ch;
      return i >= 0 && b ? b[Math.min(i, b.length - 1)] : ch;
    }).join("");
    io.out(out);
    return 0;
  };

  C.tee = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const text = inputText(io);
    io.out(text);
    let code = 0;
    rest.forEach((n) => {
      const err = cx.fs.writeFile(cx.abs(n), text, H(f, "a", "append"), cx.user);
      if (err) {
        io.err("tee: " + n + ": " + errMsg(err) + "\n");
        code = 1;
      }
    });
    return code;
  };

  C.seq = (args, io) => {
    const n = args.map(Number);
    if (!n.length || n.some(isNaN)) {
      io.err(n.length ? "seq: invalid floating point argument: '" + args[n.findIndex(isNaN)] + "'\n" : "seq: missing operand\nTry 'seq --help' for more information.\n");
      return 1;
    }
    const start = n.length > 1 ? n[0] : 1;
    const step = n.length === 3 ? n[1] : 1;
    const end = n[n.length - 1];
    for (let i = start, guard = 0; (step > 0 ? i <= end : i >= end) && guard < 10000; i += step, guard++) io.out(i + "\n");
    return 0;
  };

  C.basename = (args, io) => {
    if (!args.length) {
      io.err("basename: missing operand\nTry 'basename --help' for more information.\n");
      return 1;
    }
    let b = args[0].replace(/\/+$/, "").split("/").pop() || "/";
    if (args[1] && b.endsWith(args[1]) && b !== args[1]) b = b.slice(0, -args[1].length);
    io.out(b + "\n");
    return 0;
  };

  C.dirname = (args, io) => {
    if (!args.length) {
      io.err("dirname: missing operand\nTry 'dirname --help' for more information.\n");
      return 1;
    }
    args.forEach((a) => {
      const t = a.replace(/\/+$/, "");
      const i = t.lastIndexOf("/");
      io.out((i < 0 ? "." : i === 0 ? "/" : t.slice(0, i)) + "\n");
    });
    return 0;
  };

  C.realpath = (args, io, cx) => {
    const { rest } = opts(args, "");
    if (!rest.length) {
      io.err("realpath: missing operand\nTry 'realpath --help' for more information.\n");
      return 1;
    }
    let code = 0;
    rest.forEach((a) => {
      const abs = cx.abs(a);
      if (cx.fs.stat(abs).err) {
        io.err("realpath: " + a + ": " + ERR.ENOENT + "\n");
        code = 1;
      } else io.out(abs + "\n");
    });
    return code;
  };

  C.file = (args, io, cx) => {
    let code = 0;
    args.filter((a) => a[0] !== "-").forEach((a) => {
      const r = cx.fs.stat(cx.abs(a), false);
      if (r.err) {
        io.out(a + ": cannot open `" + a + "' (" + errMsg(r.err) + ")\n");
        code = 1;
      } else if (r.node.t === "d") io.out(a + ": directory\n");
      else if (r.node.t === "l") io.out(a + ": symbolic link to " + r.node.target + "\n");
      else if (cx.fs.size(r.node) === 0) io.out(a + ": empty\n");
      else if (r.node.size != null) io.out(a + ": data\n");
      else io.out(a + ": " + (/^#!/.test(r.node.data) ? "script, ASCII text executable" : "ASCII text") + "\n");
    });
    return code;
  };

  C.stat = (args, io, cx) => {
    const { rest } = opts(args, "c");
    if (!rest.length) {
      io.err("stat: missing operand\nTry 'stat --help' for more information.\n");
      return 1;
    }
    let code = 0;
    const ts = (d) => d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()) + " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()) + ".000000000 " + (d.getTimezoneOffset() <= 0 ? "+" : "-") + pad2(Math.floor(Math.abs(d.getTimezoneOffset()) / 60)) + pad2(Math.abs(d.getTimezoneOffset()) % 60);
    rest.forEach((a) => {
      const r = cx.fs.stat(cx.abs(a), false);
      if (r.err) {
        io.err("stat: cannot statx '" + a + "': " + errMsg(r.err) + "\n");
        code = 1;
        return;
      }
      const n = r.node;
      const size = cx.fs.size(n);
      const uid = (u) => (u === "root" ? 0 : 1000);
      const kind = n.t === "d" ? "directory" : n.t === "l" ? "symbolic link" : size ? "regular file" : "regular empty file";
      io.out("  File: " + a + (n.t === "l" ? " -> " + n.target : "") + "\n");
      io.out("  Size: " + padR(size, 10) + "\tBlocks: " + padR(Math.ceil(size / 4096) * 8, 10) + " IO Block: 4096   " + kind + "\n");
      io.out("Device: 252,0\tInode: " + (131072 + (a.length * 977) % 9000) + "      Links: " + (n.t === "d" ? 2 : 1) + "\n");
      io.out("Access: (" + (n.mode & 0o7777).toString(8).padStart(4, "0") + "/" + modeStr(n) + ")  Uid: (" + padL(uid(n.o), 5) + "/" + padL(n.o, 8) + ")   Gid: (" + padL(uid(n.g || n.o), 5) + "/" + padL(n.g || n.o, 8) + ")\n");
      io.out("Access: " + ts(n.m) + "\nModify: " + ts(n.m) + "\nChange: " + ts(n.m) + "\n Birth: -\n");
    });
    return code;
  };

  function globToRegex(p, ci) {
    return new RegExp("^" + p.replace(/[.+^${}()|\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$", ci ? "i" : "");
  }

  C.find = (args, io, cx) => {
    const paths = [];
    let i = 0;
    while (i < args.length && args[i][0] !== "-" && args[i] !== "!" && args[i] !== "(") paths.push(args[i++]);
    if (!paths.length) paths.push(".");
    const tests = [];
    let maxDepth = Infinity;
    let minDepth = 0;
    for (; i < args.length; i++) {
      const a = args[i];
      if (a === "-name" || a === "-iname") tests.push({ re: globToRegex(args[++i] || "", a === "-iname") });
      else if (a === "-type") tests.push({ type: args[++i] });
      else if (a === "-maxdepth") maxDepth = parseInt(args[++i], 10);
      else if (a === "-mindepth") minDepth = parseInt(args[++i], 10);
      else if (a === "-empty") tests.push({ empty: true });
      else if (a === "-print") continue;
      else {
        io.err("find: unknown predicate `" + a + "'\n");
        return 1;
      }
    }
    let code = 0;
    const match = (n, name) => tests.every((t) => {
      if (t.re) return t.re.test(name);
      if (t.type) return t.type === (n.t === "d" ? "d" : n.t === "l" ? "l" : "f");
      if (t.empty) return n.t === "d" ? !cx.fs.names(n).length : cx.fs.size(n) === 0;
      return true;
    });
    const visit = (abs, label, depth) => {
      const r = cx.fs.stat(abs, false);
      if (r.err) {
        io.err("find: '" + label + "': " + errMsg(r.err) + "\n");
        code = 1;
        return;
      }
      if (depth >= minDepth && match(r.node, label.replace(/\/+$/, "").split("/").pop() || label)) io.out(label + "\n");
      if (r.node.t === "d" && depth < maxDepth) {
        if (!cx.fs.canAccess(r.node, cx.user, 4)) {
          io.err("find: '" + label + "': " + ERR.EACCES + "\n");
          code = 1;
          return;
        }
        cx.fs.names(r.node).sort().forEach((n) => visit(abs === "/" ? "/" + n : abs + "/" + n, label.replace(/\/$/, "") + "/" + n, depth + 1));
      }
    };
    paths.forEach((p) => visit(cx.abs(p), p, 0));
    return code;
  };

  C.du = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const hum = H(f, "h", "human-readable");
    const fmt = (kib) => (hum ? human(kib * 1024) : String(kib));
    const blocks = (n) => (n.t === "d" ? 4 : Math.ceil(cx.fs.size(n) / 4096) * 4);
    const total = (n) => (n.t === "d" ? cx.fs.names(n).reduce((a, k) => a + total(n.c[k]), 4) : blocks(n));
    let code = 0;
    const walkDu = (n, label, top) => {
      if (n.t === "d") cx.fs.names(n).sort().forEach((k) => {
        if (n.c[k].t === "d") walkDu(n.c[k], label.replace(/\/$/, "") + "/" + k, false);
        else if (H(f, "a")) io.out(fmt(total(n.c[k])) + "\t" + label.replace(/\/$/, "") + "/" + k + "\n");
      });
      if (!H(f, "s") || top) io.out(fmt(total(n)) + "\t" + label + "\n");
    };
    (rest.length ? rest : ["."]).forEach((a) => {
      const r = cx.fs.stat(cx.abs(a));
      if (r.err) {
        io.err("du: cannot access '" + a + "': " + errMsg(r.err) + "\n");
        code = 1;
      } else walkDu(r.node, a, true);
    });
    return code;
  };

  C.test = (args, io, cx) => {
    const a = args.slice();
    let neg = false;
    if (a[0] === "!") {
      neg = true;
      a.shift();
    }
    let res = false;
    const node = (p) => cx.fs.stat(cx.abs(p)).node;
    if (a.length === 1) res = a[0] !== "";
    else if (a.length === 2) {
      const n = node(a[1]);
      const ops = {
        "-e": () => !!n, "-f": () => !!n && n.t === "f", "-d": () => !!n && n.t === "d", "-r": () => !!n && cx.fs.canAccess(n, cx.user, 4),
        "-w": () => !!n && cx.fs.canAccess(n, cx.user, 2), "-x": () => !!n && cx.fs.canAccess(n, cx.user, 1) && (n.t === "d" || (n.mode & 0o111) > 0),
        "-s": () => !!n && cx.fs.size(n) > 0, "-L": () => !!cx.fs.stat(cx.abs(a[1]), false).node && cx.fs.stat(cx.abs(a[1]), false).node.t === "l",
        "-z": () => a[1] === "", "-n": () => a[1] !== ""
      };
      res = ops[a[0]] ? ops[a[0]]() : false;
    } else if (a.length === 3) {
      const x = a[0];
      const y = a[2];
      const cmp = { "=": x === y, "==": x === y, "!=": x !== y, "-eq": +x === +y, "-ne": +x !== +y, "-lt": +x < +y, "-le": +x <= +y, "-gt": +x > +y, "-ge": +x >= +y };
      res = !!cmp[a[1]];
    }
    return res !== neg ? 0 : 1;
  };
  C["["] = (args, io, cx) => {
    if (args[args.length - 1] !== "]") {
      io.err("bash: [: missing `]'\n");
      return 2;
    }
    return C.test(args.slice(0, -1), io, cx);
  };

  // ── System information ─────────────────────────────────────────
  C.whoami = (args, io, cx) => {
    io.out(cx.user + "\n");
    return 0;
  };

  C.id = (args, io, cx) => {
    const u = cx.user;
    const uid = u === "root" ? 0 : 1000;
    const groups = u === "root" ? "0(root)" : "1000(" + u + "),4(adm),27(sudo),100(users)";
    const { f } = opts(args, "");
    if (f.u) io.out((f.n ? u : uid) + "\n");
    else if (f.g) io.out((f.n ? u : uid) + "\n");
    else io.out("uid=" + uid + "(" + u + ") gid=" + uid + "(" + u + ") groups=" + groups + "\n");
    return 0;
  };

  C.groups = (args, io, cx) => {
    io.out((cx.user === "root" ? "root" : cx.user + " adm sudo users") + "\n");
    return 0;
  };

  C.hostname = (args, io, cx) => {
    const { f } = opts(args, "");
    io.out((f.I || f.i ? cx.st.ip + " " : cx.st.host) + "\n");
    return 0;
  };

  C.uname = (args, io, cx) => {
    const { f } = opts(args, "");
    const parts = [];
    const all = f.a || f.all;
    if (all || f.s || !Object.keys(f).length) parts.push("Linux");
    if (all || f.n) parts.push(cx.st.host);
    if (all || f.r) parts.push("6.8.0-137-generic");
    if (all || f.v) parts.push("#137-Ubuntu SMP PREEMPT_DYNAMIC Fri Jun 12 15:48:36 UTC 2026");
    if (all || f.m) parts.push("x86_64");
    if (all) parts.push("x86_64", "x86_64");
    if (all || f.o) parts.push("GNU/Linux");
    io.out(parts.join(" ") + "\n");
    return 0;
  };

  C.date = (args, io) => {
    const fmt = args.filter((a) => a[0] === "+")[0];
    io.out(fmtDate(new Date(), fmt ? fmt.slice(1) : null) + "\n");
    return 0;
  };

  C.uptime = (args, io) => {
    const d = new Date();
    const text = pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()) + " up 4 days,  3:12,  1 user,  load average: 0.00, 0.01, 0.00";
    io.out(" " + text + "\n");
    return 0;
  };

  C.df = (args, io) => {
    const { f } = opts(args, "");
    const rows = f.h
      ? [["tmpfs", "1.6G", "1.1M", "1.6G", "1%", "/run"], ["/dev/mapper/ubuntu--vg-ubuntu--lv", "239G", "6.7G", "220G", "3%", "/"], ["tmpfs", "7.9G", "0", "7.9G", "0%", "/dev/shm"], ["tmpfs", "5.0M", "0", "5.0M", "0%", "/run/lock"], ["/dev/sda2", "2.0G", "99M", "1.7G", "6%", "/boot"], ["tmpfs", "1.6G", "12K", "1.6G", "1%", "/run/user/0"]]
      : [["tmpfs", "1638092", "1128", "1636964", "1%", "/run"], ["/dev/mapper/ubuntu--vg-ubuntu--lv", "250608524", "7027712", "230843196", "3%", "/"], ["tmpfs", "8190460", "0", "8190460", "0%", "/dev/shm"], ["tmpfs", "5120", "0", "5120", "0%", "/run/lock"], ["/dev/sda2", "2038320", "101012", "1815876", "6%", "/boot"], ["tmpfs", "1638092", "12", "1638080", "1%", "/run/user/0"]];
    io.out(padR("Filesystem", 34) + padL(f.h ? "Size" : "1K-blocks", 10) + padL("Used", 10) + padL("Avail", 10) + padL("Use%", 5) + " Mounted on\n");
    rows.forEach((r) => io.out(padR(r[0], 34) + padL(r[1], 10) + padL(r[2], 10) + padL(r[3], 10) + padL(r[4], 5) + " " + r[5] + "\n"));
    return 0;
  };

  C.free = (args, io) => {
    const { f } = opts(args, "");
    const rows = f.h
      ? [["Mem:", "15Gi", "1.1Gi", "13Gi", "1.0Mi", "1.3Gi", "14Gi"], ["Swap:", "0B", "0B", "0B"]]
      : f.m ? [["Mem:", "15996", "1096", "13586", "1", "1318", "14654"], ["Swap:", "0", "0", "0"]]
        : [["Mem:", "16380920", "1122500", "13912344", "1052", "1346076", "15004212"], ["Swap:", "0", "0", "0"]];
    io.out(padL("total", 19) + padL("used", 12) + padL("free", 12) + padL("shared", 12) + padL("buff/cache", 12) + padL("available", 12) + "\n");
    rows.forEach((r) => io.out(padR(r[0], 8) + r.slice(1).map((v, i) => padL(v, i === 0 ? 11 : 12)).join("") + "\n"));
    return 0;
  };

  C.nproc = (args, io) => {
    io.out("4\n");
    return 0;
  };

  C.who = (args, io, cx) => {
    const d = new Date();
    io.out(cx.user + "    pts/0        " + d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()) + " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + " (" + (cx.st.client || "172.16.3.9") + ")\n");
    return 0;
  };

  C.ps = (args, io, cx) => {
    const { f, rest } = opts(args, "");
    const all = f.a || f.e || f.A || rest.indexOf("aux") >= 0 || rest.indexOf("ax") >= 0 || f.f;
    if (all) {
      io.out("USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND\n");
      io.out("root           1  0.0  0.1  22344 13312 ?        Ss   Oct15   0:03 /sbin/init\n");
      io.out("root         712  0.0  0.0  15368  7424 ?        Ss   Oct15   0:00 /usr/lib/systemd/systemd-logind\n");
      io.out("root         931  0.0  0.1  15444  9216 ?        Ss   Oct15   0:00 sshd: /usr/sbin/sshd -D [listener]\n");
      io.out(padR(cx.user, 8) + "    1523  0.0  0.0   8272  5376 pts/0    Ss   00:05   0:00 -bash\n");
      io.out(padR(cx.user, 8) + "    1790  0.0  0.0  10072  3584 pts/0    R+   00:09   0:00 ps " + (rest[0] || "-ef") + "\n");
    } else {
      io.out("    PID TTY          TIME CMD\n   1523 pts/0    00:00:00 bash\n   1790 pts/0    00:00:00 ps\n");
    }
    return 0;
  };

  C.lsb_release = (args, io) => {
    const { f } = opts(args, "");
    if (f.a) io.out("No LSB modules are available.\nDistributor ID:\tUbuntu\nDescription:\tUbuntu 24.04.4 LTS\nRelease:\t24.04\nCodename:\tnoble\n");
    else if (f.d) io.out("Description:\tUbuntu 24.04.4 LTS\n");
    else if (f.r) io.out("Release:\t24.04\n");
    else if (f.c) io.out("Codename:\tnoble\n");
    else if (f.i) io.out("Distributor ID:\tUbuntu\n");
    else io.out("No LSB modules are available.\n");
    return 0;
  };

  // ── Environment and shell builtins ─────────────────────────────
  C.env = C.printenv = (args, io, cx) => {
    const st = cx.st;
    const all = Object.assign({}, st.env, { HOME: st.home, USER: st.user, LOGNAME: st.user, PWD: st.cwd, OLDPWD: st.oldpwd }, st.exported);
    if (args.length && args[0][0] !== "-") {
      if (!(args[0] in all)) return 1;
      io.out(all[args[0]] + "\n");
      return 0;
    }
    Object.keys(all).forEach((k) => io.out(k + "=" + all[k] + "\n"));
    return 0;
  };

  C.export = (args, io, cx) => {
    if (!args.length) {
      Object.keys(cx.st.exported).forEach((k) => io.out('declare -x ' + k + '="' + cx.st.exported[k] + '"\n'));
      return 0;
    }
    args.forEach((a) => {
      const m = /^([A-Za-z_]\w*)(?:=(.*))?$/.exec(a);
      if (!m) {
        io.err("bash: export: `" + a + "': not a valid identifier\n");
        return;
      }
      if (m[2] !== undefined) cx.st.vars[m[1]] = m[2];
      cx.st.exported[m[1]] = getVar(cx.st, m[1]);
    });
    return 0;
  };

  C.unset = (args, io, cx) => {
    args.forEach((a) => {
      delete cx.st.vars[a];
      delete cx.st.exported[a];
    });
    return 0;
  };

  C.history = (args, io, cx) => {
    const h = cx.st.history;
    if (args[0] === "-c") {
      h.length = 0;
      return 0;
    }
    const n = /^\d+$/.test(args[0] || "") ? parseInt(args[0], 10) : h.length;
    h.slice(-n).forEach((c, i) => io.out(padL(h.length - Math.min(n, h.length) + i + 1, 5) + "  " + c + "\n"));
    return 0;
  };

  function whichName(cx, name) {
    const r = cx.fs.stat("/usr/bin/" + name);
    return r.node ? "/usr/bin/" + name : null;
  }

  C.which = (args, io, cx) => {
    let code = 0;
    args.filter((a) => a[0] !== "-").forEach((a) => {
      const p = BUILTINS.indexOf(a) < 0 && whichName(cx, a);
      if (p) io.out(p + "\n");
      else code = 1;
    });
    return code;
  };

  C.type = (args, io, cx) => {
    let code = 0;
    args.forEach((a) => {
      if (BUILTINS.indexOf(a) >= 0) io.out(a + " is a shell builtin\n");
      else if (whichName(cx, a)) io.out(a + " is " + whichName(cx, a) + "\n");
      else {
        io.err("bash: type: " + a + ": not found\n");
        code = 1;
      }
    });
    return code;
  };

  C.command = (args, io, cx) => {
    if (args[0] === "-v") return C.which(args.slice(1), io, cx);
    return cx.sub(args.join(" "), io);
  };

  C.true = () => 0;
  C.false = () => 1;
  C.sleep = (args, io, cx) => {
    const s = parseFloat(args[0]);
    if (isNaN(s)) {
      io.err(args.length ? "sleep: invalid time interval '" + args[0] + "'\nTry 'sleep --help' for more information.\n" : "sleep: missing operand\nTry 'sleep --help' for more information.\n");
      return 1;
    }
    cx.result.delay += Math.min(s, 5) * 1000;
    return 0;
  };
  C.clear = (args, io, cx) => {
    cx.result.chunks.push({ clear: true });
    return 0;
  };
  C.exit = C.logout = (args, io, cx) => {
    cx.result.exit = true;
    return 0;
  };

  C.bash = C.sh = (args, io, cx) => {
    const { f, rest } = opts(args, "c");
    if (f.c != null) return cx.sub(f.c, io);
    if (!rest.length) return 0;
    const r = cx.fs.stat(cx.abs(rest[0]));
    if (r.err || r.node.t !== "f") {
      io.err((args[0] === "sh" ? "sh" : "bash") + ": " + rest[0] + ": " + errMsg(r.err || "EISDIR") + "\n");
      return 127;
    }
    if (!cx.fs.canAccess(r.node, cx.user, 4)) {
      io.err("bash: " + rest[0] + ": " + ERR.EACCES + "\n");
      return 126;
    }
    return cx.sub(r.node.data.split("\n").filter((l) => !/^\s*(#|$)/.test(l)).join("\n"), io);
  };

  C.xargs = (args, io, cx) => {
    const words = inputText(io).split(/\s+/).filter(Boolean).map((w) => "'" + w.replace(/'/g, "'\\''") + "'");
    return cx.sub((args.length ? args.join(" ") : "echo") + " " + words.join(" "), io);
  };

  C.ll = (args, io, cx) => C.ls(["-alF"].concat(args), io, cx);

  C.help = (args, io) => {
    io.out("GNU bash, version 5.2.21(1)-release (x86_64-pc-linux-gnu)\nThis simulated shell supports common commands such as:\n");
    io.out("  ls cd pwd mkdir rmdir touch rm cp mv ln cat echo printf head tail wc grep sort uniq cut tr tee find du stat file\n  chmod chown whoami id hostname uname date uptime df free ps env export history which type clear exit\nPipes (|), redirects (> >> <), && || ; and $(...) are supported.\n");
    return 0;
  };

  C.virsh = (args, io, cx) => {
    const fail = (text) => { io.err("error: " + text + "\n"); return 1; };
    if (cx.st.host !== "manager") return fail("virsh is only available on the KVM hypervisor (172.16.3.3).");
    if (cx.user !== "root") return fail("Permission denied. Use sudo or the root session.");
    const domains = cx.fs.domains || [];
    if (args[0] === "list") {
      if (args.slice(1).some((a) => !["--all", "--autostart", "--no-autostart"].includes(a))) return fail("unsupported list option; use --all, --autostart or --no-autostart.");
      const all = args.includes("--all");
      const rows = domains.filter((d) => (all || d.running) && (!args.includes("--autostart") || d.autostart) && (!args.includes("--no-autostart") || !d.autostart));
      io.out(" Id   Name                 State\n----------------------------------------\n");
      rows.forEach((d, i) => io.out(" " + (d.running ? i + 1 : "-") + "    " + d.name.padEnd(20) + (d.running ? "running" : "shut off") + "\n"));
      return 0;
    }
    const d = domains.find((x) => x.name === args[1]);
    if (!d) return fail("failed to get domain '" + (args[1] || "") + "'.");
    if (args[0] === "autostart" && args.length === 2) {
      d.autostart = true;
      io.out("Domain " + d.name + " marked as autostarted\n");
      return 0;
    }
    if (!["shutdown", "destroy", "undefine"].includes(args[0]) || args.length !== 2) return fail("use virsh list, autostart, shutdown, destroy or undefine.");
    if (d.name !== "failed-vm") return fail("The working manager is protected in this lab. Use the disposable failed-vm for recovery practice.");
    if (args[0] === "undefine") {
      if (d.running) return fail("domain is still running; shut it down first.");
      cx.fs.domains = domains.filter((x) => x !== d);
      io.out("Domain " + d.name + " has been undefined\n");
    } else {
      if (!d.running) return fail("domain is not running.");
      d.running = false;
      io.out("Domain " + d.name + (args[0] === "destroy" ? " destroyed\n" : " is being shutdown\n"));
    }
    return 0;
  };

  C.nslookup = (args, io, cx) => {
    if (args.length !== 1) { io.err("Usage: nslookup <hostname>\n"); return 1; }
    const dns = cx.fs.dns || "172.16.3.9";
    if (dns !== "172.16.3.9") { io.err(";; connection timed out; no servers could be reached (configured DNS: " + dns + ")\n"); return 1; }
    io.out("Server:\t\t" + dns + "\nAddress:\t" + dns + "#53\n\n");
    if (!["vcenter-01.talabs.local", "vcenter.talabs.local"].includes(args[0])) {
      io.err("** server can't find " + args[0] + ": NXDOMAIN\n");
      return 1;
    }
    io.out("Name:\tvcenter-01.talabs.local\nAddress: 172.16.3.10\n");
    return 0;
  };

  // ── Execution ──────────────────────────────────────────────────
  function createState(fs, user, host, ip, client) {
    fs.addUserHome(user);
    const home = user === "root" ? "/root" : "/home/" + user;
    return {
      fs: fs, user: user, host: host, ip: ip, client: client, home: home, cwd: home, oldpwd: home, code: 0, cols: 80, history: [], vars: {}, exported: {},
      env: { SHELL: "/bin/bash", TERM: "xterm", LANG: "en_US.UTF-8", PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin", HISTSIZE: "1000", SHLVL: "1", SSH_CONNECTION: (client || "172.16.3.9") + " 52214 " + ip + " 22" }
    };
  }

  function writeRedirect(cx, io, target, text, append) {
    const err = cx.fs.writeFile(cx.abs(target), text, append, cx.user);
    if (err) {
      io.err("bash: " + target + ": " + errMsg(err) + "\n");
      return false;
    }
    return true;
  }

  function execLine(line, st, result, depth) {
    const fs = st.fs;
    const lex = tokenize(line);
    const parsed = lex.err ? lex : parse(lex.toks);
    if (parsed.err) {
      result.chunks.push("bash: " + parsed.err + "\n");
      st.code = 2;
      return;
    }
    const sub = (cmd) => {
      if (depth > 4) return "";
      const r = { chunks: [], exit: false, delay: 0, unsupported: null };
      execLine(cmd, st, r, depth + 1);
      return flatten(r.chunks);
    };

    const runSimple = (cmd, input, sinkOut, sinkErr, tty) => {
      const io = {
        in: input,
        tty: tty,
        out: (s, cls) => sinkOut.push(cls ? [s, cls] : s),
        err: (s) => sinkErr.push(s)
      };
      let argv = [];
      cmd.words.forEach((w) => {
        argv = argv.concat(expandWord(w, st, fs, sub));
      });
      if (!argv.length) return 0;
      if (argv.length === 1 && /^[A-Za-z_]\w*=/.test(argv[0])) {
        const eq = argv[0].indexOf("=");
        st.vars[argv[0].slice(0, eq)] = argv[0].slice(eq + 1);
        return 0;
      }
      let user = st.user;
      let name = argv[0];
      let prefix = "bash";
      if (name === "sudo") {
        let k = 1;
        while (argv[k] && argv[k][0] === "-") k++;
        if (k >= argv.length) {
          io.err("usage: sudo -h | -K | -k | -V\n");
          return 1;
        }
        user = "root";
        prefix = "sudo";
        argv = argv.slice(k);
        name = argv[0];
      }
      const cx = {
        st: st, fs: fs, user: user, result: result,
        abs: (p) => fs.resolve(p, st.cwd),
        sub: (text, ioOut) => {
          const r = { chunks: [], exit: false, delay: 0, unsupported: null };
          execLine(text, st, r, depth + 1);
          r.chunks.forEach((c) => (c && c.clear ? result.chunks.push(c) : ioOut.out(Array.isArray(c) ? c[0] : c, Array.isArray(c) ? c[1] : null)));
          result.delay += r.delay;
          return st.code;
        }
      };
      if (name.indexOf("/") >= 0) {
        const r = fs.stat(cx.abs(name));
        if (r.err || r.node.t === "d") {
          io.err(prefix + ": " + name + ": " + (r.err ? errMsg(r.err) : ERR.EISDIR) + "\n");
          return r.err ? 127 : 126;
        }
        if (!(r.node.mode & 0o111) || !fs.canAccess(r.node, user, 1)) {
          io.err(prefix + ": " + name + ": " + ERR.EACCES + "\n");
          return 126;
        }
        return C.bash([name], io, cx);
      }
      if (UNSUPPORTED.indexOf(name) >= 0) {
        result.unsupported = name;
        return 0;
      }
      const fn = COMMANDS[name];
      if (!fn) {
        io.err(prefix + ": " + name + ": command not found\n");
        return 127;
      }
      return fn(argv.slice(1), io, cx);
    };

    const runPipeline = (cmds) => {
      let input = null;
      let code = 0;
      cmds.forEach((cmd, idx) => {
        const last = idx === cmds.length - 1;
        let outRedir = null;
        let errRedir = null;
        let merge = false;
        let skip = false;
        const expandOne = (w) => expandWord(w, st, fs, sub)[0];
        cmd.redirs.forEach((r) => {
          if (r.op === "2>&1") merge = true;
          else if (r.op === "<") {
            const n = expandOne(r.w);
            const rr = fs.stat(fs.resolve(n, st.cwd));
            if (rr.err || rr.node.t === "d") {
              result.chunks.push("bash: " + n + ": " + (rr.err ? errMsg(rr.err) : ERR.EISDIR) + "\n");
              skip = true;
            } else input = rr.node.data;
          } else if (r.op === ">" || r.op === ">>") outRedir = { path: expandOne(r.w), append: r.op === ">>" };
          else if (r.op === "&>") outRedir = errRedir = { path: expandOne(r.w), append: false, both: true };
          else errRedir = { path: expandOne(r.w), append: r.op === "2>>" };
        });
        if (skip) {
          code = 1;
          input = "";
          return;
        }
        const toTerm = last && !outRedir;
        const outBuf = toTerm ? result.chunks : [];
        let errBuf = result.chunks;
        if (errRedir && !errRedir.both) errBuf = [];
        else if (errRedir && errRedir.both) errBuf = outBuf;
        else if (merge) errBuf = outBuf;
        code = runSimple(cmd, input, outBuf, errBuf, toTerm);
        const rcx = { fs: fs, user: st.user, abs: (p) => fs.resolve(p, st.cwd) };
        const rio = { err: (s) => result.chunks.push(s) };
        if (outRedir) {
          const text = flatten(outBuf);
          if (!writeRedirect(rcx, rio, outRedir.path, text, outRedir.append)) code = 1;
        }
        if (errRedir && !errRedir.both) writeRedirect(rcx, rio, errRedir.path, flatten(errBuf), errRedir.append);
        input = last ? null : outRedir ? "" : flatten(outBuf);
      });
      return code;
    };

    for (const item of parsed.items) {
      if (item.sep === "&&" && st.code !== 0) continue;
      if (item.sep === "||" && st.code === 0) continue;
      st.code = runPipeline(item.pipeline);
      if (result.exit) break;
    }
  }

  function run(line, st) {
    const result = { chunks: [], exit: false, delay: 0, unsupported: null };
    execLine(line, st, result, 0);
    return result;
  }

  function promptPath(st) {
    if (st.cwd === st.home) return "~";
    if (st.cwd.indexOf(st.home + "/") === 0) return "~" + st.cwd.slice(st.home.length);
    return st.cwd;
  }

  const COMPLETE_EXTRA = ["apt", "apt-get", "sudo", "clear"];

  function complete(st, line) {
    const m = /^(.*?)(\S*)$/.exec(line);
    const before = m[1];
    const word = m[2];
    const fs = st.fs;
    const firstWord = !before.trim() || /^\s*sudo\s+$/.test(before) || /[|;&]\s*$/.test(before);
    let matches;
    let dirPrefix = "";
    if (firstWord && word.indexOf("/") < 0) {
      matches = Object.keys(COMMANDS).concat(UNSUPPORTED, COMPLETE_EXTRA, ["bash", "sh"]).filter((n) => n.indexOf(word) === 0 && n !== "[");
      matches = Array.from(new Set(matches)).sort();
    } else {
      const slash = word.lastIndexOf("/");
      dirPrefix = slash >= 0 ? word.slice(0, slash + 1) : "";
      const base = word.slice(slash + 1);
      const dirPath = dirPrefix.charAt(0) === "~" ? st.home + dirPrefix.slice(1) : dirPrefix;
      const r = fs.stat(fs.resolve(dirPath || ".", st.cwd));
      matches = [];
      if (r.node && r.node.t === "d") {
        matches = fs.names(r.node).filter((n) => n.indexOf(base) === 0 && (base || n.charAt(0) !== ".")).sort().map((n) => {
          const child = r.node.c[n];
          let isDir = child.t === "d";
          if (child.t === "l") {
            const target = fs.stat(fs.resolve(dirPath + n, st.cwd));
            isDir = !!target.node && target.node.t === "d";
          }
          return n + (isDir ? "/" : "");
        });
      }
    }
    if (!matches.length) return { line: line, matches: [] };
    let common = matches[0];
    matches.forEach((n) => {
      while (n.indexOf(common) !== 0) common = common.slice(0, -1);
    });
    let completed = before + dirPrefix + common;
    if (matches.length === 1 && common.slice(-1) !== "/") completed += " ";
    return { line: completed, matches: matches };
  }

  root.MobaShell = {
    deployManager: (fs, name) => {
      fs.domains = [{ name: name, running: true, autostart: false }, { name: "failed-vm", running: true, autostart: false }];
      fs.put("/var/morpheus/kvm/local", mkDir());
      fs.put("/var/morpheus/kvm/local/" + name + ".qcow2", mkFile("Simulated manager disk\n"));
      fs.put("/var/morpheus/kvm/local/failed-vm.qcow2", mkFile("Simulated failed deployment disk\n"));
    },
    createFs: createFs,
    createState: createState,
    run: run,
    promptPath: promptPath,
    complete: complete,
    human: human,
    modeStr: modeStr,
    listDir: (st, abs) => {
      const r = st.fs.stat(abs);
      if (!r.node || r.node.t !== "d") return null;
      return st.fs.names(r.node).map((n) => ({ name: n, node: r.node.c[n] }));
    },
    writeUpload: (st, name, bytes) => {
      const abs = st.fs.resolve(name, st.cwd);
      const err = st.fs.writeFile(abs, "", false, st.user);
      if (err) return false;
      const node = st.fs.stat(abs).node;
      node.size = bytes;
      return true;
    }
  };
})(window);
