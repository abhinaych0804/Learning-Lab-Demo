(function () {
  const note = document.getElementById("heroNote");

  function onProductClick(event) {
    const product = event.currentTarget.dataset.product;

    if (!window.SimLabsAuth.getUser()) {
      note.textContent = `Please log in to open the ${product} labs.`;
      window.SimLabsAuth.openModal(event.currentTarget);
      return;
    }

    if (product === "VME") {
      window.location.href = "VME/index.html";
      return;
    }

    note.textContent = `${product} labs are coming soon.`;
  }

  window.SimLabsAuth.onChange(function (user) {
    note.textContent = user ? `Welcome back, ${user.fullName}.` : "";
  });

  document.querySelectorAll("[data-product]").forEach(function (button) {
    button.addEventListener("click", onProductClick);
  });

  window.SimLabsAuth.init().then(function () {
    if (new URLSearchParams(window.location.search).get("login") === "1" && !window.SimLabsAuth.getUser()) {
      window.SimLabsAuth.openModal();
    }
  });
})();
