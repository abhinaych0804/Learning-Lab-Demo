(function () {
  const request = window.SimLabsApi.request;
  const $ = (id) => document.getElementById(id);

  const STATUS_LABELS = {
    completed: "Completed",
    in_progress: "In progress",
    not_started: "Not started"
  };

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  function showError(message) {
    $("managerError").textContent = message;
    $("managerError").hidden = false;
  }

  function formatDate(value) {
    return value ? new Date(value).toLocaleString() : "";
  }

  function formatDuration(ms) {
    const totalSeconds = Math.round((ms || 0) / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = String(totalSeconds % 60).padStart(2, "0");
    return `${minutes}:${seconds}`;
  }

  function statusBadge(status, text) {
    const modifier = status === "completed" ? "completed" : status === "in_progress" ? "in-progress" : "";
    return el("span", `mgr-status ${modifier ? "mgr-status--" + modifier : ""}`.trim(), text || STATUS_LABELS[status] || status);
  }

  function scoreChip(score) {
    if (score === null || score === undefined) return el("span", "mgr-score-chip", "-");
    const modifier = score >= 75 ? " mgr-score-chip--good" : score < 50 ? " mgr-score-chip--weak" : "";
    return el("span", `mgr-score-chip${modifier}`, String(score));
  }

  function renderPending(pending) {
    const list = $("pendingList");
    list.replaceChildren();
    $("pendingEmpty").hidden = pending.length > 0;

    pending.forEach((person) => {
      const row = el("div", "mgr-request");
      const who = el("div");
      who.append(el("div", "mgr-person-name", person.fullName), el("div", "mgr-person-meta", `${person.email} · requested ${formatDate(person.requestedAt)}`));

      const actions = el("div", "mgr-request__actions");
      const approve = el("button", "submit-btn", "Approve");
      approve.type = "button";
      const decline = el("button", "submit-btn submit-btn--secondary", "Decline");
      decline.type = "button";
      approve.addEventListener("click", () => decide(person.id, "approve", [approve, decline]));
      decline.addEventListener("click", () => decide(person.id, "decline", [approve, decline]));
      actions.append(approve, decline);

      row.append(who, actions);
      list.append(row);
    });
  }

  async function decide(userId, decision, buttons) {
    buttons.forEach((b) => (b.disabled = true));
    const { ok, data } = await request(`/api/manager/requests/${userId}/decision`, {
      method: "POST",
      body: { decision }
    });
    if (!ok) {
      buttons.forEach((b) => (b.disabled = false));
      showError(data.message || "Could not save your decision. Please try again.");
      return;
    }
    await load();
  }

  function renderStats(reports, pending, labIds) {
    const totalSlots = reports.length * labIds.length;
    const completed = reports.reduce(
      (sum, r) => sum + r.labs.filter((l) => l.status === "completed").length,
      0
    );
    const bests = reports.flatMap((r) => r.labs.map((l) => l.best)).filter((b) => b !== null);

    $("statReports").textContent = String(reports.length);
    $("statPending").textContent = String(pending.length);
    $("statCompleted").textContent = totalSlots ? `${Math.round((completed / totalSlots) * 100)}%` : "0%";
    $("statAvgScore").textContent = bests.length
      ? String(Math.round(bests.reduce((a, b) => a + b, 0) / bests.length))
      : "-";
  }

  function renderStatusChart(reports, labIds) {
    const chart = $("statusChart");
    chart.replaceChildren();
    if (reports.length === 0 || labIds.length === 0) {
      chart.append(el("p", "mgr-section__empty", "No data yet."));
      return;
    }

    reports.forEach((r) => {
      const counts = { completed: 0, in_progress: 0, not_started: 0 };
      const activeLabs = [];
      r.labs.forEach((l) => {
        const key = l.status === "completed" || l.status === "in_progress" ? l.status : "not_started";
        counts[key] += 1;
        if (key !== "not_started") activeLabs.push(l);
      });

      const row = el("div", "mgr-bar-row mgr-bar-row--labs");
      const track = el("div", "mgr-bar-track");
      track.setAttribute("role", "img");
      track.setAttribute(
        "aria-label",
        `${r.fullName}: ${activeLabs.map((l) => `${l.name} ${STATUS_LABELS[l.status].toLowerCase()}`).join(", ") || "no labs started"}`
      );
      [
        ["completed", "var(--hpe-color-foreground-ok)"],
        ["in_progress", "var(--hpe-color-foreground-warning)"],
        ["not_started", "var(--surface-3)"]
      ].forEach(([key, color]) => {
        if (counts[key] === 0) return;
        const seg = el("div", "mgr-bar-fill");
        seg.style.width = `${(counts[key] / labIds.length) * 100}%`;
        seg.style.background = color;
        track.append(seg);
      });

      const who = el("div");
      who.append(el("span", "mgr-person-name", r.fullName));
      const labList = el("div", "mgr-lab-list");
      if (activeLabs.length === 0) {
        labList.append(el("span", "mgr-person-meta", "No labs started"));
      } else {
        activeLabs.forEach((l) => labList.append(statusBadge(l.status, `${l.name} · ${STATUS_LABELS[l.status]}`)));
      }
      who.append(labList);

      row.append(who, track);
      chart.append(row);
    });
  }

  function renderScoreChart(reports) {
    const chart = $("scoreChart");
    chart.replaceChildren();
    if (reports.length === 0) {
      chart.append(el("p", "mgr-section__empty", "No data yet."));
      return;
    }

    reports.forEach((r) => {
      const bests = r.labs.map((l) => l.best).filter((b) => b !== null);
      const best = bests.length ? Math.max(...bests) : null;

      const row = el("div", "mgr-bar-row");
      const track = el("div", "mgr-bar-track");
      const fill = el("div", "mgr-bar-fill");
      fill.style.width = `${best || 0}%`;
      fill.style.background =
        best === null ? "transparent" : best >= 75 ? "var(--hpe-color-foreground-ok)" : best < 50 ? "var(--hpe-color-foreground-critical)" : "var(--hpe-color-foreground-warning)";
      track.append(fill);

      row.append(el("span", "mgr-person-name", r.fullName), track, scoreChip(best));
      chart.append(row);
    });
  }

  function renderReports(reports, labIds) {
    const body = $("reportsBody");
    body.replaceChildren();
    $("reportsEmpty").hidden = reports.length > 0;
    $("reportsTable").hidden = reports.length === 0;

    reports.forEach((r) => {
      r.labs.forEach((lab) => {
        const row = el("tr");
        row.append(
          el("td", null),
          el("td", null, lab.name),
          el("td", null),
          el("td", null),
          el("td", null),
          el("td", null, String(lab.attempts)),
          el("td", null)
        );

        const nameCell = row.cells[0];
        nameCell.append(el("div", "mgr-person-name", r.fullName), el("div", "mgr-person-meta", r.email));
        row.cells[2].append(statusBadge(lab.status));
        row.cells[3].append(scoreChip(lab.best));
        row.cells[4].append(scoreChip(lab.latest));

        const toggle = el("button", "topbar-btn", lab.scores.length ? "Show scores" : "No scores");
        toggle.type = "button";
        toggle.disabled = lab.scores.length === 0;
        toggle.setAttribute("aria-expanded", "false");
        row.cells[6].append(toggle);

        const historyRow = el("tr");
        historyRow.hidden = true;
        const historyCell = el("td");
        historyCell.colSpan = 7;
        const list = el("div", "mgr-history");
        lab.scores.forEach((s) => {
          list.append(
            el(
              "div",
              "mgr-history__item",
              `${formatDate(s.createdAt)} · ${s.total}/100 · ${s.grade} · ${formatDuration(s.elapsedMs)} · fault: ${s.fault}`
            )
          );
        });
        historyCell.append(list);
        historyRow.append(historyCell);

        toggle.addEventListener("click", () => {
          const open = historyRow.hidden;
          historyRow.hidden = !open;
          toggle.setAttribute("aria-expanded", String(open));
          toggle.textContent = open ? "Hide scores" : "Show scores";
        });

        body.append(row, historyRow);
      });
    });
  }

  async function load() {
    const { ok, data } = await request("/api/manager/reports");
    if (!ok) {
      showError(data.message || "Could not load your reports.");
      return;
    }
    $("managerError").hidden = true;
    renderPending(data.pending);
    renderStats(data.reports, data.pending, data.labIds);
    renderStatusChart(data.reports, data.labIds);
    renderScoreChart(data.reports);
    renderReports(data.reports, data.labIds);
  }

  async function init() {
    const session = await request("/api/me");
    if (!session.ok) {
      window.location.href = "../index.html?login=1";
      return;
    }
    if (session.data.user.role !== "manager") {
      window.location.href = "../index.html";
      return;
    }

    $("managerName").textContent = session.data.user.fullName;
    $("managerLogoutBtn").addEventListener("click", async () => {
      await request("/api/auth/logout", { method: "POST" });
      window.location.href = "../index.html";
    });

    await load();
  }

  init();
})();
