(function () {
  const THEME_KEY = "simlabs-theme";

  function storedTheme() {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      return saved === "dark" ? "dark" : "light";
    } catch {
      return "light";
    }
  }

  function setTheme(mode) {
    document.documentElement.setAttribute("data-mode", mode);
    try {
      localStorage.setItem(THEME_KEY, mode);
    } catch {
      // Storage unavailable; the theme just will not persist.
    }
  }

  document.documentElement.setAttribute("data-mode", storedTheme());

  document.addEventListener("DOMContentLoaded", function () {
    const toggle = document.getElementById("themeToggle");
    if (!toggle) return;
    toggle.addEventListener("click", function () {
      const dark = document.documentElement.getAttribute("data-mode") === "dark";
      setTheme(dark ? "light" : "dark");
    });
  });
})();
