(function () {
  const desktop = document.getElementById("vmeDesktop");
  const toast = document.getElementById("vmeToast");
  const startBtn = document.getElementById("vmeStartBtn");
  const startMenu = document.getElementById("vmeStartMenu");
  const clockTime = document.getElementById("vmeClockTime");
  const clockDate = document.getElementById("vmeClockDate");
  const icons = Array.from(desktop.querySelectorAll(".vme-icon"));

  let toastTimer = null;
  let busyCount = 0;

  // Simulates the lag of a real machine: shows a busy cursor, then runs `done`.
  function busy(minMs, maxMs, done) {
    if (window.SimLabsProgress && window.SimLabsProgress.replaying) return done();
    busyCount++;
    desktop.classList.add("is-busy");
    setTimeout(function () {
      busyCount--;
      if (!busyCount) desktop.classList.remove("is-busy");
      done();
    }, minMs + Math.random() * (maxMs - minMs));
  }

  function launchApp(name) {
    busy(300, 600, function () {
      showToast(name + " is not available yet.");
    });
  }

  function updateClock() {
    const now = new Date();
    clockTime.textContent = now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    clockDate.textContent = now.toLocaleDateString("en-US");
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.remove("is-visible");
    }, 1800);
  }

  function selectIcon(target) {
    icons.forEach(function (icon) {
      icon.classList.toggle("is-selected", icon === target);
    });
  }

  function toggleStartMenu(force) {
    const open = typeof force === "boolean" ? force : startMenu.hidden;
    startMenu.hidden = !open;
    startBtn.classList.toggle("is-active", open);
    startBtn.setAttribute("aria-expanded", String(open));
  }

  icons.forEach(function (icon) {
    const name = icon.querySelector(".vme-icon__label").textContent.trim();
    icon.addEventListener("click", function (event) {
      event.stopPropagation();
      toggleStartMenu(false);
      selectIcon(icon);
    });
    function activate() {
      if (icon.dataset.open) {
        document.dispatchEvent(new CustomEvent("vme:open-explorer", { detail: { target: icon.dataset.open } }));
      } else if (icon.dataset.app) {
        document.dispatchEvent(new CustomEvent("vme:open-" + icon.dataset.app));
      } else {
        launchApp(name);
      }
    }
    icon.addEventListener("dblclick", activate);
    icon.addEventListener("keydown", function (event) {
      if (event.key === "Enter") activate();
    });
  });

  desktop.addEventListener("click", function () {
    selectIcon(null);
    toggleStartMenu(false);
  });

  startBtn.addEventListener("click", function (event) {
    event.stopPropagation();
    toggleStartMenu();
  });

  desktop.querySelectorAll("[data-placeholder]").forEach(function (el) {
    el.addEventListener("click", function (event) {
      event.stopPropagation();
      toggleStartMenu(false);
      if (el.classList.contains("vme-taskbar__app")) launchApp(el.dataset.placeholder);
      else showToast(el.dataset.placeholder + " is not available yet.");
    });
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") toggleStartMenu(false);
  });

  window.VmeDesktop = { busy: busy, toast: showToast };

  updateClock();
  setInterval(updateClock, 1000);
})();
