// Lab progress: reports status (in progress / completed) to the server and keeps guided-mode steps in a cookie.
(function () {
  "use strict";

  const script = document.currentScript;
  const labId = script && script.dataset.lab;
  if (!labId || !window.SimLabsApi) return;

  const api = window.SimLabsApi;
  const mode = document.documentElement.dataset.labMode;
  const COOKIE = "simlabs_progress_" + labId;
  const MAX_AGE = 30 * 24 * 60 * 60;

  let userId = null;
  const ready = api.request("/api/me").then((result) => {
    userId = result.ok && result.data.user ? result.data.user.id : null;
    return userId;
  });

  let completed = false;
  function setStatus(status) {
    return api.request("/api/labs/" + encodeURIComponent(labId) + "/progress", { method: "PUT", body: { status: status } });
  }
  function complete() {
    if (completed) return;
    completed = true;
    recording = false;
    clearStep();
    setStatus("completed");
  }

  // Cookie value is "<userId>:<step>" so another account on the same browser does not pick it up.
  function writeCookie(value, maxAge) {
    const secure = window.location.protocol === "https:" ? "; Secure" : "";
    document.cookie = COOKIE + "=" + encodeURIComponent(value) + "; path=/; max-age=" + maxAge + "; SameSite=Lax" + secure;
  }
  function loadStep() {
    const entry = document.cookie.split("; ").find((c) => c.indexOf(COOKIE + "=") === 0);
    if (!entry || userId == null) return 0;
    const parts = decodeURIComponent(entry.slice(COOKIE.length + 1)).split(":");
    const step = Number(parts[1]);
    return parts[0] === String(userId) && Number.isInteger(step) && step > 0 ? step : 0;
  }
  function saveStep(step) {
    if (userId != null) writeCookie(userId + ":" + step, MAX_AGE);
  }
  function clearStep() {
    writeCookie("", 0);
  }

  ready.then((id) => {
    if (id != null) setStatus("in_progress");
  });
  // Guided mode completes through its own step flow; practice completes when the learner finishes the scorecard.
  document.addEventListener("vme:lab-complete", complete);

  // Guided labs record the learner's trusted clicks, double-clicks, keys and field values inside the desktop.
  const actionsUrl = "/api/labs/" + encodeURIComponent(labId) + "/actions";
  const DESKTOP = ".vme-desktop";
  const MAX_RECORDED = 10000;
  const WAIT_STEP_MS = 50;
  const WAIT_LIMIT_MS = 1500;
  const REPLAY_BUDGET_MS = 60000;
  const SETTLE_AFTER_ENTER_MS = 300;
  const sleep = (ms) => new Promise((resolveSleep) => setTimeout(resolveSleep, ms));
  let recording = false;
  let actions = [];
  let saveTimer = null;

  // Element location: nearest id (or the desktop) plus child indexes, so replay can find the same node.
  function locate(target) {
    const segs = [];
    let node = target;
    while (node && !node.matches(DESKTOP)) {
      if (node.id) return { a: node.id, s: segs.join("/") };
      const index = Array.prototype.indexOf.call(node.parentElement.children, node);
      segs.unshift(node.tagName.toLowerCase() + "." + index);
      node = node.parentElement;
    }
    return node ? { a: "", s: segs.join("/") } : null;
  }

  function resolve(rec) {
    let node = rec.a ? document.getElementById(rec.a) : document.querySelector(DESKTOP);
    if (!node) return null;
    if (!rec.s) return node;
    for (const seg of rec.s.split("/")) {
      const parts = seg.split(".");
      const child = node.children[Number(parts[1])];
      if (!child || child.tagName.toLowerCase() !== parts[0]) return null;
      node = child;
    }
    return node;
  }

  function saveActions() {
    if (userId == null) return;
    api.request(actionsUrl, { method: "PUT", body: { actions: actions } });
  }

  function push(entry) {
    if (!recording || progressApi.replaying || actions.length >= MAX_RECORDED) return;
    actions.push(entry);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveActions, 800);
  }

  function remember(type, event, extra) {
    const desktop = document.querySelector(DESKTOP);
    if (!event.isTrusted || !desktop || !desktop.contains(event.target)) return;
    const at = locate(event.target);
    if (at) push(Object.assign({ t: type, a: at.a, s: at.s }, extra));
  }

  if (mode === "guided") {
    document.addEventListener("click", (e) => remember("click", e, { c: e.ctrlKey, h: e.shiftKey, m: e.metaKey }), true);
    document.addEventListener("dblclick", (e) => remember("dbl", e, { c: e.ctrlKey, h: e.shiftKey, m: e.metaKey }), true);
    document.addEventListener("keydown", (e) => remember("key", e, { k: e.key, c: e.ctrlKey, h: e.shiftKey, l: e.altKey }), true);
    document.addEventListener(
      "input",
      (e) => {
        const t = e.target;
        if (!("value" in t)) return;
        if (t.type === "checkbox" || t.type === "radio") remember("check", e, { v: t.checked });
        else if (t.type !== "file") remember("input", e, { v: t.value });
      },
      true
    );
    document.addEventListener("paste", (e) => remember("paste", e, { v: (e.clipboardData && e.clipboardData.getData("text")) || "" }), true);
  }

  function apply(node, a) {
    if (a.t === "click" || a.t === "dbl") {
      const init = { bubbles: true, cancelable: true, view: window, ctrlKey: !!a.c, shiftKey: !!a.h, metaKey: !!a.m };
      node.dispatchEvent(new MouseEvent(a.t === "click" ? "click" : "dblclick", init));
    }
    else if (a.t === "paste") {
      const data = new DataTransfer();
      data.setData("text", a.v);
      node.dispatchEvent(new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true }));
    }
    else if (a.t === "key") node.dispatchEvent(new KeyboardEvent("keydown", { key: a.k, ctrlKey: a.c, shiftKey: a.h, altKey: a.l, bubbles: true, cancelable: true }));
    else if (a.t === "input" || a.t === "check") {
      if (a.t === "input") node.value = a.v;
      else node.checked = a.v;
      node.dispatchEvent(new Event("input", { bubbles: true }));
      node.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  // Waits only as long as the target is missing or the desktop is busy, so the app's timed UI is ready.
  async function waitForTarget(rec) {
    const desktop = document.querySelector(DESKTOP);
    const started = Date.now();
    // Hidden dialogs (like save-password) are not clickable until the app shows them.
    const isReady = (n) => n && n.getClientRects().length > 0 && !(desktop && desktop.classList.contains("is-busy"));
    let node = resolve(rec);
    while (!isReady(node) && Date.now() - started < WAIT_LIMIT_MS) {
      await sleep(WAIT_STEP_MS);
      node = resolve(rec);
    }
    return node;
  }

  const loading = document.createElement("div");
  loading.className = "ld-page vme-replay";
  loading.setAttribute("role", "status");
  loading.innerHTML = '<div class="ld-card"><div class="ld-spin"></div><h1>Restoring your lab</h1><p>Replaying your saved steps. Please wait.</p></div>';

  async function replay(list) {
    const desktop = document.querySelector(DESKTOP);
    progressApi.replaying = true;
    if (desktop) desktop.classList.add("is-replaying");
    document.body.appendChild(loading);
    try {
      const deadline = Date.now() + REPLAY_BUDGET_MS;
      for (const a of list || []) {
        if (Date.now() > deadline) break;
        const node = await waitForTarget(a);
        if (node) apply(node, a);
        // Enter submits a password or command, and the app shows its next state after a timer.
        if (a.t === "key" && a.k === "Enter") await sleep(SETTLE_AFTER_ENTER_MS);
      }
    } finally {
      progressApi.replaying = false;
      loading.remove();
      if (desktop) desktop.classList.remove("is-replaying");
      actions = (list || []).slice();
      recording = true;
    }
  }

  function loadActions() {
    return api.request(actionsUrl).then((result) => (result.ok && Array.isArray(result.data.actions) ? result.data.actions : []));
  }

  function begin() {
    actions = [];
    recording = true;
    saveActions();
  }

  const progressApi = {
    ready: ready,
    loadStep: loadStep,
    saveStep: saveStep,
    clearStep: clearStep,
    loadActions: loadActions,
    replay: replay,
    begin: begin,
    replaying: false
  };
  window.SimLabsProgress = progressApi;
})();
