(function () {
  const isLocal = ["localhost", "127.0.0.1"].includes(window.location.hostname);

  // Served by Express (port 5000) or behind a reverse proxy: same origin.
  // Opened from another local dev server: call the API on the same host so the session cookie is same-site.
  const base =
    window.SIMLABS_API_BASE ??
    (isLocal && window.location.port !== "5000" ? `http://${window.location.hostname}:5000` : "");

  async function request(path, { method = "GET", body } = {}) {
    try {
      const response = await fetch(base + path, {
        method,
        credentials: "include",
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined
      });

      let data = {};
      try {
        data = await response.json();
      } catch {
        // Non-JSON response; leave data empty.
      }

      return { ok: response.ok && data.success !== false, status: response.status, data };
    } catch {
      return { ok: false, status: 0, data: { message: "Unable to reach the server. Please try again." } };
    }
  }

  window.SimLabsApi = { request };
})();
