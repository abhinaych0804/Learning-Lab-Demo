// Shows the signed-in learner's status (not started / in progress / completed) on each lab card.
(function () {
  "use strict";

  if (!window.SimLabsApi) return;

  const LABELS = {
    not_started: { badge: "Not started", cta: "Start lab \u2192" },
    in_progress: { badge: "In progress", cta: "Continue lab \u2192" },
    completed: { badge: "Completed", cta: "Start again \u2192" }
  };

  window.SimLabsApi.request("/api/labs/progress").then((result) => {
    if (!result.ok) return;
    const progress = result.data.progress || {};

    document.querySelectorAll(".vme-card[data-lab]").forEach((card) => {
      const status = LABELS[progress[card.dataset.lab]] ? progress[card.dataset.lab] : "not_started";
      const badge = document.createElement("span");
      badge.className = "vme-card__status vme-card__status--" + status.replace("_", "-");
      badge.textContent = LABELS[status].badge;
      const title = card.querySelector(".vme-card__title");
      card.insertBefore(badge, title);
      const cta = card.querySelector(".vme-card__cta");
      if (cta) cta.textContent = LABELS[status].cta;
    });
  });
})();
