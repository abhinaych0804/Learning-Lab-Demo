// The VME pages are for signed-in users only; send everyone else back to the login prompt.
(function () {
  window.SimLabsApi.request("/api/me").then(function (result) {
    if (!result.ok && result.status !== 0) {
      window.location.replace("../index.html?login=1");
    }
  });
})();
