(function () {
  "use strict";

  window.VmeInfrastructure = function (api) {
    const { server, esc, shell, modal, close, refresh, save, toast } = api;
    const layout = "HVM 1.3 Cluster on HVM/Ubuntu 24.04";
    const fresh = () => ({ cluster: null, shares: [], vm: { managed: false, agent: "", datastore: "Local", history: [] } });
    const data = () => server.infrastructure;
    let taskTimer = null;
    const button = (text, action) => '<button type="button" class="st-btn" data-action="' + action + '">' + esc(text) + "</button>";
    const input = (key, label, value, type) => '<label class="md__row"><span class="md__label">' + esc(label) + '</span><input class="st-input" name="' + key + '" type="' + (type || "text") + '" value="' + esc(value == null ? "" : value) + '"></label>';
    const select = (key, label, options, value) => '<label class="md__row"><span class="md__label">' + esc(label) + '</span><select class="st-input" name="' + key + '">' + options.map((o) => {
      const v = typeof o === "string" ? o : o.id;
      const text = typeof o === "string" ? o : o.name;
      return '<option value="' + esc(v) + '"' + (String(v) === String(value) ? " selected" : "") + ">" + esc(text) + "</option>";
    }).join("") + "</select></label>";
    const check = (key, label, checked) => '<label class="wz-check"><input name="' + key + '" type="checkbox"' + (checked ? " checked" : "") + '><span>' + esc(label) + "</span></label>";
    const tabs = (items, current) => '<nav class="st-tabs">' + items.map((t) => '<button type="button" class="' + (current === t ? "is-on" : "") + '" data-tab="' + t + '">' + t + "</button>").join("") + "</nav>";
    const table = (heads, rows) => '<div class="si-table-wrap"><table class="si-table"><thead><tr>' + heads.map((h) => "<th>" + h + "</th>").join("") + "</tr></thead><tbody>" + (rows.length ? rows.map((r) => "<tr>" + r.map((v) => "<td>" + v + "</td>").join("") + "</tr>").join("") : '<tr><td colspan="' + heads.length + '">No records</td></tr>') + "</tbody></table></div>";
    const history = (items) => table(["Task", "Status"], items.map((h) => [esc(h.text), h.start && Date.now() < h.start ? "Queued" : h.due && Date.now() < h.due ? "In progress" : "&#10003; Complete"]));
    const fail = (form, message) => {
      const err = form.querySelector("[data-error]");
      err.textContent = message;
      err.hidden = false;
      document.dispatchEvent(new CustomEvent("vme:track", { detail: { name: "error", source: "infrastructure", message: message } }));
    };

    function form(title, body, submitText, onSubmit) {
      const box = modal('<form class="md" role="dialog" aria-modal="true" aria-labelledby="siTitle"><div class="md__head"><h2 id="siTitle">' + esc(title) + '</h2><button class="md__x" type="button" aria-label="Close">X</button></div><div class="md__body">' + body + '<p class="mp-err" data-error role="alert" hidden></p></div><div class="md__foot"><button type="button" class="st-btn" data-cancel>Cancel</button><button type="submit" class="st-btn">' + esc(submitText) + "</button></div></form>");
      box.querySelector("[data-cancel]").addEventListener("click", close);
      box.addEventListener("submit", (e) => {
        e.preventDefault();
        const values = {};
        box.querySelectorAll("[name]").forEach((el) => { values[el.name] = el.type === "checkbox" ? el.checked : el.value.trim(); });
        const error = onSubmit(values, box);
        if (error) fail(box, error);
      });
      return box;
    }

    function commit(tab) {
      save();
      close();
      resume();
      refresh(tab);
    }

    function settle() {
      const d = data();
      if (!d) return;
      let changed = false;
      const now = Date.now();
      const vm = d.vm;
      if (vm.agentDue && vm.agentDue <= now) {
        vm.agent = "9.0.1";
        delete vm.agentDue;
        changed = true;
      }
      if (vm.migrationDue && vm.migrationDue <= now) {
        vm.datastore = vm.migrationTarget;
        delete vm.migrationDue;
        delete vm.migrationTarget;
        changed = true;
      }
      if (d.cluster) d.cluster.hosts.forEach((h) => {
        if (h.due && h.due <= now) {
          delete h.due;
          changed = true;
        }
      });
      if (changed) save();
      return changed;
    }

    function pending() {
      const d = data();
      return d && (d.vm.agentDue || d.vm.migrationDue || (d.cluster && d.cluster.hosts.some((h) => h.due)));
    }

    function resume() {
      clearTimeout(taskTimer);
      if (pending()) taskTimer = setTimeout(() => {
        settle();
        resume();
      }, 1000);
    }

    function watch(tab, el, dirty) {
      if (pending() || dirty) setTimeout(() => {
        if (tab.view !== el) return;
        if (api.modalOpen()) watch(tab, el, true);
        else refresh(tab);
      }, 1000);
      return el;
    }

    function hostFields(third) {
      return (third ? select("plan", "Plan", ["Default Manual"], "Default Manual") : select("layout", "Layout", [layout], layout)) +
        '<div data-hosts>' + hostRow(0, third) + "</div>" +
        (third ? "" : button("+ SSH Host", "host")) +
        input("port", "SSH Port", "22", "number") + input("username", "SSH Username", "") +
        input("password", "SSH Password", "", "password") +
        input("management", "Management Net Interface", "ens192") +
        input("storage", "Storage Net Interface", third ? "" : "ens224") +
        input("compute", "Compute Net Interface", "ens256") + input("vlans", "Compute Vlans", "");
    }

    function hostRow(i, third) {
      return '<fieldset><legend>SSH Host ' + (i + 1) + "</legend>" +
        (third ? "" : input("hostName" + i, "SSH Hosts Name", "")) +
        input("hostIp" + i, third ? "SSH Host IP" : "IP", "") + "</fieldset>";
    }

    function clusterWizard(tab, third) {
      const c = data().cluster;
      const groups = server.groups;
      const clouds = server.clouds.filter((x) => x.type === "private" && x.enabled);
      if (!groups.length || !clouds.length) return toast("Create an infrastructure group and an enabled Private cloud first.");
      const state = {};
      let stage = 0;
      const stages = third ? ["Name", "Configure", "Review"] : ["Type", "Group", "Configure", "Review"];
      let hostCount = 1;
      function render() {
        let body = "";
        const name = third ? "Node-03" : "HPE HVM Cluster";
        const configure = stage === stages.indexOf("Configure");
        if (stages[stage] === "Type") body = select("type", "Cluster Type", ["Select", "HVM"], state.type || "Select");
        if (stages[stage] === "Group") body = select("groupId", "Group", groups, state.groupId);
        if (stages[stage] === "Name") body = input("name", "Name", state.name) + input("description", "Description", state.description);
        if (configure) body = (third ? "" : select("cloudId", "Cloud", clouds.filter((x) => String(x.groupId) === String(state.groupId)), state.cloudId) +
          input("name", "Cluster Name", state.name) + input("description", "Description", state.description)) + hostFields(third);
        if (stages[stage] === "Review") body = "<p>Verify the settings before completing " + esc(state.name || name) + ".</p><dl>" +
          Object.keys(state).filter((k) => k !== "password").map((k) => "<dt>" + esc(k) + "</dt><dd>" + esc(state[k]) + "</dd>").join("") + "</dl>";
        const box = form((third ? "Add HPE VM Hypervisor" : "Create Cluster") + " - " + stages[stage], body, stage === stages.length - 1 ? "Complete" : "Next", (v) => {
          Object.assign(state, v);
          if (stages[stage] === "Type" && state.type !== "HVM") return "Select HVM.";
          if (stages[stage] === "Group" && !state.groupId) return "Select a group.";
          if (stages[stage] === "Name" && !state.name) return "Name is required.";
          if (configure) {
            if (!state.name || (!third && !state.cloudId)) return "Name and an associated cloud are required.";
            if (!third && (state.name !== "HPE HVM Cluster" || state.description !== "hvmcluster")) return "Use Cluster Name HPE HVM Cluster and Description hvmcluster for this lab.";
            if (state.port !== "22" || state.username !== "student" || state.password !== "!HPEstorage2050") return "Host authentication failed. Use the supplied SSH port and student credentials.";
            if (state.management !== "ens192" || state.compute !== "ens256" || state.vlans !== "50-53" || (third && state.storage !== "ens224")) return "Check the management, storage, compute interfaces and VLAN range in the lab brief.";
            if (!third && hostCount !== 2) return "Add exactly two initial SSH hosts using + SSH Host.";
            const count = third ? 1 : 2;
            for (let i = 0; i < count; i++) {
              const expected = third ? 3 : i + 1;
              if (state["hostIp" + i] !== "172.16.3." + (30 + expected) || (!third && state["hostName" + i] !== "Node-0" + expected)) return "Check the SSH host name and IP against the lab brief.";
            }
            if (third && (state.name !== "Node-03" || c.hosts.some((h) => h.name === state.name))) return "Use Node-03; a node can only be added once.";
          }
          if (stage < stages.length - 1) {
            stage++;
            render();
            return;
          }
          const due = Date.now() + 6000;
          if (third) {
            c.hosts.push({ name: state.name, ip: state.hostIp0, management: state.management, storage: state.storage, compute: state.compute, vlans: state.vlans, due: due });
            c.history.push({ text: "Node-03: Server provisioning", due: due - 3000 }, { text: "Node-03: Post Provisioning Operations", start: due - 3000, due: due });
          } else {
            data().cluster = {
              name: state.name, description: state.description, groupId: Number(state.groupId), cloudId: Number(state.cloudId),
              layout: state.layout, management: state.management, storage: state.storage, compute: state.compute, vlans: state.vlans,
              hosts: [0, 1].map((i) => ({ name: state["hostName" + i], ip: state["hostIp" + i], due: due })),
              networks: [50, 51, 52, 53, null].map((vlan) => ({ vlan: vlan, name: vlan === null ? "Management" : "Compute VLAN " + vlan, dhcp: false, override: false, access: true, default: false })),
              datastore: null, history: [{ text: "Cluster provisioning", due: due }]
            };
          }
          delete state.password;
          commit(tab);
        });
        if (stage > 0) {
          const previous = document.createElement("button");
          previous.type = "button";
          previous.className = "st-btn";
          previous.textContent = "Previous";
          previous.addEventListener("click", () => {
            box.querySelectorAll("[name]").forEach((el) => { state[el.name] = el.value.trim(); });
            stage--;
            render();
          });
          box.querySelector(".md__foot").prepend(previous);
        }
        if (configure) {
          hostCount = 1;
          if (!third && state.hostIp1 !== undefined) {
            box.querySelector("[data-hosts]").insertAdjacentHTML("beforeend", hostRow(hostCount++, false));
          }
          box.querySelectorAll("[name]").forEach((el) => { if (state[el.name] !== undefined) el.value = state[el.name]; });
          const add = box.querySelector('[data-action="host"]');
          if (add) add.addEventListener("click", () => {
            if (hostCount >= 2) return;
            box.querySelector("[data-hosts]").insertAdjacentHTML("beforeend", hostRow(hostCount++, false));
          });
        }
      }
      render();
    }

    function editNetwork(tab, network) {
      form("Edit Network", input("name", "Display Name", network.name) +
        "<p>VLAN: " + (network.vlan === null ? "Management" : network.vlan) + "</p>" +
        check("dhcp", "DHCP Server", network.dhcp) + check("override", "Allow IP Override", network.override) +
        '<details><summary>Group Access</summary>' + check("access", "HPE HVM Group Access", network.access) +
        check("default", "Default network for HPE HVM Group", network.default) + "</details>", "Save Changes", (v) => {
        if (!v.name) return "Display Name is required.";
        if (v.default && !v.access) return "A default network must allow group access.";
        if (v.default) data().cluster.networks.forEach((n) => { n.default = false; });
        Object.assign(network, v);
        commit(tab);
      });
    }

    function datastore(tab) {
      const current = data().cluster.datastore;
      const d = current || { name: "", host: "", directory: "", version: "Default", image: false, access: false, heartbeat: false };
      form(current ? "Edit Data Store" : "Add Data Store", select("type", "Type", ["NFS Datastore"], "NFS Datastore") +
        input("name", "Name", d.name) + input("host", "Source Host", d.host) + input("directory", "Source Directory", d.directory) +
        select("version", "Version", ["Default", "3", "4"], d.version) + check("image", "Image Target", d.image) +
        check("heartbeat", "Heartbeat Target", d.heartbeat) + '<details open><summary>Group Access</summary>' + check("access", "HPE HVM Group Access", d.access) + "</details>", current ? "Save Changes" : "Save", (v) => {
        if (!v.name || !v.host || v.directory[0] !== "/") return "Name, Source Host and an absolute Source Directory are required.";
        if (current && data().vm.datastore === current.name && v.name !== current.name) return "The datastore is in use; retain its name.";
        data().cluster.datastore = v;
        commit(tab);
      });
    }

    function addShare(tab, existing) {
      const s = existing || { name: "", host: "", folder: "", active: true };
      form(existing ? "Edit File Share" : "Add File Share", select("type", "Type", ["NFSv3"], "NFSv3") + input("name", "Name", s.name) + input("host", "Host", s.host) +
        input("folder", "Export Folder", s.folder) + check("active", "Active", s.active) + check("backup", "Default Backup Target", s.backup) +
        check("update", "Update existing backups", s.update) + check("archive", "Default Deployment Archive Target", s.archive) +
        check("images", "Default Virtual Image Store", s.images) + check("support", "Default Support Bundle Store", s.support), "Save Changes", (v) => {
        if (!v.name || !v.host || v.folder[0] !== "/") return "Name, Host and an absolute Export Folder are required.";
        if (data().shares.some((x) => x !== existing && x.name.toLowerCase() === v.name.toLowerCase())) return "A file share with this name already exists.";
        if (v.update && !v.backup) return "Update existing backups requires a backup target.";
        if (existing) Object.assign(existing, v);
        else data().shares.push(v);
        commit(tab);
      });
    }

    function convert(tab) {
      const vm = data().vm;
      form("Convert To Managed", input("username", "Username", "") + input("password", "Password", "", "password") +
        select("agent", "Agent", ["No Agent install"], "No Agent install") +
        select("type", "Instance Type", ["Ubuntu"], "Ubuntu") + select("version", "Version", ["24.04"], "24.04") +
        select("layout", "Layout", ["Single KVM VM"], "Single KVM VM") +
        select("os", "Operating System", ["Ubuntu 24.04 64-bit"], "Ubuntu 24.04 64-bit") +
        "<p>Plan: 4 CPU, 16GB Memory (discovered from the deployed VM)</p>", "Save Changes", (v) => {
        if (v.username !== "admin" || v.password !== (api.managerPassword() || "!HPEstorage2050")) return "Guest authentication failed. Use the manager VM credentials entered during installation.";
        vm.managed = true;
        vm.history.push({ text: "Convert To Managed - No Agent install" });
        commit(tab);
      });
    }

    function installAgent(tab) {
      const vm = data().vm;
      if (!vm.managed) return toast("Convert the VM to managed first.");
      if (vm.agent || vm.agentDue) return toast("The agent is already installed or installation is in progress.");
      form("Install Agent", "<p>Install the Morpheus Agent on hpe-vm?</p>", "OK", () => {
        vm.agentDue = Date.now() + 4000;
        vm.history.push({ text: "Install Morpheus Agent", due: vm.agentDue });
        commit(tab);
      });
    }

    function reconfigure(tab) {
      const vm = data().vm;
      const ds = data().cluster.datastore;
      if (!ds || !ds.access) return toast("Add a datastore with group access before moving the disk.");
      if (vm.agentDue || vm.migrationDue) return toast("Wait for the current VM operation to finish.");
      form("Reconfigure", select("datastore", "Volumes - root disk", ["Local", ds.name], vm.datastore) + "<p>CD-ROM: no change</p>", "Reconfigure", (v) => {
        if (v.datastore === vm.datastore) return "Select a different datastore to move the disk.";
        vm.migrationTarget = v.datastore;
        vm.migrationDue = Date.now() + 5000;
        vm.history.push({ text: "Resize VM / move local data to " + v.datastore, due: vm.migrationDue });
        commit(tab);
      });
    }

    function build(tab) {
      settle();
      const d = data();
      const c = d.cluster;
      const which = tab.page.section;
      const current = tab.page.detail || (which === "clusters" ? "Hosts" : which === "compute" ? "Virtual Machines" : "FileShares");
      let body = "";
      if (which === "clusters") {
        if (!c) body = button("+ Add Cluster", "cluster") + "<p>Create an HVM cluster to manage its hosts, networks and storage.</p>";
        else if (!tab.page.clusterDetail) body = table(["Name", "Hosts", "Cloud"], [[button(c.name, "cluster-details"), String(c.hosts.length), esc((server.clouds.find((x) => x.id === c.cloudId) || {}).name || "")]]);
        else {
          body = "<h2>" + esc(c.name) + "</h2><details><summary>Actions</summary>" + button("Add HPE VM Hypervisor", "node") + "</details>" +
            tabs(["Hosts", "Networks", "Storage", "History"], current);
          if (current === "Hosts") body += table(["Name", "IP", "Status"], c.hosts.map((h) => [esc(h.name), esc(h.ip), h.due ? "Provisioning" : "Provisioned"]));
          if (current === "Networks") body += table(["Name", "VLAN", "Group Access", "Default", "Edit"], c.networks.map((n, i) => [esc(n.name), n.vlan === null ? "-" : String(n.vlan), n.access ? "HPE HVM Group" : "None", n.default ? "Yes" : "No", button("Edit", "network-" + i)]));
          if (current === "Storage") body += "<h3>Data Stores</h3>" + (!c.datastore || !c.datastore.heartbeat ? '<p class="si-warning">No heartbeat target datastore is currently set.</p>' : "") +
            button("Add", "datastore") + table(["Name", "Type", "Source", "Image Target", "Heartbeat Target", "Edit"], c.datastore ? [[esc(c.datastore.name), "NFS Datastore", esc(c.datastore.host + ":" + c.datastore.directory), c.datastore.image ? "Yes" : "No", c.datastore.heartbeat ? "Yes" : "No", button("Edit", "datastore")]] : []);
          if (current === "History") body += history(c.history);
        }
      } else if (which === "storage") {
        body = tabs(["FileShares"], "FileShares") + button("+ Add", "share") +
          table(["Name", "Type", "Host", "Export Folder", "Active", "Contents", "Edit"], d.shares.map((s, i) => [esc(s.name), esc(s.type), esc(s.host), esc(s.folder), s.active ? "Yes" : "No", s.folder === "/hpe-vm-templ" ? "Preloaded VM templates" : "Virtual images / backups", button("Edit", "share-" + i)]));
      } else if (which === "compute") {
        const vm = d.vm;
        if (!c) body = "<p>Create the HVM cluster with inventory enabled to discover hpe-vm.</p>";
        else if (!tab.page.vmDetail) body = tabs(["Virtual Machines"], "Virtual Machines") + '<label><input type="checkbox" data-vm-select> Select hpe-vm</label><details><summary>Actions</summary>' +
          button("Convert To Managed", "convert-selected") + "</details>" + table(["Name", "Host", "Type", "Plan", "Status"], [[button("hpe-vm", "vm-details"), "Node-01", vm.managed ? "Managed" : "Unmanaged", "4 CPU, 16GB Memory", vm.agentDue ? "Upgrading" : vm.migrationDue ? "Resizing" : "Provisioned"]]);
        else {
          body = "<h2>hpe-vm</h2><p>Status: " + (vm.agentDue ? "Upgrading" : vm.migrationDue ? "Resizing" : "Provisioned") +
            " | Agent Version: " + esc(vm.agent || "Not installed") + "</p>" + (vm.agent ? "<p>Discovered guest: Ubuntu 24.04 64-bit | 4 CPU | 16GB Memory | Network: ens192</p>" : "") +
            '<details><summary>Actions</summary>' + button("Install Agent", "agent") + button("Reconfigure", "reconfigure") + "</details>" +
            tabs(["Summary", "Storage", "History"], current);
          if (current === "Storage") body += table(["Device", "Datastore"], [["root disk", esc(vm.datastore)], ["CD-ROM", "-"]]);
          if (current === "History") body += history(vm.history);
        }
      }
      const label = { clusters: "Clusters", compute: "Compute", storage: "Storage" }[which];
      const el = shell(tab, "Infrastructure", label, '<section class="st-card si-panel"><h1>' + label + "</h1>" + body + "</section>");
      el.addEventListener("click", (e) => {
        const t = e.target.closest("[data-tab]");
        if (t) {
          tab.page.detail = t.dataset.tab;
          refresh(tab);
          return;
        }
        const b = e.target.closest("[data-action]");
        if (!b) return;
        const action = b.dataset.action;
        if (action === "cluster") clusterWizard(tab, false);
        else if (action === "cluster-details") api.navigate(tab, "/infrastructure/clusters/1");
        else if (action === "node") clusterWizard(tab, true);
        else if (action.indexOf("network-") === 0) editNetwork(tab, c.networks[Number(action.slice(8))]);
        else if (action === "datastore") datastore(tab);
        else if (action === "share") addShare(tab);
        else if (action.indexOf("share-") === 0) addShare(tab, d.shares[Number(action.slice(6))]);
        else if (action === "vm-details") api.navigate(tab, "/infrastructure/compute/1");
        else if (action === "convert-selected") {
          if (!el.querySelector("[data-vm-select]").checked) toast("Select the hpe-vm checkbox first.");
          else if (d.vm.managed) toast("The VM is already managed.");
          else convert(tab);
        } else if (action === "agent") installAgent(tab);
        else if (action === "reconfigure") reconfigure(tab);
      });
      return watch(tab, el);
    }

    return { fresh: fresh, build: build, settle: settle, resume: resume };
  };
})();
