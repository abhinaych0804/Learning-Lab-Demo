(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const desktop = $("vmeDesktop");
  const win = $("vmeMoba");
  const taskbarBtn = $("vmeMobaBtn");
  if (!desktop || !win || !taskbarBtn) return;

  const titlebar = $("mobaTitlebar");
  const explorerWin = $("vmeExplorer");
  let launching = false;

  const notAvailable = (name) => {
    if (window.VmeDesktop) window.VmeDesktop.toast(name + " is not available yet.");
  };

  // Guided mode listens to these events to follow what the learner does.
  const guided = document.documentElement.dataset.labMode === "guided";
  // Practice mode skips the save-password prompt and the keyboard screens, which otherwise only take their defaults.
  const practice = document.documentElement.dataset.labMode === "practice";
  const track = (name, detail) => document.dispatchEvent(new CustomEvent("vme:track", { detail: Object.assign({ name: name }, detail) }));

  // ── Menu bar and toolbar ────────────────────────────────────────
  const MENUS = ["Terminal", "Sessions", "View", "X server", "Tools", "Games", "Settings", "Macros", "Help"];
  const menubar = $("mobaMenubar");
  MENUS.forEach((label, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    if (i === 0) b.classList.add("is-on");
    b.addEventListener("click", () => notAvailable(label + " menu"));
    menubar.appendChild(b);
  });

  const svg = (body) => '<svg viewBox="0 0 32 32" aria-hidden="true">' + body + "</svg>";
  const monitor = (screen) =>
    '<rect x="3" y="4" width="26" height="19" rx="1.500" fill="#e8edf3" stroke="#6d7783"/>' + screen +
    '<path d="M11 28h10M16 23v5" stroke="#6d7783" stroke-width="2"/>';

  const TOOLS = [
    ["Session", svg(monitor('<rect x="5" y="6" width="22" height="15" fill="#2b6cb0"/><circle cx="12" cy="11" r="3" fill="#e5484d"/><circle cx="20" cy="11" r="3" fill="#3aa655"/><circle cx="16" cy="16" r="3" fill="#f6c40d"/>')), "session"],
    ["Servers", svg('<g stroke="#4a86c5" stroke-width="1.500"><path d="M16 16L16 5M16 16L6 11M16 16L26 11M16 16L9 26M16 16L23 26"/></g><g fill="#2f7fd1"><circle cx="16" cy="16" r="4"/><circle cx="16" cy="5" r="3"/><circle cx="6" cy="11" r="3"/><circle cx="26" cy="11" r="3"/><circle cx="9" cy="26" r="3"/><circle cx="23" cy="26" r="3"/></g>')],
    ["Tools", svg('<path d="M20 3l9 9-4 4-9-9z" fill="#e5484d"/><path d="M16 8l9 9-12 12-5-1-1-5z" fill="#f06a6e"/><path d="M6 26l-3 3" stroke="#5f6b7a" stroke-width="3" stroke-linecap="round"/>')],
    ["Games", svg('<path d="M7 9h18c3 0 5 4 5.500 10s-2 7-4 5l-3-4H8.500l-3 4c-2 2-4.500 1-4-5S4 9 7 9z" fill="#aab1bb" stroke="#6d7783"/><path d="M8 13v4M6 15h4" stroke="#3d4650" stroke-width="1.600"/><circle cx="22" cy="13.500" r="1.400" fill="#e5484d"/><circle cx="25" cy="16" r="1.400" fill="#3aa655"/>')],
    ["Sessions", svg('<path d="M16 2l4.200 9 9.800 1.200-7.200 6.800 1.900 9.800L16 23.800 7.300 28.800l1.900-9.800L2 12.200 11.800 11z" fill="#f6c40d" stroke="#c99a00" stroke-linejoin="round"/>')],
    ["View", svg(monitor('<rect x="5" y="6" width="22" height="15" fill="#2d3a4a"/><circle cx="16" cy="12" r="3" fill="#e8b88a"/><path d="M9 21c1-5 13-5 14 0z" fill="#3aa655"/>'))],
    ["Split", svg('<rect x="3" y="5" width="26" height="22" fill="#fff" stroke="#2f7fd1" stroke-width="2"/><path d="M16 5v22M3 16h26" stroke="#2f7fd1" stroke-width="2"/><rect x="4" y="6" width="11" height="9" fill="#9fcdf2"/><rect x="17" y="17" width="11" height="9" fill="#9fcdf2"/>')],
    ["MultiExec", svg('<path d="M5 4l11 13M27 4L16 17M16 17v11" stroke="#4b57b5" stroke-width="4" stroke-linecap="round"/>')],
    ["Tunneling", svg(monitor('<rect x="5" y="6" width="22" height="15" fill="#e8edf3"/><path d="M8 11h14M18 8l4 3-4 3M24 17H10M14 14l-4 3 4 3" fill="none" stroke="#2e9e4f" stroke-width="1.800"/>'))],
    ["Packages", svg('<path d="M6 12l10-5 10 5v12l-10 5-10-5z" fill="#8a96a6"/><path d="M6 12l10 5 10-5-10-5z" fill="#b9c3d0"/><path d="M16 17v12" stroke="#5f6b7a"/><path d="M10 4h12v6H10z" fill="#6b95c9"/>')],
    ["Settings", svg('<circle cx="12" cy="14" r="6" fill="none" stroke="#2f7fd1" stroke-width="4" stroke-dasharray="3.500 2.200"/><circle cx="12" cy="14" r="3" fill="#2f7fd1"/><circle cx="23" cy="22" r="4.500" fill="none" stroke="#4a86c5" stroke-width="3" stroke-dasharray="2.600 1.800"/>')],
    ["Help", svg('<circle cx="16" cy="16" r="13" fill="#2088e6"/><text x="16" y="23" text-anchor="middle" font-size="20" font-weight="700" font-family="Segoe UI, Arial, sans-serif" fill="#fff">?</text>')],
    null,
    ["X server", svg('<path d="M6 4h6l4 7 4-7h6L19 16l7 12h-6l-4-7-4 7H6l7-12z" fill="#3a3a3a"/><path d="M12 4l4 7-3 5-7-12z" fill="#e5484d"/><path d="M20 4h6l-7 12-3-5z" fill="#2f7fd1"/><path d="M13 16l3 5-4 7H6z" fill="#3aa655"/>')],
    ["Exit", svg('<circle cx="16" cy="16" r="13" fill="#e5484d"/><path d="M16 8v8M11 11a8 8 0 1 0 10 0" fill="none" stroke="#fff" stroke-width="2.600" stroke-linecap="round"/>'), "exit"]
  ];

  const toolbar = $("mobaToolbar");
  TOOLS.forEach((t) => {
    if (!t) {
      const gap = document.createElement("span");
      gap.className = "moba-toolbar__gap";
      toolbar.appendChild(gap);
      return;
    }
    const b = document.createElement("button");
    b.type = "button";
    b.className = "moba-tool";
    b.innerHTML = t[1] + "<span>" + t[0] + "</span>";
    b.addEventListener("click", () => {
      if (t[2] === "exit") closeWindow();
      else if (t[2] === "session") openSessionDialog();
      else notAvailable(t[0]);
    });
    toolbar.appendChild(b);
  });

  // ── Session settings dialog ─────────────────────────────────────
  const darkTile = (inner) => '<rect x="2" y="2" width="28" height="28" rx="2" fill="#2b2b2b"/>' + inner;
  const globe = (c1, c2) =>
    '<circle cx="16" cy="16" r="13" fill="' + c1 + '"/><path d="M8 9c4-2 6 1 5 4s-4 2-4 5-3 2-4-1c-1-3 0-6 3-8zM19 6c4 1 7 5 7 9-3-1-4-3-6-3s-3-3-1-6z" fill="' + c2 + '"/>';
  const screen = (inner) =>
    '<rect x="3" y="3" width="26" height="19" rx="1.500" fill="#e8edf3" stroke="#5f6b7a"/>' + inner + '<path d="M11 28h10M16 22v6" stroke="#5f6b7a" stroke-width="2"/>';

  const SESSION_TYPES = [
    ["SSH", svg(darkTile('<path d="M12 9a4.500 4.500 0 1 1 3.500 7L22 22.500l-2 2-2-2-1.500 1.500-2-2 .5-3.500A4.500 4.500 0 0 1 12 9z" fill="#f0b61a" stroke="#c99a00" stroke-width=".6"/><circle cx="14" cy="12" r="1.500" fill="#2b2b2b"/>'))],
    ["Telnet", svg(darkTile('<path d="M16 7l7 4v8l-7 5-7-5v-8z" fill="#8f5cc4"/><path d="M16 7l7 4-7 5-7-5z" fill="#c9a2ec"/>'))],
    ["Rsh", svg(darkTile('<circle cx="14" cy="14" r="4.500" fill="none" stroke="#f08a24" stroke-width="2.600"/><circle cx="21" cy="21" r="3" fill="none" stroke="#f08a24" stroke-width="2"/><path d="M17 17l2 2" stroke="#f08a24" stroke-width="2"/>'))],
    ["Xdmcp", svg(screen('<path d="M9 6l14 13M23 6L9 19" stroke="#2b2b2b" stroke-width="3"/>'))],
    ["RDP", svg(screen('<rect x="12" y="8" width="3.500" height="3.500" fill="#1e88e5"/><rect x="16.500" y="8" width="3.500" height="3.500" fill="#1e88e5"/><rect x="12" y="12.500" width="3.500" height="3.500" fill="#1e88e5"/><rect x="16.500" y="12.500" width="3.500" height="3.500" fill="#1e88e5"/>'))],
    ["VNC", svg(screen('<text x="8" y="16" font-size="9" font-weight="700" font-family="Arial, sans-serif" fill="#e5484d">v</text><text x="16" y="16" font-size="9" font-weight="700" font-family="Arial, sans-serif" fill="#2f7fd1">c</text>'))],
    ["FTP", svg(globe("#2f9e44", "#8fd694"))],
    ["SFTP", svg(globe("#f08a24", "#f8c27a"))],
    ["Serial", svg('<path d="M20 4l8 8-4 4-8-8z" fill="#8a96a6"/><path d="M14 10l8 8-9 9-8-1-1-8z" fill="#aab4c2"/><path d="M5 27l-2 2" stroke="#5f6b7a" stroke-width="3" stroke-linecap="round"/>')],
    ["File", svg(screen('<circle cx="16" cy="12.500" r="6" fill="#4aa8e0"/><path d="M12 9c2-1 3 1 2 2s-2 1-1 3M18 8c2 1 3 3 2 5" stroke="#3aa655" stroke-width="1.800" fill="none"/>'))],
    ["Shell", svg(darkTile('<path d="M8 11l5 4-5 4" fill="none" stroke="#fff" stroke-width="2"/><path d="M15 21h8" stroke="#fff" stroke-width="2"/>'))],
    ["Browser", svg(globe("#1fa0d6", "#3aa655"))],
    ["Mosh", svg('<path d="M6 24l8-14 8 14z" fill="#2f7fd1"/><circle cx="14" cy="15" r="3" fill="#9fcdf2"/><path d="M20 6a8 8 0 0 1 6 6M22 2a12 12 0 0 1 8 8" fill="none" stroke="#2f7fd1" stroke-width="2" stroke-linecap="round"/>')],
    ["Aws S3", svg('<path d="M16 3l6 3.500v7L16 17l-6-3.500v-7z" fill="#f6a623"/><path d="M9 15l6 3.500v7L9 29l-6-3.500v-7zM23 15l6 3.500v7L23 29l-6-3.500v-7z" fill="#f8bd5c"/><path d="M16 3v7M9 15v7M23 15v7" stroke="#fff" stroke-width=".8" opacity=".6"/>')],
    ["WSL", svg(darkTile('<rect x="9" y="9" width="6" height="6" fill="#2f9ae6"/><rect x="16" y="9" width="6" height="6" fill="#2f9ae6"/><rect x="9" y="16" width="6" height="6" fill="#2f9ae6"/><rect x="16" y="16" width="6" height="6" fill="#2f9ae6"/>'))]
  ];

  const SSH_ICON = SESSION_TYPES[0][1];
  const SSH_TABS = [
    ["Advanced SSH settings", SSH_ICON],
    ["Terminal settings", svg(darkTile('<circle cx="16" cy="16" r="6" fill="none" stroke="#4aa8e0" stroke-width="3.500" stroke-dasharray="3.200 2"/><circle cx="16" cy="16" r="2.500" fill="#4aa8e0"/>'))],
    ["Network settings", svg('<g stroke="#4a86c5" stroke-width="1.800"><path d="M16 16L16 5M16 16L6 11M16 16L26 11M16 16L9 26M16 16L23 26"/></g><g fill="#2f9ae6"><circle cx="16" cy="16" r="4"/><circle cx="16" cy="5" r="3"/><circle cx="6" cy="11" r="3"/><circle cx="26" cy="11" r="3"/><circle cx="9" cy="26" r="3"/><circle cx="23" cy="26" r="3"/></g>')],
    ["Bookmark settings", svg('<path d="M16 2l4.200 9 9.800 1.200-7.200 6.800 1.900 9.800L16 23.800 7.300 28.800l1.900-9.800L2 12.200 11.800 11z" fill="#f6c40d" stroke="#c99a00" stroke-linejoin="round"/>')]
  ];
  const SSH_DESC = "Secure Shell (SSH) session";

  const sshHtml =
    '<div class="moba-ssh" hidden>' +
    '<div class="moba-ssh__head">' + SSH_ICON + '<span>Basic SSH settings</span></div>' +
    '<div class="moba-ssh__basic">' +
    '<div class="moba-ssh__f"><label for="mobaSshHost">Remote host *</label><input id="mobaSshHost" class="moba-ssh__host" type="text" autocomplete="off" spellcheck="false"></div>' +
    '<div class="moba-ssh__f"><label for="mobaSshUser">Username</label>' +
    '<span class="moba-ssh__combo"><input id="mobaSshUser" type="text" autocomplete="off" spellcheck="false"><svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><path d="M1.500 3.500l3.500 3.500 3.500-3.500" fill="none" stroke="currentColor" stroke-width="1.300"/></svg></span>' +
    '<button type="button" class="moba-ssh__user" aria-label="Specify username"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="18" fill="#cfe6fa"/><circle cx="10" cy="10" r="3.500" fill="#e8b88a"/><path d="M3 20c1-5 13-5 14 0z" fill="#2f6fb5"/><circle cx="18" cy="17" r="4" fill="#f6c40d"/></svg></button></div>' +
    '<div class="moba-ssh__f"><label for="mobaSshPort">Port</label><input id="mobaSshPort" class="moba-ssh__port" type="number" min="1" max="65535" value="22"></div>' +
    '</div>' +
    '<div class="moba-ssh__tabs" role="tablist">' +
    SSH_TABS.map((t) => '<button type="button" role="tab" aria-selected="false" data-tab="' + t[0] + '">' + t[1] + "<span>" + t[0] + "</span></button>").join("") +
    '</div>' +
    '<div class="moba-ssh__box"><p id="mobaSshMsg">' + SSH_DESC + "</p>" +
    '<span class="moba-ssh__big">' + SSH_ICON + "</span></div>" +
    "</div>";

  const dlg = document.createElement("div");
  dlg.className = "moba-dlg";
  dlg.hidden = true;
  dlg.tabIndex = -1;
  dlg.setAttribute("role", "dialog");
  dlg.setAttribute("aria-modal", "true");
  dlg.setAttribute("aria-label", "Session settings");
  dlg.innerHTML =
    '<div class="moba-dlg__title"><span>Session settings</span>' +
    '<button type="button" class="moba-dlg__x" aria-label="Close"><svg width="10" height="10" viewBox="0 0 10 10"><path d="M0 0l10 10M10 0L0 10" stroke="currentColor" stroke-width="1.100"/></svg></button></div>' +
    '<div class="moba-dlg__types" role="listbox" aria-label="Session type"></div>' +
    sshHtml +
    '<div class="moba-dlg__panel"><svg viewBox="0 0 80 80" aria-hidden="true"><rect x="4" y="6" width="72" height="54" rx="3" fill="#6b8aa0"/><rect x="9" y="11" width="62" height="44" fill="#d6ebfa"/>' +
    '<path d="M33 66h14l2 8H31z" fill="#6b8aa0"/><path d="M24 74h32" stroke="#6b8aa0" stroke-width="4" stroke-linecap="round"/>' +
    '<path d="M40 16l9 5v10l-9 5-9-5V21z" fill="#2f7fd1"/><path d="M30 33l9 5v10l-9 5-9-5V38z" fill="#e5484d"/><path d="M50 33l9 5v10l-9 5-9-5V38z" fill="#3aa655"/></svg>' +
    '<p id="mobaDlgMsg">Choose a session type...</p></div>' +
    '<div class="moba-dlg__btns">' +
    '<button type="button" class="moba-dlg__btn is-default" data-act="ok"><svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="9" fill="#3aa655"/><path d="M5.500 10.500l3 3 6-6.500" fill="none" stroke="#fff" stroke-width="2.200"/></svg><span>OK</span></button>' +
    '<button type="button" class="moba-dlg__btn" data-act="cancel"><svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="9" fill="#e5484d"/><path d="M6.500 6.500l7 7M13.500 6.500l-7 7" stroke="#fff" stroke-width="2.200"/></svg><span>Cancel</span></button></div>';
  win.appendChild(dlg);

  const typesEl = dlg.querySelector(".moba-dlg__types");
  const msgEl = $("mobaDlgMsg");
  const panelEl = dlg.querySelector(".moba-dlg__panel");
  const sshEl = dlg.querySelector(".moba-ssh");
  const sshHost = $("mobaSshHost");
  const sshUser = $("mobaSshUser");
  const sshPort = $("mobaSshPort");
  const sshMsg = $("mobaSshMsg");
  const sshTabs = Array.from(sshEl.querySelectorAll(".moba-ssh__tabs button"));
  let chosen = null;

  function resetSsh() {
    sshHost.value = "";
    sshUser.value = "";
    sshPort.value = "22";
    sshMsg.textContent = SSH_DESC;
    sshTabs.forEach((x) => {
      x.classList.remove("is-active");
      x.setAttribute("aria-selected", "false");
    });
  }

  // Clicking the active tab again goes back to the session description.
  sshTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const turnOn = !tab.classList.contains("is-active");
      sshTabs.forEach((x) => {
        x.classList.toggle("is-active", turnOn && x === tab);
        x.setAttribute("aria-selected", String(turnOn && x === tab));
      });
      sshMsg.textContent = turnOn ? tab.dataset.tab + " are not available yet." : SSH_DESC;
    });
  });

  sshEl.querySelector(".moba-ssh__user").addEventListener("click", () => notAvailable("Saved usernames"));

  SESSION_TYPES.forEach((t) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "moba-dlg__type";
    b.setAttribute("role", "option");
    b.setAttribute("aria-selected", "false");
    b.innerHTML = t[1] + "<span>" + t[0] + "</span>";
    b.addEventListener("click", () => {
      chosen = t[0];
      track("session-type", { type: t[0] });
      typesEl.querySelectorAll(".moba-dlg__type").forEach((x) => {
        const on = x === b;
        x.classList.toggle("is-selected", on);
        x.setAttribute("aria-selected", String(on));
      });
      const isSsh = t[0] === "SSH";
      sshEl.hidden = !isSsh;
      panelEl.hidden = isSsh;
      msgEl.textContent = t[0] + " session settings are not available yet.";
      if (isSsh) sshHost.focus();
    });
    typesEl.appendChild(b);
  });

  function openSessionDialog() {
    track("session-dialog");
    chosen = null;
    msgEl.textContent = "Choose a session type...";
    typesEl.querySelectorAll(".moba-dlg__type").forEach((x) => {
      x.classList.remove("is-selected");
      x.setAttribute("aria-selected", "false");
    });
    sshEl.hidden = true;
    panelEl.hidden = false;
    resetSsh();
    dlg.hidden = false;
    dlg.focus({ preventScroll: true });
  }

  function closeSessionDialog() {
    dlg.hidden = true;
  }

  function confirmSession() {
    if (chosen === "SSH") {
      const host = sshHost.value.trim();
      if (!host) {
        if (window.VmeDesktop) window.VmeDesktop.toast("Please enter a remote host.");
        sshHost.focus();
        return;
      }
      if (host !== SSH_HOST && (!managerNetwork || host !== managerNetwork.ip)) {
        if (window.VmeDesktop) window.VmeDesktop.toast("Network error: Connection timed out.");
        sshHost.focus();
        return;
      }
      if (sshPort.value.trim() !== "22") {
        if (window.VmeDesktop) window.VmeDesktop.toast("Connection refused: use SSH port 22.");
        return;
      }
      track("ssh-ok", { host: host, user: sshUser.value.trim(), port: sshPort.value.trim() });
      closeSessionDialog();
      startSshSession(host, sshUser.value.trim() || "root");
      return;
    }
    const type = chosen;
    closeSessionDialog();
    if (type) notAvailable("Starting the " + type + " session");
  }

  dlg.querySelector(".moba-dlg__x").addEventListener("click", closeSessionDialog);
  dlg.querySelector('[data-act="cancel"]').addEventListener("click", closeSessionDialog);
  dlg.querySelector('[data-act="ok"]').addEventListener("click", confirmSession);
  dlg.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.stopPropagation();
      closeSessionDialog();
    } else if (e.key === "Enter" && e.target.tagName === "INPUT") {
      confirmSession();
    }
  });

  // ── SSH session tab ─────────────────────────────────────────────
  const SSH_HOST = "172.16.3.3";
  const SSH_HOSTNAME = "manager";
  const SSH_PASSWORD = "Lab@123456";
  const SSH_CLIENT_IP = "172.16.3.9";
  const vfs = window.MobaShell.createFs(SSH_HOSTNAME);
  const managerFs = window.MobaShell.createFs("hpe-vm1");
  let managerNetwork = null;
  let hpeVmInstalled = false;
  const HPE_VM_DEB_NAME = "hpe-vm_1.0.15-1_amd64.deb";
  let hpeVmReady = false;
  const titleText = win.querySelector(".moba-titlebar__text");
  const tabsEl = win.querySelector(".moba-tabs");
  const homeTab = tabsEl.querySelector(".moba-tab");
  const newTab = tabsEl.querySelectorAll(".moba-tab")[1];
  const mainEl = win.querySelector(".moba-main");
  const homeEl = win.querySelector(".moba-home");
  const sideEl = win.querySelector(".moba-side");
  const strip = win.querySelector(".moba-side__strip");
  const starBtn = strip.querySelector(".moba-side__btn--star");
  const treeEl = win.querySelector(".moba-tree");

  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };
  const icon20 = (body) => '<svg viewBox="0 0 20 20" aria-hidden="true">' + body + "</svg>";
  const FOLDER = '<path d="M1.500 4h6l1.800 2H18.500v10h-17z" fill="#e9b93a"/><path d="M1.500 7.500h17V16h-17z" fill="#f8d775"/>';
  const DOT_FILE = '<rect x="2" y="2" width="16" height="16" rx="1" fill="#6b6f76"/><path d="M5 6h10M5 9h10M5 12h6" stroke="#c9ccd2"/>';
  const PLAIN_FILE = '<path d="M4.500 1.500h8l3 3v14h-11z" fill="#fff" stroke="#8a94a0"/>';
  const TEXT_FILE = PLAIN_FILE + '<path d="M6.500 8.500h7M6.500 11h7M6.500 13.500h5" stroke="#8a94a0"/>';
  const FOLDER_ICONS = {
    "3D Objects": '<path d="M10 2l7 4v8l-7 4-7-4V6z" fill="#3fb6e8"/><path d="M10 10l7-4M10 10v8M10 10L3 6" stroke="#1d6f9a"/>',
    Desktop: '<rect x="2" y="4" width="16" height="10" fill="#1e88e5"/><path d="M8 16h4" stroke="#5a6470" stroke-width="1.600"/>',
    Documents: PLAIN_FILE,
    Downloads: '<path d="M8 2h4v8h3l-5 6-5-6h3z" fill="#1e88e5"/>',
    Music: '<path d="M8 15V4l8-1.500v11" stroke="#1e88e5" stroke-width="1.600" fill="none"/><circle cx="6" cy="15" r="2.200" fill="#1e88e5"/><circle cx="14" cy="13.500" r="2.200" fill="#1e88e5"/>',
    Pictures: '<rect x="2" y="3" width="16" height="14" fill="#e8f4ff" stroke="#5b8fc9"/><path d="M3 16l5-6 4 4 2-2 4 4z" fill="#4caf50"/>',
    Videos: '<rect x="3" y="3" width="14" height="14" fill="#3b3f46"/><path d="M8 7v6l5-3z" fill="#fff"/>',
  };
  const HARD_DRIVE = '<rect x="2" y="5" width="16" height="10" rx="1.500" fill="#d5dae0" stroke="#6b7078"/><path d="M4 11.500h12" stroke="#8a94a0"/><circle cx="14.500" cy="8" r="0.900" fill="#2f9e8f"/>';
  const DVD_DRIVE = '<circle cx="10" cy="10" r="8" fill="#e4e8ed" stroke="#6b7078"/><circle cx="10" cy="10" r="2.500" fill="#fff" stroke="#8a94a0"/>';
  const PC_ICON = '<rect x="2" y="3" width="16" height="10" rx="0.500" fill="#3aa0e0" stroke="#2f6f9f"/><path d="M7 17h6M10 13v4" stroke="#5a6470" stroke-width="1.600"/>';
  const NAV_ICONS = {
    "This PC": PC_ICON,
    "Windows 2022 (C:)": HARD_DRIVE,
    "Local Disk (D:)": HARD_DRIVE,
    "DVD Drive (E:)": DVD_DRIVE,
  };
  const GLOBE_ORANGE = svg(globe("#f08a24", "#f8c27a"));

  const sftp = el("div", "moba-sftp");
  sftp.hidden = true;
  const SFTP_TOOLS = [
    icon20('<rect x="2" y="3" width="16" height="14" rx="1" fill="#2f9e8f"/><path d="M6 14V9M4 11l2-2 2 2" stroke="#fff" stroke-width="1.600" fill="none"/>'),
    icon20('<path d="M10 2v10M5.500 8L10 12.500 14.500 8" stroke="#2f7fd1" stroke-width="2" fill="none"/><path d="M3 16h14" stroke="#2f7fd1" stroke-width="2"/>'),
    icon20('<path d="M10 13V3M5.500 7L10 2.500 14.500 7" stroke="#2f9e8f" stroke-width="2" fill="none"/><path d="M3 17h14" stroke="#2f9e8f" stroke-width="2"/>'),
    icon20('<circle cx="10" cy="10" r="7" fill="none" stroke="#3aa655" stroke-width="2.400"/><path d="M10 1.500l4 3-4 3z" fill="#3aa655"/>'),
    icon20(FOLDER + '<circle cx="15" cy="14" r="4" fill="#3aa655"/><path d="M15 12v4M13 14h4" stroke="#fff" stroke-width="1.400"/>'),
    icon20('<path d="M4.500 1.500h8l3 3v14h-11z" fill="#4aa8e0" stroke="#2f7fd1"/>'),
    icon20('<circle cx="10" cy="10" r="8" fill="#e5484d"/><path d="M6.500 6.500l7 7M13.500 6.500l-7 7" stroke="#fff" stroke-width="1.800"/>'),
    icon20('<text x="10" y="16" text-anchor="middle" font-size="16" font-weight="700" font-family="Arial, sans-serif" fill="#8f3fb8">A</text>'),
    icon20('<rect x="5" y="2" width="10" height="16" fill="#2b4a9c"/>')
  ];
  const SFTP_UP = icon20('<rect x="2" y="2" width="16" height="16" rx="1" fill="#4d8f5d"/><path d="M7 14V8M5 10l2-2 2 2" stroke="#fff" stroke-width="1.500" fill="none"/>');
  const SFTP_SYSTEM_FILES = [".bash_history", ".bashrc", ".profile", ".bash_logout"];
  sftp.innerHTML =
    '<div class="moba-sftp__head">' + GLOBE_ORANGE + "<span>SSH browser (SFTP)</span></div>" +
    '<div class="moba-sftp__tools">' + SFTP_TOOLS.map((icon, index) => index === 2 ? '<button type="button" id="mobaUpload" title="Upload files" aria-label="Upload files">' + icon + '</button>' : "<span>" + icon + "</span>").join("") + "</div>" +
    '<div class="moba-sftp__path"><span>/root/</span><svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><path d="M1.500 3.500l3.500 3.500 3.500-3.500" fill="none" stroke="currentColor" stroke-width="1.300"/></svg></div>' +
    '<div class="moba-sftp__name"><svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><path d="M1 2.500h8L5 8z" fill="#2f7fd1"/></svg><span>Name</span></div>' +
    '<div class="moba-sftp__list"></div>' +
    '<div class="moba-sftp__hscroll" aria-hidden="true"><svg width="8" height="8" viewBox="0 0 8 8"><path d="M6 1L2 4l4 3z" fill="#555"/></svg><i></i><svg width="8" height="8" viewBox="0 0 8 8"><path d="M2 1l4 3-4 3z" fill="#555"/></svg></div>' +
    '<label class="moba-sftp__follow"><input type="checkbox" checked><span>Follow terminal folder</span></label>' +
    '<button type="button" class="moba-sftp__mon" aria-pressed="true"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="3" width="20" height="14" rx="1" fill="#2d3a4a" stroke="#5f6b7a"/><path d="M4 11h4l2-4 3 7 2-3h5" fill="none" stroke="#3fc15f" stroke-width="1.600"/><path d="M8 21h8M12 17v4" stroke="#5f6b7a" stroke-width="2"/></svg><span>Remote monitoring</span></button>';
  sideEl.appendChild(sftp);

  const uploadButton = $("mobaUpload");
  const uploadFiles = [
    { name: "hpe-vm_1.0.15-1_amd64.deb", date: "6/15/2026 4:57 PM", type: "DEB File", size: 33724 },
    { name: "hpe-vm-essentials-9.0.1-1.qcow2.gz", date: "7/21/2026 7:59 PM", type: "GZ File", size: 3463405 },
    { name: "Morpheus_Manager_Installer-1.0.0-x64.dmg", date: "7/21/2026 7:57 PM", type: "DMG File", size: 117340 },
    { name: "Morpheus_Manager_Installer-win32-x64-1.0.0.zip", date: "7/21/2026 7:57 PM", type: "Compressed (zipped) Folder", size: 141175 },
    { name: "README", date: "7/21/2026 7:54 PM", type: "File", size: 3 },
    { name: "SHA256.txt", date: "7/21/2026 8:00 PM", type: "Text Document", size: 1 }
  ];
  // Practice mode can make an upload silently fail once. Guided mode never does.
  const dropUpload = (name) => !!(window.SimLabsPractice && window.SimLabsPractice.dropUpload(name));
  const uploadDialog = el("div", "moba-upload");
  uploadDialog.hidden = true;
  uploadDialog.setAttribute("role", "dialog");
  uploadDialog.setAttribute("aria-modal", "true");
  uploadDialog.setAttribute("aria-label", "Choose which file(s) to upload...");
  uploadDialog.innerHTML =
    '<div class="moba-upload__title"><img src="../Images/MobaXtermIcon.webp" alt=""><span>Choose which file(s) to upload...</span><button type="button" data-upload-close aria-label="Close">&#215;</button></div>' +
    '<div class="moba-upload__address"><button type="button" data-upload-pc title="Up to This PC" aria-label="Up to This PC">&#8593;</button><div><button type="button" data-upload-pc>This PC</button><span class="moba-upload__sep"> &gt; </span><button type="button" data-upload-dvd>DVD Drive (E:)</button></div><input type="search" aria-label="Search files" placeholder="Search DVD Drive (E:)"></div>' +
    '<div class="moba-upload__organize">Organize <span>Details</span></div>' +
    '<div class="moba-upload__body"><nav aria-label="File locations"></nav><div class="moba-upload__viewport"><div class="moba-upload__columns"><span>Name</span><span>Date modified</span><span>Type</span><span>Size</span></div><div class="moba-upload__files" role="listbox" aria-label="Files" aria-multiselectable="true"></div></div></div>' +
    '<div class="moba-upload__footer"><label for="mobaUploadNames">File name:</label><input id="mobaUploadNames" type="text" readonly><div><button type="button" data-upload-open disabled>Open</button><button type="button" data-upload-close>Cancel</button></div></div>';
  win.appendChild(uploadDialog);
  const uploadList = uploadDialog.querySelector(".moba-upload__files");
  const uploadColumns = uploadDialog.querySelector(".moba-upload__columns");
  const uploadSearch = uploadDialog.querySelector('input[type="search"]');
  const uploadNames = $("mobaUploadNames");
  const uploadOpen = uploadDialog.querySelector("[data-upload-open]");
  const uploadNav = uploadDialog.querySelector("nav");
  const uploadProgress = el("div", "moba-upload-progress");
  uploadProgress.hidden = true;
  uploadProgress.innerHTML = '<div class="moba-upload-progress__name" role="status"></div><div class="moba-upload-progress__controls">' + SFTP_TOOLS[2] + '<div><span class="moba-upload-progress__count"></span><div class="moba-upload-progress__bar" role="progressbar" aria-label="File upload" aria-valuemin="0" aria-valuemax="100"><i></i><span>0%</span></div></div><button type="button">&#215; Cancel</button></div>';
  sftp.appendChild(uploadProgress);
  let uploadSelection = new Set();
  let uploadAnchor = 0;
  let uploadLocation = "This PC";
  let uploadTimer = null;
  let uploadActive = false;

  function syncUploadSelection() {
    uploadList.querySelectorAll("[data-file]").forEach((row) => {
      row.setAttribute("aria-selected", String(uploadSelection.has(Number(row.dataset.file))));
    });
    uploadNames.value = Array.from(uploadSelection).sort((first, second) => first - second).map((index) => '"' + uploadFiles[index].name + '"').join(" ");
    uploadOpen.disabled = uploadSelection.size === 0;
    track("upload-select", { names: Array.from(uploadSelection).map((index) => uploadFiles[index].name) });
  }

  function renderUploadFiles() {
    uploadList.textContent = "";
    const thisPc = uploadLocation === "This PC";
    const headers = uploadColumns.querySelectorAll("span");
    ["Name", thisPc ? "Type" : "Date modified", thisPc ? "Total size" : "Type", thisPc ? "Free space" : "Size"].forEach((text, position) => {
      headers[position].textContent = text;
    });
    uploadFiles.forEach((file, index) => {
      if (uploadLocation !== "DVD Drive (E:)" || !file.name.toLowerCase().includes(uploadSearch.value.toLowerCase())) return;
      const row = el("button", "moba-upload__file");
      row.type = "button";
      row.dataset.file = index;
      row.setAttribute("role", "option");
      const name = el("span", "moba-upload__filename");
      name.innerHTML = icon20(file.type.indexOf("zipped") >= 0 ? FOLDER : file.type === "Text Document" ? TEXT_FILE : PLAIN_FILE);
      name.appendChild(el("span", "", file.name));
      name.title = file.name;
      row.append(name, el("span", "", file.date), el("span", "", file.type), el("span", "", file.size.toLocaleString("en-US") + " KB"));
      row.addEventListener("click", (event) => {
        if (event.shiftKey) {
          if (!event.ctrlKey && !event.metaKey) uploadSelection.clear();
          uploadList.querySelectorAll("[data-file]").forEach((visibleRow) => {
            const position = Number(visibleRow.dataset.file);
            if (position >= Math.min(uploadAnchor, index) && position <= Math.max(uploadAnchor, index)) uploadSelection.add(position);
          });
        } else if (event.ctrlKey || event.metaKey) {
          if (uploadSelection.has(index)) uploadSelection.delete(index);
          else uploadSelection.add(index);
          uploadAnchor = index;
        } else {
          uploadSelection = new Set([index]);
          uploadAnchor = index;
        }
        syncUploadSelection();
      });
      row.addEventListener("dblclick", startUpload);
      uploadList.appendChild(row);
    });
    if (thisPc) {
      const drive = (label, icon, type, total, free) => {
        const item = el("button", "moba-upload__file moba-upload__static");
        item.type = "button";
        const name = el("span", "moba-upload__filename");
        name.innerHTML = icon20(icon);
        name.appendChild(el("span", "", label));
        item.append(name, el("span", "", type), el("span", "", total), el("span", "", free));
        return item;
      };
      const folderRow = (folder) => {
        const item = el("button", "moba-upload__file moba-upload__static");
        item.type = "button";
        const name = el("span", "moba-upload__filename");
        name.innerHTML = icon20(FOLDER_ICONS[folder] || FOLDER);
        name.appendChild(el("span", "", folder));
        item.append(name, el("span", "", "System Folder"), el("span", ""), el("span", ""));
        return item;
      };
      uploadList.appendChild(el("div", "moba-upload__group", "Folders (7)"));
      ["3D Objects", "Desktop", "Documents", "Downloads", "Music", "Pictures", "Videos"].forEach((folder) => {
        uploadList.appendChild(folderRow(folder));
      });
      uploadList.appendChild(el("div", "moba-upload__group", "Devices and drives (3)"));
      uploadList.appendChild(drive("Windows 2022 (C:)", HARD_DRIVE, "Local Disk", "127 GB", "85.6 GB"));
      uploadList.appendChild(drive("Local Disk (D:)", HARD_DRIVE, "Local Disk", "32 GB", "31.9 GB"));
      const dvdRow = drive("DVD Drive (E:)", DVD_DRIVE, "DVD Drive", "3.58 GB", "0 GB");
      dvdRow.addEventListener("dblclick", () => navigateUpload("DVD Drive (E:)"));
      dvdRow.addEventListener("keydown", (event) => {
        if (event.key === "Enter") navigateUpload("DVD Drive (E:)");
      });
      uploadList.appendChild(dvdRow);
    }
    syncUploadSelection();
  }

  function navigateUpload(location) {
    uploadLocation = location;
    uploadSelection.clear();
    uploadAnchor = 0;
    uploadSearch.value = "";
    uploadSearch.placeholder = "Search " + location;
    uploadDialog.querySelector("[data-upload-dvd]").hidden = location !== "DVD Drive (E:)";
    uploadDialog.querySelector(".moba-upload__sep").hidden = location !== "DVD Drive (E:)";
    uploadNav.querySelectorAll("button").forEach((button) => button.classList.toggle("is-selected", button.textContent === location));
    renderUploadFiles();
    track("upload-navigate", { location: location });
  }

  ["This PC", "3D Objects", "Desktop", "Documents", "Downloads", "Music", "Pictures", "Videos", "Windows 2022 (C:)", "Local Disk (D:)", "DVD Drive (E:)"].forEach((location) => {
    const button = el("button", "", location);
    button.type = "button";
    button.innerHTML = icon20(NAV_ICONS[location] || FOLDER_ICONS[location] || FOLDER) + '<span></span>';
    button.querySelector("span").textContent = location;
    button.addEventListener("click", () => navigateUpload(location));
    uploadNav.appendChild(button);
  });

  function closeUploadDialog() {
    uploadDialog.hidden = true;
    titlebar.classList.remove("is-inactive");
    uploadButton.focus({ preventScroll: true });
  }

  function stopUpload() {
    clearInterval(uploadTimer);
    uploadTimer = null;
    uploadActive = false;
    uploadProgress.hidden = true;
    uploadButton.disabled = false;
  }

  function startUpload() {
    if (!session || !session.authed || uploadActive || !uploadSelection.size) return;
    const queue = Array.from(uploadSelection).sort((first, second) => first - second).map((index) => uploadFiles[index]);
    track("upload-start", { names: queue.map((file) => file.name) });
    closeUploadDialog();
    if (window.SimLabsProgress && window.SimLabsProgress.replaying) {
      queue.forEach((file) => {
        if (session && session.shell) MobaShell.writeUpload(session.shell, file.name, file.size * 1024);
      });
      renderSftp();
      tickMonitor();
      return;
    }
    uploadActive = true;
    uploadButton.disabled = true;
    uploadProgress.hidden = false;
    uploadProgress.scrollIntoView({ block: "nearest" });
    if (window.VmeDesktop) window.VmeDesktop.toast("Uploading " + queue.length + " file(s). Progress is shown in the SSH browser.");
    let position = 0;
    let started = Date.now();
    const update = () => {
      const file = queue[position];
      const duration = Math.min(30000, 2500 + file.size / 170);
      const percent = Math.min(100, Math.floor((Date.now() - started) / duration * 100));
      uploadProgress.querySelector(".moba-upload-progress__name").textContent = "Uploading " + file.name;
      uploadProgress.querySelector(".moba-upload-progress__name").title = "Uploading " + file.name;
      uploadProgress.querySelector(".moba-upload-progress__count").textContent = "[" + (position + 1) + "/" + queue.length + "]";
      const bar = uploadProgress.querySelector('[role="progressbar"]');
      bar.setAttribute("aria-valuenow", String(percent));
      bar.querySelector("i").style.width = percent + "%";
      bar.querySelector("span").textContent = percent + "%";
      if (percent < 100) return;
      if (session && session.shell) {
        if (!dropUpload(file.name)) MobaShell.writeUpload(session.shell, file.name, file.size * 1024);
        renderSftp();
      }
      position++;
      if (position === queue.length) {
        stopUpload();
        tickMonitor();
        if (window.VmeDesktop) window.VmeDesktop.toast("Upload complete.");
      } else {
        started = Date.now();
      }
    };
    update();
    tickMonitor();
    uploadTimer = setInterval(update, 200);
  }

  uploadButton.addEventListener("click", () => {
    if (!session || !session.authed || uploadActive) return;
    track("upload-open");
    navigateUpload("This PC");
    uploadDialog.hidden = false;
    titlebar.classList.add("is-inactive");
    uploadList.querySelector("button").focus();
  });
  uploadDialog.querySelectorAll("[data-upload-close]").forEach((button) => button.addEventListener("click", closeUploadDialog));
  uploadDialog.querySelectorAll("[data-upload-pc]").forEach((button) => button.addEventListener("click", () => navigateUpload("This PC")));
  uploadDialog.querySelector("[data-upload-dvd]").addEventListener("click", () => navigateUpload("DVD Drive (E:)"));
  uploadOpen.addEventListener("click", startUpload);
  uploadProgress.querySelector("button").addEventListener("click", () => {
    stopUpload();
    tickMonitor();
    uploadButton.focus({ preventScroll: true });
  });
  uploadSearch.addEventListener("input", () => {
    uploadSelection.clear();
    renderUploadFiles();
  });
  uploadDialog.addEventListener("keydown", (event) => {
    event.stopPropagation();
    if (event.key === "Escape") closeUploadDialog();
    else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "a" && event.target.closest(".moba-upload__files")) {
      event.preventDefault();
      uploadList.querySelectorAll("[data-file]").forEach((row) => uploadSelection.add(Number(row.dataset.file)));
      syncUploadSelection();
    } else if (event.key === "Enter" && event.target.closest("[data-file]")) {
      event.preventDefault();
      const index = Number(event.target.closest("[data-file]").dataset.file);
      if (!uploadSelection.has(index)) uploadSelection = new Set([index]);
      startUpload();
    } else if (event.key === "Tab") {
      const controls = Array.from(uploadDialog.querySelectorAll("button:not(:disabled), input")).filter((control) => control.getClientRects().length);
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && event.target === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && event.target === last) { event.preventDefault(); first.focus(); }
    }
  });

  const sftpBtn = el("button", "moba-side__btn");
  sftpBtn.type = "button";
  sftpBtn.hidden = true;
  sftpBtn.setAttribute("aria-label", "SSH browser (SFTP)");
  sftpBtn.innerHTML = GLOBE_ORANGE;
  strip.appendChild(sftpBtn);

  const term = el("section", "moba-term");
  term.hidden = true;
  term.setAttribute("aria-label", "SSH terminal");
  const screenEl = el("div", "moba-term__screen");
  const cursorEl = el("i", "moba-term__cursor");
  const termBody = el("div", "moba-term__body");
  termBody.appendChild(screenEl);
  term.appendChild(termBody);

  const monIcon = (body) => '<svg viewBox="0 0 24 24" aria-hidden="true">' + body + "</svg>";
  const mon = el("div", "moba-mon");
  mon.hidden = true;
  mon.innerHTML =
    '<span class="moba-mon__i">' + monIcon('<rect x="2" y="3" width="20" height="18" rx="2" fill="#2b2b2b"/><path d="M6 9l4 3-4 3" fill="none" stroke="#e5484d" stroke-width="2"/>') + "<b>" + SSH_HOSTNAME + "</b></span>" +
    '<span class="moba-mon__i">' + monIcon('<rect x="5" y="5" width="14" height="14" rx="1" fill="#3aa655"/><path d="M8 2v3M12 2v3M16 2v3M8 19v3M12 19v3M16 19v3M2 8h3M2 12h3M2 16h3M19 8h3M19 12h3M19 16h3" stroke="#3aa655" stroke-width="1.500"/>') + '<b id="mobaMonCpu">0%</b></span>' +
    '<span class="moba-mon__graph" aria-hidden="true"></span>' +
    '<span class="moba-mon__i">' + monIcon('<rect x="2" y="8" width="20" height="9" fill="#3aa655"/><path d="M5 17v3M9 17v3M13 17v3M17 17v3" stroke="#5f6b7a" stroke-width="2"/>') + '<b id="mobaMonMem">1.05 GB / 15.62 GB</b></span>' +
    '<span class="moba-mon__i">' + monIcon('<path d="M12 21V5M5.500 11.500L12 4.500l6.500 7" fill="none" stroke="#2f9e8f" stroke-width="2.600"/>') + '<b id="mobaMonUp">0.03 Mb/s</b></span>' +
    '<span class="moba-mon__i">' + monIcon('<path d="M12 3v16M5.500 12.500L12 19.500l6.500-7" fill="none" stroke="#2f7fd1" stroke-width="2.600"/>') + '<b id="mobaMonDown">0.00 Mb/s</b></span>' +
    '<span class="moba-mon__i">' + monIcon('<rect x="3" y="4" width="18" height="13" rx="1" fill="#e8edf3" stroke="#5f6b7a"/><circle cx="12" cy="10.500" r="4" fill="#3aa655"/><path d="M12 8v3l2 1" stroke="#fff" stroke-width="1.200" fill="none"/><path d="M8 21h8M12 17v4" stroke="#5f6b7a" stroke-width="2"/>') + "<b>10 hours</b></span>" +
    '<span class="moba-mon__sp"></span>' +
    '<span class="moba-mon__arrows" aria-hidden="true">' + monIcon('<path d="M3 12h18M9 6l-6 6 6 6" fill="none" stroke="#2f5fd1" stroke-width="3"/>') + monIcon('<path d="M3 12h18M15 6l6 6-6 6" fill="none" stroke="#2f5fd1" stroke-width="3"/>') + "</span>" +
    '<button type="button" class="moba-mon__x" aria-label="Close remote monitoring"><svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="9" fill="#e5484d"/><path d="M6.500 6.500l7 7M13.500 6.500l-7 7" stroke="#fff" stroke-width="2.200"/></svg></button>';
  term.appendChild(mon);
  mainEl.appendChild(term);

  const tuiEl = el("div", "moba-tui");
  tuiEl.hidden = true;
  tuiEl.innerHTML =
    '<div class="moba-tui__head">Package configuration</div>' +
    '<div class="moba-tui__dlg">' +
    '<div class="moba-tui__ttl"><span>┤</span><b></b><span>├</span></div>' +
    '<p class="moba-tui__txt"></p>' +
    '<div class="moba-tui__lbl"></div>' +
    '<div class="moba-tui__listwrap"><div class="moba-tui__list"></div>' +
    '<div class="moba-tui__bar"><i>↑&#xFE0E;</i><span class="moba-tui__track"><b></b></span><i>↓&#xFE0E;</i></div></div>' +
    '<div class="moba-tui__btns"><button type="button" data-b="ok">&lt;Ok&gt;</button><button type="button" data-b="cancel">&lt;Cancel&gt;</button></div>' +
    "</div>";
  termBody.appendChild(tuiEl);
  const tui = {
    title: tuiEl.querySelector(".moba-tui__ttl b"),
    text: tuiEl.querySelector(".moba-tui__txt"),
    label: tuiEl.querySelector(".moba-tui__lbl"),
    list: tuiEl.querySelector(".moba-tui__list"),
    wrap: tuiEl.querySelector(".moba-tui__listwrap"),
    track: tuiEl.querySelector(".moba-tui__track"),
    thumb: tuiEl.querySelector(".moba-tui__track b"),
    bar: tuiEl.querySelector(".moba-tui__bar"),
    btns: Array.from(tuiEl.querySelectorAll(".moba-tui__btns button"))
  };

  const vmMenuEl = el("div", "moba-vm-menu");
  vmMenuEl.hidden = true;
  vmMenuEl.setAttribute("role", "application");
  vmMenuEl.setAttribute("aria-label", "HPE VM Console");
  vmMenuEl.innerHTML =
    '<div class="moba-vm-menu__dialog">' +
    '<div class="moba-vm-menu__title">HPE VM Console</div>' +
    '<div class="moba-vm-menu__options" role="listbox" aria-label="Console options">' +
    '<button type="button" role="option" data-vm-option="0" data-hotkey="h"><span>&lt;</span>Host Information<span>&gt;</span></button>' +
    '<button type="button" role="option" data-vm-option="1" data-hotkey="c"><span>&lt;</span>Configure Network<span>&gt;</span></button>' +
    '<button type="button" role="option" data-vm-option="2" data-hotkey="v"><span>&lt;</span>Virtual Machines<span>&gt;</span></button>' +
    '<button type="button" role="option" data-vm-option="3" data-hotkey="k"><span>&lt;</span>Keyboard Layout / TimeZone<span>&gt;</span></button>' +
    '<button type="button" role="option" data-vm-option="4" data-hotkey="i"><span>&lt;</span>Install VME Manager<span>&gt;</span></button>' +
    '<button type="button" role="option" data-vm-option="5" data-hotkey="w"><span>&lt;</span>Install Worker<span>&gt;</span></button>' +
    '<button type="button" role="option" data-vm-option="6" data-hotkey="e"><span>&lt; </span>Exit<span> &gt;</span></button>' +
    '</div>' +
    '<div class="moba-vm-menu__footer"><span>Copyright 2024-2025 HPE, Inc.</span><span>v1.0.15</span></div>' +
    '</div>';
  termBody.appendChild(vmMenuEl);
  const vmMenuOptions = Array.from(vmMenuEl.querySelectorAll("[data-vm-option]"));
  let vmMenuSelected = 6;

  const installerEl = el("div", "moba-vme-installer");
  installerEl.hidden = true;
  installerEl.setAttribute("role", "dialog");
  installerEl.setAttribute("aria-modal", "true");
  installerEl.setAttribute("aria-label", "VME Manager Installation Options");
  installerEl.innerHTML =
    '<form class="moba-vme-installer__form">' +
    '<div class="moba-vme-installer__title">VME Manager Installation Options</div>' +
    '<section class="moba-vme-installer__section">' +
    '<h2>VM Config Options:</h2>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerIp">IP Address:</label><input id="vmeManagerIp" name="ip" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerNetmask">Netmask:</label><input id="vmeManagerNetmask" name="netmask" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerGateway">Gateway:</label><input id="vmeManagerGateway" name="gateway" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerDns">DNS Server:</label><input id="vmeManagerDns" name="dns" value="8.8.8.8" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerUrl">Appliance URL:</label><input id="vmeManagerUrl" name="url" autocomplete="url"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerHostname">Hostname:</label><input id="vmeManagerHostname" name="hostname" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerUser">Admin User:</label><input id="vmeManagerUser" name="admin" autocomplete="username"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerPassword">Admin Password:</label><input id="vmeManagerPassword" name="password" type="password" autocomplete="new-password"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerConfirm">Confirm Password:</label><input id="vmeManagerConfirm" name="confirm" type="password" autocomplete="new-password"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerImage">Image URI:</label><input id="vmeManagerImage" name="image" value="/" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__browse-row"><span></span><button type="button" data-installer-browse><span>&lt;</span>Browse Files<span>&gt;</span></button></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerProxy">Proxy:</label><input id="vmeManagerProxy" name="proxy" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerNoProxy">No Proxy List:</label><input id="vmeManagerNoProxy" name="noProxy" autocomplete="off"></div>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerSize">Select VM Size:</label><select id="vmeManagerSize" name="size"><option>Small</option><option>Medium</option><option>Large</option></select></div>' +
    '</section>' +
    '<section class="moba-vme-installer__section moba-vme-installer__section--host">' +
    '<h2>Host Config Options:</h2>' +
    '<div class="moba-vme-installer__row"><label for="vmeManagerInterface">Management Interface:</label><select id="vmeManagerInterface" name="interface"><option>ens192</option><option>ens160</option></select></div>' +
    '<label class="moba-vme-installer__check"><input type="checkbox" name="vlan">Use Compute VLAN?</label>' +
    '</section>' +
    '<div class="moba-vme-installer__actions"><button type="submit" data-installer-action="install"><span>&lt;</span>Install<span>&gt;</span></button><button type="button" data-installer-action="abort"><span>&lt;</span>Abort<span>&gt;</span></button><button type="button" data-installer-action="help"><span>&lt;</span>Help<span>&gt;</span></button></div>' +
    '<p class="moba-vme-installer__error" role="alert" hidden></p>' +
    '</form>' +
    '<div class="moba-vme-installer__progress" hidden></div>' +
    '<div class="moba-vme-installer__complete" hidden></div>';
  termBody.appendChild(installerEl);
  const installerForm = installerEl.querySelector("form");
  const installerError = installerEl.querySelector(".moba-vme-installer__error");
  const installerProgress = installerEl.querySelector(".moba-vme-installer__progress");
  const installerComplete = installerEl.querySelector(".moba-vme-installer__complete");
  const installerFileInput = $("vmeManagerImage");

  const filePickerEl = el("div", "moba-vme-file-picker");
  filePickerEl.hidden = true;
  filePickerEl.setAttribute("role", "dialog");
  filePickerEl.setAttribute("aria-modal", "true");
  filePickerEl.setAttribute("aria-label", "Open File");
  filePickerEl.innerHTML =
    '<div class="moba-vme-file-picker__panel">' +
    '<div class="moba-vme-file-picker__title">Open File</div>' +
    '<div class="moba-vme-file-picker__label">Choose a file</div>' +
    '<div class="moba-vme-file-picker__path" aria-live="polite"></div>' +
    '<div class="moba-vme-file-picker__columns"><div class="moba-vme-file-picker__files" role="listbox" aria-label="Files"></div><div class="moba-vme-file-picker__folders" role="listbox" aria-label="Folders"></div></div>' +
    '<input class="moba-vme-file-picker__filename" aria-label="Selected file path">' +
    '<div class="moba-vme-file-picker__actions"><button type="button" data-file-picker-open>Open</button><button type="button" data-file-picker-cancel>Cancel</button></div>' +
    '</div>';
  termBody.appendChild(filePickerEl);
  const pickerPath = filePickerEl.querySelector(".moba-vme-file-picker__path");
  const pickerFiles = filePickerEl.querySelector(".moba-vme-file-picker__files");
  const pickerFolders = filePickerEl.querySelector(".moba-vme-file-picker__folders");
  const pickerFilename = filePickerEl.querySelector(".moba-vme-file-picker__filename");
  const pickerOpen = filePickerEl.querySelector("[data-file-picker-open]");
  let pickerDirectory = "/";
  let pickerFile = "";

  const installerProgressSteps = [
    { title: "Downloading QCOW Image...", progress: 2, delay: 90000 },
    { title: "Reconfiguring VME Manager...", progress: 75, delay: 60000 },
    { title: "Starting VME Manager Services...", progress: 100, delay: 30000 }
  ];
  let installerTimer = null;

  // Choices offered by the keyboard-configuration package during an upgrade.
  const KB_COUNTRIES = ("Afghani|Albanian|Amharic|Arabic|Arabic (Morocco)|Arabic (Syria)|Armenian|Azerbaijani|Bambara|Bangla|Belarusian|Belgian|Berber (Algeria, Latin)|Bosnian|Braille|Bulgarian|Burmese|Chinese|Croatian|Czech|Danish|Dhivehi|Dutch|Dzongkha|" +
    "English (Australia)|English (Cameroon)|English (Ghana)|English (New Zealand)|English (Nigeria)|English (South Africa)|English (UK)|English (US)|Esperanto|Estonian|Faroese|Filipino|Finnish|French|French (Canada)|French (Democratic Republic of the Congo)|French (Togo)|Georgian|German|German (Austria)|Greek|Hebrew|Hungarian|Icelandic|Indian|Indonesian (Latin)|Iraqi|Irish|Italian|Japanese|Kazakh|Khmer (Cambodia)|Korean|Kyrgyz|Lao|Latvian|Lithuanian|Macedonian|Malay (Jawi, Arabic Keyboard)|Maltese|Maori|Moldavian|Mongolian|Montenegrin|Nepali|Norwegian|Persian|Polish|Portuguese|Portuguese (Brazil)|Romanian|Russian|Serbian|Sinhala (phonetic)|Slovak|Slovenian|Spanish|Spanish (Latin American)|Swahili (Kenya)|Swahili (Tanzania)|Swedish|Taiwanese|Tajik|Thai|Tswana|Turkish|Turkmen|Ukrainian|Urdu (Pakistan)|Uzbek|Vietnamese|Wolof").split("|");
  const KB_LAYOUTS = ("English (US)|English (US) - Cherokee|English (US) - English (classic Dvorak)|English (US) - English (Colemak)|English (US) - English (Colemak-DH)|English (US) - English (Colemak-DH ISO)|English (US) - English (Colemak-DH Ortholinear)|English (US) - English (Colemak-DH Wide)|English (US) - English (Colemak-DH Wide ISO)|English (US) - English (Dvorak)|English (US) - English (Dvorak, alt. intl.)|English (US) - English (Dvorak, intl., with dead keys)|" +
    "English (US) - English (Dvorak, left-handed)|English (US) - English (Dvorak, right-handed)|English (US) - English (Macintosh)|English (US) - English (Norman)|English (US) - English (US, Symbolic)|English (US) - English (US, alt. intl.)|English (US) - English (US, euro on 5)|English (US) - English (US, intl., with dead keys)|English (US) - English (Workman)|English (US) - English (Workman, intl., with dead keys)|English (US) - English (intl., with AltGr dead keys)|English (US) - Russian (US, phonetic)|English (US) - Serbo-Croatian (US)|Other").split("|");
  const KEYBOARD_SCREENS = [
    {
      title: "Configuring keyboard-configuration",
      text: "The layout of keyboards varies per country, with some countries having multiple common layouts. Please select the country of origin for the keyboard.",
      label: "Country of origin for the keyboard:",
      items: KB_COUNTRIES,
      sel: "English (US)"
    },
    {
      title: "Configuring keyboard-configuration",
      text: "Please select the layout matching the keyboard for this machine.",
      label: "Keyboard layout:",
      items: KB_LAYOUTS,
      sel: "English (US)"
    }
  ];

  const pw = el("div", "moba-pw");
  pw.hidden = true;
  pw.setAttribute("role", "dialog");
  pw.setAttribute("aria-modal", "true");
  pw.setAttribute("aria-label", "MobaXterm");
  pw.innerHTML =
    '<div class="moba-pw__box">' +
    '<div class="moba-pw__title"><span>MobaXterm</span><button type="button" class="moba-dlg__x" data-pw="no" aria-label="Close"><svg width="10" height="10" viewBox="0 0 10 10"><path d="M0 0l10 10M10 0L0 10" stroke="currentColor" stroke-width="1.100"/></svg></button></div>' +
    '<div class="moba-pw__body">' +
    '<svg class="moba-pw__key" viewBox="0 0 96 96" aria-hidden="true"><g transform="rotate(45 28 28)"><circle cx="28" cy="28" r="21" fill="#f5a31a"/><circle cx="28" cy="28" r="7.500" fill="#fff"/><rect x="42" y="22" width="54" height="12" rx="2" fill="#f5a31a"/><rect x="72" y="32" width="8" height="12" fill="#f5a31a"/><rect x="85" y="32" width="8" height="9" fill="#f5a31a"/></g></svg>' +
    '<p class="moba-pw__q" id="mobaPwQ"></p>' +
    '<div class="moba-pw__btns">' +
    '<button type="button" class="moba-dlg__btn is-default" data-pw="yes"><svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="9" fill="#3aa655"/><path d="M5.500 10.500l3 3 6-6.500" fill="none" stroke="#fff" stroke-width="2.200"/></svg><span>Yes</span></button>' +
    '<button type="button" class="moba-dlg__btn" data-pw="no"><svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="9" fill="#e5484d"/><path d="M6.500 6.500l7 7M13.500 6.500l-7 7" stroke="#fff" stroke-width="2.200"/></svg><span>No</span></button></div>' +
    '<p class="moba-pw__note">MobaXterm will use your "Master Password" in order to secure all your stored passwords with strong encryption.</p></div>' +
    '<div class="moba-pw__foot"><label><input type="checkbox" id="mobaPwSkip"><span>Do not show this message again</span></label>' +
    '<button type="button" class="moba-pw__info" id="mobaPwInfo" aria-label="More information">i</button></div>' +
    "</div>";
  win.appendChild(pw);

  const pwQuestion = $("mobaPwQ");
  const pwSkip = $("mobaPwSkip");
  const pwYes = pw.querySelector('[data-pw="yes"]');
  let session = null;
  let sessionTimers = [];
  let monTimer = null;
  let monOn = true;
  const monBtn = sftp.querySelector(".moba-sftp__mon");
  let skipSavePrompt = practice;

  function setSide(which) {
    const sftpOn = which === "sftp" && !!session && session.authed;
    treeEl.hidden = sftpOn;
    sftp.hidden = !sftpOn;
    starBtn.classList.toggle("is-active", !sftpOn);
    sftpBtn.classList.toggle("is-active", sftpOn);
  }

  function showTab(which) {
    const onTerm = which === "term" && !!session;
    homeEl.hidden = onTerm;
    term.hidden = !onTerm;
    mainEl.classList.toggle("is-term", onTerm);
    homeTab.classList.toggle("is-active", !onTerm);
    if (session) session.tab.classList.toggle("is-active", onTerm);
    titleText.textContent = onTerm ? session.label : "MobaXterm";
    setSide(onTerm ? "sftp" : "sessions");
  }

  function openPw() {
    pwQuestion.textContent = "Do you want to save password for " + session.user + "@" + session.host + "?";
    pwSkip.checked = false;
    pw.hidden = false;
    titlebar.classList.add("is-inactive");
    pwYes.focus();
  }

  function closePw() {
    if (pw.hidden) return;
    if (pwSkip.checked) skipSavePrompt = true;
    pw.hidden = true;
    titlebar.classList.remove("is-inactive");
    if (session) {
      screenEl.focus({ preventScroll: true });
      if (session.pendingLogin) finishLogin();
    }
  }

  const outLine = (parts, cls) => {
    const line = el("div", "moba-term__line moba-term__line--plain" + (cls ? " " + cls : ""));
    (Array.isArray(parts) ? parts : [parts]).forEach((p) => {
      if (typeof p === "string") line.appendChild(document.createTextNode(p));
      else line.appendChild(el("span", p[1], p[0]));
    });
    return line;
  };

  // Static copy of what the lab server prints after a successful SSH login.
  function loginOutput(user, host) {
    const box = el("div", "moba-term__box");
    const b = (parts, cls) => box.appendChild(outLine(parts, cls));
    b([["• MobaXterm Personal Edition v26.4 •", "t-green"]], "is-center");
    b([["(SSH client, X server and network tools)", "t-yel"]], "is-center");
    b("");
    b([" ► SSH session to ", [user + "@" + host, "t-mag"]]);
    b(["   • Direct SSH      :  ", ["✔", "t-green"]]);
    b(["   • SSH compression :  ", ["✘", "t-red"]]);
    b(["   • SSH-browser     :  ", ["✔", "t-green"]]);
    b(["   • X11-forwarding  :  ", ["✘", "t-red"], "  (", ["disabled", "t-red"], " or ", ["not supported", "t-red"], " by server)"]);
    b("");
    b([" ► For more ", ["info", "t-cyan"], ", ctrl+click on ", ["help", "t-link"], " or visit our ", ["website", "t-link"], "."]);

    const nodes = [box];
    const o = (parts) => nodes.push(outLine(parts));
    o("");
    o("Welcome to Ubuntu 24.04.4 LTS (GNU/Linux 6.8.0-137-generic x86_64)");
    o("");
    o([" * Documentation:  ", ["https://help.ubuntu.com", "t-link"]]);
    o([" * Management:     ", ["https://landscape.canonical.com", "t-link"]]);
    o([" * Support:        ", ["https://ubuntu.com/pro", "t-link"]]);
    o("");
    o([" System ", ["information", "t-cyan"], " as of Thu Oct 15 12:05:56 AM PDT 2026"]);
    o("");
    o("  System load:  0.0                Processes:               268");
    o("  Usage of /:   2.8% of 239.00GB   Users logged in:         0");
    o(["  Memory usage: 4%                 IPv4 address for ens192: ", [host, "t-mag"]]);
    o("  Swap usage:   0%");
    o("");
    o(" * Strictly confined Kubernetes makes edge and IoT secure. Learn how MicroK8s");
    o("   just raised the bar for easy, resilient and secure K8s cluster deployment.");
    o("");
    o(["   ", ["https://ubuntu.com/engage/secure-kubernetes-at-the-edge", "t-link"]]);
    o("");
    o(["Expanded Security Maintenance for Applications is not ", ["enabled", "t-green"], "."]);
    o("");
    o("260 updates can be applied immediately.");
    o("177 of these updates are standard security updates.");
    o(["To see these additional updates run: ", ["apt list --upgradable", "t-cyan"]]);
    o("");
    o("Enable ESM Apps to receive additional future security updates.");
    o(["See ", ["https://ubuntu.com/esm", "t-link"], " or run: sudo pro status"]);
    o("");
    o("");
    o([["Last login:", "t-cyan"], " Wed Jun 24 14:15:47 2026 from ", ["172.16.3.9", "t-mag"]]);
    return nodes;
  }

  function updateMonitor() {
    mon.hidden = !(session && session.authed && monOn);
    monBtn.setAttribute("aria-pressed", String(monOn));
  }

  function tickMonitor() {
    if (uploadActive) {
      $("mobaMonCpu").textContent = "4%";
      $("mobaMonMem").textContent = "1.35 GB / 15.62 GB";
      $("mobaMonUp").textContent = "3.43 Mb/s";
      $("mobaMonDown").textContent = "620.16 Mb/s";
      return;
    }
    const rate = () => (Math.floor(Math.random() * 4) / 100).toFixed(2) + " Mb/s";
    $("mobaMonCpu").textContent = Math.floor(Math.random() * 3) + "%";
    $("mobaMonMem").textContent = (1.05 + Math.floor(Math.random() * 3) / 100).toFixed(2) + " GB / 15.62 GB";
    $("mobaMonUp").textContent = rate();
    $("mobaMonDown").textContent = rate();
  }

  function finishLogin() {
    const s = session;
    s.pendingLogin = false;
    s.authed = true;
    sftpBtn.hidden = false;
    renderSftp();
    if (!term.hidden) setSide("sftp");
    updateMonitor();
    clearInterval(monTimer);
    monTimer = setInterval(tickMonitor, 2000);
    sessionTimers.push(setTimeout(() => {
      s.out.remove();
      loginOutput(s.user, s.host).forEach((n) => screenEl.appendChild(n));
      newPrompt();
    }, 350));
  }

  // ── Shell ──────────────────────────────────────────────────────
  const scrollEnd = () => {
    screenEl.scrollTop = screenEl.scrollHeight;
  };

  function newPrompt() {
    const s = session;
    if (s.lastCmd) {
      track("command-done", { text: s.lastCmd });
      s.lastCmd = null;
    }
    const line = outLine(s.user + "@" + s.shell.host + ":" + window.MobaShell.promptPath(s.shell) + (s.user === "root" ? "# " : "$ "));
    s.cmdEl = el("span", "");
    line.appendChild(s.cmdEl);
    line.appendChild(cursorEl);
    screenEl.appendChild(line);
    s.mode = "shell";
    s.cmd = "";
    s.draft = "";
    s.histPos = s.history.length;
    scrollEnd();
  }

  function setCmd(text) {
    session.cmd = text;
    session.cmdEl.textContent = text;
    scrollEnd();
  }

  function printLine(parts) {
    screenEl.appendChild(outLine(parts));
    scrollEnd();
  }

  function shellKey(e, ctrl) {
    const s = session;
    const key = e.key.toLowerCase();
    if (ctrl && !e.altKey && key === "c") {
      if (String(window.getSelection())) return;
      e.preventDefault();
      interrupt();
      return;
    }
    if (s.mode === "busy") {
      if (!ctrl && !e.metaKey && (e.key.length === 1 || e.key === "Enter")) e.preventDefault();
      return;
    }
    if (ctrl && !e.altKey && key === "l" && s.mode === "shell") {
      e.preventDefault();
      const keep = s.cmd;
      screenEl.textContent = "";
      newPrompt();
      setCmd(keep);
      return;
    }
    if (e.metaKey || ctrl) return;
    if (e.key === "Enter") {
      e.preventDefault();
      if (s.mode === "confirm") answerContinue();
      else runCommand();
    } else if (e.key === "Backspace") {
      e.preventDefault();
      setCmd(s.cmd.slice(0, -1));
    } else if (e.key === "ArrowUp" && s.mode === "shell") {
      e.preventDefault();
      if (s.histPos > 0) {
        if (s.histPos === s.history.length) s.draft = s.cmd;
        s.histPos--;
        setCmd(s.history[s.histPos]);
      }
    } else if (e.key === "ArrowDown" && s.mode === "shell") {
      e.preventDefault();
      if (s.histPos < s.history.length) {
        s.histPos++;
        setCmd(s.histPos === s.history.length ? s.draft : s.history[s.histPos]);
      }
    } else if (e.key === "Tab") {
      e.preventDefault();
      if (s.mode === "shell") tabComplete();
      return;
    } else if (e.key.length === 1) {
      e.preventDefault();
      setCmd(s.cmd + e.key);
    }
    s.lastTab = false;
  }

  function tabComplete() {
    const s = session;
    const r = window.MobaShell.complete(s.shell, s.cmd);
    if (r.line !== s.cmd) {
      setCmd(r.line);
      s.lastTab = false;
    } else if (r.matches.length > 1) {
      if (s.lastTab) {
        const keep = s.cmd;
        cursorEl.remove();
        printLine(r.matches.join("  "));
        newPrompt();
        setCmd(keep);
      }
      s.lastTab = !s.lastTab;
    }
  }

  function interrupt() {
    const s = session;
    s.lastCmd = null;
    clearTimeout(s.runTimer);
    if (s.progressEl) {
      s.progressEl.remove();
      s.progressEl = null;
    }
    cursorEl.remove();
    if (s.mode === "shell" || s.mode === "confirm") s.cmdEl.appendChild(document.createTextNode("^C"));
    else printLine("^C");
    newPrompt();
  }

  // While replaying, timed output is written at once so the final state appears without waiting.
  function delay(ms) {
    return window.SimLabsProgress && window.SimLabsProgress.replaying ? 0 : ms;
  }

  // Prints steps one after another; a step with `append` continues the previous line.
  const PROGRESS_MIN_MS = 2000;
  function stream(steps, done) {
    const s = session;
    if (window.SimLabsProgress && window.SimLabsProgress.replaying) {
      let shown = null;
      steps.forEach((st) => {
        if (st.append && shown) {
          shown.appendChild(document.createTextNode(st.text));
        } else {
          shown = outLine(st.text);
          screenEl.appendChild(shown);
        }
      });
      scrollEnd();
      if (done) done();
      else newPrompt();
      return;
    }
    let i = 0;
    let last = null;
    // Long steps get a progress line that stays at the bottom while output scrolls above it.
    const total = steps.reduce((sum, st) => sum + st.delay, 0);
    let spent = 0;
    const bar = total >= PROGRESS_MIN_MS ? outLine("") : null;
    const place = (node) => screenEl.insertBefore(node, bar);
    const updateBar = () => {
      if (!bar) return;
      const pct = Math.min(99, Math.floor((spent / total) * 100));
      bar.textContent = "Progress: [" + "#".repeat(Math.floor(pct / 5)).padEnd(20, "-") + "] " + pct + "%";
    };
    if (bar) {
      bar.classList.add("moba-term__progress");
      s.progressEl = bar;
      screenEl.appendChild(bar);
      updateBar();
    }
    const next = () => {
      if (i >= steps.length) {
        if (bar) {
          bar.remove();
          s.progressEl = null;
        }
        if (done) done();
        else newPrompt();
        return;
      }
      const st = steps[i++];
      s.runTimer = setTimeout(() => {
        spent += st.delay;
        if (st.append && last) {
          last.appendChild(document.createTextNode(st.text));
        } else {
          last = outLine(st.text);
          place(last);
        }
        updateBar();
        scrollEnd();
        next();
      }, st.delay);
      sessionTimers.push(s.runTimer);
    };
    next();
  }

  const APT_FETCH = [
    "Hit:1 http://archive.ubuntu.com/ubuntu noble InRelease",
    "Get:2 http://archive.ubuntu.com/ubuntu noble-updates InRelease [126 kB]",
    "Get:3 http://archive.ubuntu.com/ubuntu noble-backports InRelease [126 kB]",
    "Get:4 http://security.ubuntu.com/ubuntu noble-security InRelease [126 kB]",
    "Get:5 http://archive.ubuntu.com/ubuntu noble-updates/main amd64 Packages [1,402 kB]",
    "Get:6 http://archive.ubuntu.com/ubuntu noble-updates/main Translation-en [281 kB]",
    "Get:7 http://archive.ubuntu.com/ubuntu noble-updates/main amd64 Components [175 kB]",
    "Get:8 http://archive.ubuntu.com/ubuntu noble-updates/universe amd64 Packages [1,184 kB]",
    "Get:9 http://archive.ubuntu.com/ubuntu noble-updates/universe Translation-en [301 kB]",
    "Get:10 http://archive.ubuntu.com/ubuntu noble-updates/universe amd64 Components [377 kB]",
    "Get:11 http://security.ubuntu.com/ubuntu noble-security/main amd64 Packages [1,148 kB]",
    "Get:12 http://security.ubuntu.com/ubuntu noble-security/main Translation-en [208 kB]",
    "Get:13 http://security.ubuntu.com/ubuntu noble-security/universe amd64 Packages [892 kB]",
    "Get:14 http://security.ubuntu.com/ubuntu noble-security/universe Translation-en [199 kB]"
  ];
  const APT_HIT = [
    "Hit:1 http://archive.ubuntu.com/ubuntu noble InRelease",
    "Hit:2 http://archive.ubuntu.com/ubuntu noble-updates InRelease",
    "Hit:3 http://archive.ubuntu.com/ubuntu noble-backports InRelease",
    "Hit:4 http://security.ubuntu.com/ubuntu noble-security InRelease"
  ];

  function aptUpdate() {
    const s = session;
    if (s.user !== "root" && !s.sudo) {
      stream([
        { text: "Reading package lists... Done", delay: 400 },
        { text: "E: Could not open lock file /var/lib/apt/lists/lock - open (13: Permission denied)", delay: 300 },
        { text: "E: Unable to lock directory /var/lib/apt/lists/", delay: 100 },
        { text: "W: Problem unlinking the file /var/cache/apt/pkgcache.bin - RemoveCaches (13: Permission denied)", delay: 100 },
        { text: "W: Problem unlinking the file /var/cache/apt/srcpkgcache.bin - RemoveCaches (13: Permission denied)", delay: 100 }
      ]);
      return;
    }
    const steps = [];
    if (s.aptUpdated) {
      APT_HIT.forEach((t, i) => steps.push({ text: t, delay: i ? 150 : 700 }));
    } else {
      APT_FETCH.forEach((t, i) => steps.push({ text: t, delay: i ? 160 : 700 }));
      steps.push({ text: "Fetched 6,545 kB in 3s (2,181 kB/s)", delay: 700 });
    }
    steps.push({ text: "Reading package lists...", delay: 500 }, { text: " Done", delay: 600, append: true });
    steps.push({ text: "Building dependency tree...", delay: 150 }, { text: " Done", delay: 700, append: true });
    steps.push({ text: "Reading state information...", delay: 150 }, { text: " Done", delay: 400, append: true });
    steps.push({ text: s.upgraded ? "All packages are up to date." : getUpgradePlan().count + " packages can be upgraded. Run 'apt list --upgradable' to see them.", delay: 200 });
    s.aptUpdated = true;
    stream(steps);
  }

  function runCommand() {
    const s = session;
    const raw = s.cmd;
    const argv = raw.trim().split(/\s+/).filter(Boolean);
    cursorEl.remove();
    if (!argv.length) {
      newPrompt();
      return;
    }
    s.history.push(raw);
    s.lastCmd = argv.join(" ");
    track("command", { text: s.lastCmd });
    s.mode = "busy";
    s.sudo = argv[0] === "sudo";
    const args = s.sudo ? argv.slice(1) : argv;
    const prog = args[0];
    const plain = !/[|;&<>$()`*?~"'\\]/.test(raw);
    if (plain && prog === "clear") {
      screenEl.textContent = "";
      newPrompt();
    } else if (plain && prog === "reboot" && args.length === 1 && (s.user === "root" || s.sudo)) {
      rebootServer();
    } else if (plain && prog === "hpe-vm" && args.length === 1) {
      openVmMenu();
    } else if (plain && (prog === "apt" || prog === "apt-get")) {
      const rest = args.slice(1);
      const sub = rest.find((a) => a[0] !== "-");
      const yes = rest.some((a) => a === "-y" || a === "--yes" || a === "--assume-yes");
      if (sub === "update") {
        aptUpdate();
      } else if (sub === "upgrade") {
        aptUpgrade(yes);
      } else if (sub === "install" && findDebArg(rest)) {
        aptInstallHpeVm(findDebArg(rest));
      } else {
        notAvailable("'" + prog + (sub ? " " + sub : "") + "'");
        newPrompt();
      }
    } else if (plain && prog === "dpkg" && args.some((a) => a === "-i" || a === "--install")) {
      const deb = findDebArg(args.slice(1));
      if (deb) {
        dpkgInstallHpeVm(deb);
      } else {
        s.shell.code = 2;
        printLine("dpkg: error: --install needs at least one package archive file argument");
        newPrompt();
      }
    } else {
      runShell(raw);
    }
  }

  // Returns the absolute path of the first .deb argument, or null.
  function findDebArg(args) {
    const name = args.find((a) => a[0] !== "-" && /\.deb$/.test(a));
    return name ? vfs.resolve(name, session.shell.cwd) : null;
  }

  // Shared completion point for CLI installs; practice mode listens for this event.
  function markHpeVmInstalledByCli() {
    hpeVmInstalled = true;
    track("hpe-vm-cli-install");
  }

  function aptInstallHpeVm(packagePath) {
    const s = session;
    const finish = (code) => {
      s.shell.code = code;
      newPrompt();
    };
    if (s.user !== "root" && !s.sudo) {
      stream([
        { text: "E: Could not open lock file /var/lib/dpkg/lock-frontend - open (13: Permission denied)", delay: 500 },
        { text: "E: Unable to acquire the dpkg frontend lock (/var/lib/dpkg/lock-frontend), are you root?", delay: 100 }
      ], () => finish(100));
      return;
    }
    const file = vfs.stat(packagePath);
    if (!file.node || file.node.t !== "f" || !isHpeVmDeb(packagePath)) {
      track("error", { source: "apt", message: "Unsupported file " + packagePath });
      stream([
        { text: "E: Unsupported file " + packagePath + " given on commandline", delay: 300 }
      ], () => finish(100));
      return;
    }
    const lines = [
      "Reading package lists... Done",
      "Building dependency tree... Done",
      "Reading state information... Done",
      "Note, selecting 'hpe-vm' instead of '" + packagePath + "'"
    ];
    if (hpeVmInstalled) lines.push("hpe-vm is already the newest version (1.0.15-1).");
    lines.push(
      "The following packages were automatically installed and are no longer required:",
      "  linux-headers-6.8.0-124 linux-headers-6.8.0-124-generic",
      "  linux-image-6.8.0-124-generic linux-modules-6.8.0-124-generic",
      "  linux-modules-extra-6.8.0-124-generic linux-tools-6.8.0-124",
      "  linux-tools-6.8.0-124-generic",
      "Use 'apt autoremove' to remove them."
    );
    if (hpeVmInstalled) {
      lines.push("0 upgraded, 0 newly installed, 0 to remove and 1 not upgraded.");
    } else {
      lines.push(
        "The following NEW packages will be installed:",
        "  hpe-vm",
        "0 upgraded, 1 newly installed, 0 to remove and 1 not upgraded.",
        "Selecting previously unselected package hpe-vm.",
        "(Reading database ... 74512 files and directories currently installed.)",
        "Preparing to unpack " + packagePath + " ...",
        "Unpacking hpe-vm (1.0.15-1) ...",
        "Setting up hpe-vm (1.0.15-1) ...",
        "Processing triggers for man-db (2.12.0-4build2) ...",
        "Scanning processes...",
        "Scanning linux images...",
        "",
        "Running kernel seems to be up-to-date.",
        "",
        "Restarting services...",
        " systemctl restart ceph-crash.service corosync.service cron.service dlm.service fsidd.service fwupd.service logd.service multipathd.service nfs-blkmap.service nfs-idmapd.service nfs-mountd.service nfsdcld.service oddjobd.service open-vm-tools.service pacemaker.service pacemaker_remote.service pcsd-ruby.service pcsd.service rpc-gssd.service rpc-statd.service rpcbind.service systemd-machined.service upower.service vgauth.service",
        "",
        "Service restarts being deferred:",
        " /etc/needrestart/restart.d/dbus.service",
        " systemctl restart getty@tty1.service",
        " systemctl restart libvirtd.service",
        " systemctl restart systemd-logind.service",
        " systemctl restart unattended-upgrades.service",
        " systemctl restart virtlockd.service",
        " systemctl restart virtlogd.service",
        "",
        "No containers need to be restarted.",
        "",
        "User sessions running outdated binaries:",
        " root @ session #3: vmtoolsd[1851]",
        " root @ session #75: apt[6089], bash[3845], sshd[3629]",
        " root @ session #76: sshd[3635]",
        " root @ user manager service: systemd[1676]",
        "",
        "No VM guests are running outdated hypervisor (qemu) binaries on this host."
      );
    }
    stream(lines.map((text) => ({ text: text, delay: 250 })), () => {
      markHpeVmInstalledByCli();
      finish(0);
    });
  }

  function isHpeVmDeb(path) {
    return path.split("/").pop() === HPE_VM_DEB_NAME;
  }

  function dpkgInstallHpeVm(packagePath) {
    const s = session;
    const finish = (code) => {
      s.shell.code = code;
      newPrompt();
    };
    if (s.user !== "root" && !s.sudo) {
      printLine("dpkg: error: requested operation requires superuser privilege");
      finish(2);
      return;
    }
    const file = vfs.stat(packagePath);
    if (!file.node || file.node.t !== "f") {
      printLine("dpkg: error: cannot access archive '" + packagePath + "': No such file or directory");
      finish(2);
      return;
    }
    if (!isHpeVmDeb(packagePath)) {
      printLine("dpkg-deb: error: '" + packagePath + "' is not a valid Debian package for this lab");
      finish(2);
      return;
    }
    const lines = hpeVmInstalled
      ? ["(Reading database ... 74512 files and directories currently installed.)",
        "Preparing to unpack " + packagePath + " ...",
        "Unpacking hpe-vm (1.0.15-1) over (1.0.15-1) ..."]
      : ["Selecting previously unselected package hpe-vm.",
        "(Reading database ... 74512 files and directories currently installed.)",
        "Preparing to unpack " + packagePath + " ...",
        "Unpacking hpe-vm (1.0.15-1) ..."];
    lines.push("Setting up hpe-vm (1.0.15-1) ...");
    stream(lines.map((text) => ({ text: text, delay: 250 })), () => {
      markHpeVmInstalledByCli();
      finish(0);
    });
  }

  function openVmMenu() {
    if (!hpeVmInstalled || !hpeVmReady) {
      printLine(hpeVmInstalled
        ? "hpe-vm: reboot required. Run reboot and log in again after the server restarts."
        : "hpe-vm: command not found");
      session.shell.code = hpeVmInstalled ? 1 : 127;
      newPrompt();
      return;
    }
    session.shell.code = 0;
    vmMenuSelected = 6;
    renderVmMenu();
    vmMenuEl.hidden = false;
    session.mode = "vm-menu";
    screenEl.focus({ preventScroll: true });
    track("vm-menu-open");
  }

  function renderVmMenu() {
    vmMenuOptions.forEach((option, index) => {
      option.classList.toggle("is-selected", index === vmMenuSelected);
      option.setAttribute("aria-selected", String(index === vmMenuSelected));
    });
  }

  function closeVmMenu() {
    vmMenuEl.hidden = true;
    if (!session) return;
    session.mode = "shell";
    newPrompt();
    screenEl.focus({ preventScroll: true });
  }

  function vmMenuKey(e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === "ArrowUp" || e.key === "ArrowDown" || e.key === "Home" || e.key === "End") {
      e.preventDefault();
      if (e.key === "Home") vmMenuSelected = 0;
      else if (e.key === "End") vmMenuSelected = vmMenuOptions.length - 1;
      else vmMenuSelected = (vmMenuSelected + (e.key === "ArrowDown" ? 1 : vmMenuOptions.length - 1)) % vmMenuOptions.length;
      renderVmMenu();
      track("vm-menu-nav", { index: vmMenuSelected });
      return;
    }
    if (e.key === "Escape") {
      e.preventDefault();
      closeVmMenu();
      return;
    }
    if (e.key === "Enter") {
      e.preventDefault();
      activateVmMenuOption();
      return;
    }
    if (e.key.length === 1) {
      const index = vmMenuOptions.findIndex((option) => option.dataset.hotkey === e.key.toLowerCase());
      if (index >= 0) {
        e.preventDefault();
        vmMenuSelected = index;
        renderVmMenu();
        track("vm-menu-nav", { index: vmMenuSelected });
      }
    }
  }

  function activateVmMenuOption() {
    if (vmMenuSelected === vmMenuOptions.length - 1) {
      closeVmMenu();
    } else if (vmMenuSelected === 4) {
      openVmManagerInstaller();
    } else {
      notAvailable(vmMenuOptions[vmMenuSelected].textContent.replace(/[<>]/g, "").trim());
    }
  }

  function openVmManagerInstaller() {
    vmMenuEl.hidden = true;
    installerForm.hidden = false;
    installerProgress.hidden = true;
    installerComplete.hidden = true;
    installerError.hidden = true;
    filePickerEl.hidden = true;
    installerEl.hidden = false;
    session.mode = "vm-installer-form";
    installerForm.querySelector("#vmeManagerIp").focus();
    track("vm-installer-open");
  }

  function closeVmManagerInstaller() {
    clearTimeout(installerTimer);
    installerTimer = null;
    installerEl.hidden = true;
    filePickerEl.hidden = true;
    vmMenuEl.hidden = false;
    session.mode = "vm-menu";
    screenEl.focus({ preventScroll: true });
  }

  function focusableControls(container) {
    return Array.from(container.querySelectorAll("input:not([type=hidden]):not(:disabled), select:not(:disabled), button:not(:disabled)"))
      .filter((control) => !control.hidden && control.getClientRects().length > 0);
  }

  function moveOverlayFocus(container, current, delta) {
    const controls = focusableControls(container);
    const index = controls.indexOf(current);
    if (index < 0) {
      if (controls.length) controls[0].focus();
      return;
    }
    controls[Math.max(0, Math.min(controls.length - 1, index + delta))].focus();
  }

  function vmInstallerKey(e) {
    if (e.ctrlKey || e.metaKey || e.altKey || installerEl.hidden) return;
    const target = e.target;
    if (e.key === "ArrowUp" || e.key === "ArrowDown") {
      e.preventDefault();
      moveOverlayFocus(installerForm, target, e.key === "ArrowDown" ? 1 : -1);
    } else if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      if (target instanceof HTMLInputElement && target.type !== "checkbox") return;
      e.preventDefault();
      moveOverlayFocus(installerForm, target, e.key === "ArrowRight" ? 1 : -1);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (target instanceof HTMLButtonElement) target.click();
      else if (target instanceof HTMLSelectElement) {
        if (typeof target.showPicker === "function") target.showPicker();
        else {
          target.selectedIndex = (target.selectedIndex + 1) % target.options.length;
          target.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else {
        if (target instanceof HTMLInputElement && target.type === "checkbox") target.checked = !target.checked;
        moveOverlayFocus(installerForm, target, 1);
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      closeVmManagerInstaller();
    }
  }

  function renderVmFilePicker() {
    const entries = window.MobaShell.listDir(session.shell, pickerDirectory) || [];
    const directories = entries.filter((entry) => entry.node.t === "d").sort((a, b) => a.name.localeCompare(b.name));
    const files = entries.filter((entry) => entry.node.t !== "d").sort((a, b) => a.name.localeCompare(b.name));
    pickerPath.textContent = pickerDirectory;
    pickerFolders.textContent = "";
    pickerFiles.textContent = "";
    pickerFile = "";
    pickerFilename.value = "";
    pickerOpen.disabled = true;

    if (pickerDirectory !== "/") {
      const parent = el("button", "", "..");
      parent.type = "button";
      parent.dataset.folder = "..";
      pickerFolders.appendChild(parent);
    }
    directories.forEach((entry) => {
      const row = el("button", "", entry.name);
      row.type = "button";
      row.dataset.folder = entry.name;
      pickerFolders.appendChild(row);
    });
    if (files.length === 0) pickerFiles.appendChild(el("div", "moba-vme-file-picker__empty", "<empty>"));
    files.forEach((entry) => {
      const row = el("button", "", entry.name);
      row.type = "button";
      row.dataset.file = entry.name;
      pickerFiles.appendChild(row);
    });
  }

  function openVmFilePicker() {
    track("vm-picker-open");
    pickerDirectory = "/";
    renderVmFilePicker();
    filePickerEl.hidden = false;
    session.mode = "vm-file-picker";
    const firstEntry = pickerFolders.querySelector("[data-folder]") || pickerFiles.querySelector("[data-file]");
    (firstEntry || pickerFilename).focus();
  }

  function selectVmFile(name, openIfSelected) {
    const alreadySelected = pickerFile === name;
    pickerFiles.querySelectorAll("[data-file]").forEach((row) => row.classList.toggle("is-selected", row.dataset.file === name));
    pickerFile = name;
    const fullPath = (pickerDirectory === "/" ? "" : pickerDirectory) + "/" + name;
    pickerFilename.value = fullPath;
    pickerOpen.disabled = false;
    track("vm-picker-file", { file: name });
    if (openIfSelected && alreadySelected) openSelectedVmFile();
  }

  function enterVmFolder(name) {
    track("vm-picker-folder", { folder: name });
    pickerDirectory = name === ".."
      ? pickerDirectory.slice(0, pickerDirectory.lastIndexOf("/")) || "/"
      : (pickerDirectory === "/" ? "" : pickerDirectory) + "/" + name;
    renderVmFilePicker();
    const preferred = pickerFolders.querySelector("[data-folder]:not([data-folder='..'])") || pickerFiles.querySelector("[data-file]");
    (preferred || pickerFilename).focus();
  }

  function vmFilePickerKey(e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const target = e.target;
    if (e.key === "Tab") {
      e.preventDefault();
      const controls = focusableControls(filePickerEl);
      const index = controls.indexOf(target);
      const next = (index + (e.shiftKey ? controls.length - 1 : 1)) % controls.length;
      if (controls[next]) controls[next].focus();
    } else if (e.key === "ArrowUp" || e.key === "ArrowDown" || e.key === "ArrowLeft" || e.key === "ArrowRight") {
      if (target === pickerFilename && (e.key === "ArrowLeft" || e.key === "ArrowRight")) return;
      e.preventDefault();
      const delta = e.key === "ArrowUp" || e.key === "ArrowLeft" ? -1 : 1;
      const list = target.closest(".moba-vme-file-picker__files, .moba-vme-file-picker__folders");
      if (list) {
        const rows = Array.from(list.querySelectorAll("[data-folder], [data-file]"));
        if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
          const otherList = list === pickerFiles ? pickerFolders : pickerFiles;
          const next = otherList.querySelector("[data-folder], [data-file]");
          if (next) next.focus();
          else pickerFilename.focus();
        } else {
          const nextIndex = rows.indexOf(target) + delta;
          if (nextIndex >= 0 && nextIndex < rows.length) rows[nextIndex].focus();
          else if (delta > 0) pickerFilename.focus();
        }
      } else {
        moveOverlayFocus(filePickerEl, target, delta);
      }
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (target.matches("[data-folder]")) enterVmFolder(target.dataset.folder);
      else if (target.matches("[data-file]")) {
        selectVmFile(target.dataset.file, false);
        pickerOpen.focus();
      }
      else if (target.matches("[data-file-picker-open]")) openSelectedVmFile();
      else if (target.matches("[data-file-picker-cancel]")) {
        filePickerEl.hidden = true;
        session.mode = "vm-installer-form";
        installerFileInput.focus();
      } else if (target === pickerFilename && pickerFilename.value.trim()) {
        installerFileInput.value = pickerFilename.value.trim();
        filePickerEl.hidden = true;
        session.mode = "vm-installer-form";
        installerFileInput.focus();
      }
    } else if (e.key === " ") {
      if (target.matches("[data-file]")) {
        e.preventDefault();
        selectVmFile(target.dataset.file, false);
      } else if (target.matches("[data-folder]")) {
        e.preventDefault();
        enterVmFolder(target.dataset.folder);
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      filePickerEl.hidden = true;
      session.mode = "vm-installer-form";
      installerFileInput.focus();
    }
  }

  function openSelectedVmFile() {
    if (!pickerFile) return;
    track("vm-picker-done", { file: pickerFile });
    installerFileInput.value = pickerFilename.value;
    filePickerEl.hidden = true;
    session.mode = "vm-installer-form";
    installerFileInput.focus();
  }

  function startVmManagerInstall(event) {
    event.preventDefault();
    installerError.hidden = true;
    const formData = new FormData(installerForm);
    const required = ["ip", "netmask", "gateway", "dns", "url", "hostname", "admin", "password", "confirm", "image"];
    const missing = required.filter((name) => {
      const value = String(formData.get(name) || "").trim();
      return !value || (name === "image" && value === "/");
    });
    if (missing.length) {
      installerError.textContent = "Complete the required VM configuration fields before installing.";
      installerError.hidden = false;
      track("error", { source: "installer", message: "Required fields missing" });
      return;
    }
    if (formData.get("password") !== formData.get("confirm")) {
      installerError.textContent = "Admin Password and Confirm Password do not match.";
      installerError.hidden = false;
      track("error", { source: "installer", message: "Password mismatch" });
      return;
    }
    const practiceError = window.SimLabsPractice ? window.SimLabsPractice.checkInstall(formData) : null;
    if (practiceError) {
      installerError.textContent = practiceError;
      installerError.hidden = false;
      track("error", { source: "installer", message: practiceError });
      return;
    }

    installerForm.hidden = true;
    installerProgress.hidden = false;
    installerProgress.innerHTML = '<div class="moba-vme-installer__progress-title"></div><div class="moba-vme-installer__progress-label"></div><div class="moba-vme-installer__progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100"><span></span></div>';
    const progressTitle = installerProgress.querySelector(".moba-vme-installer__progress-title");
    const progressLabel = installerProgress.querySelector(".moba-vme-installer__progress-label");
    const progressBar = installerProgress.querySelector(".moba-vme-installer__progress-bar");
    const progressFill = progressBar.querySelector("span");
    let step = 0;
    const advance = () => {
      if (session.mode !== "vm-installer") return;
      if (step >= installerProgressSteps.length) {
        showVmManagerInstallComplete(formData);
        return;
      }
      const current = installerProgressSteps[step++];
      progressTitle.textContent = current.title;
      progressLabel.textContent = "Progress: " + current.progress + "%";
      progressBar.setAttribute("aria-valuenow", String(current.progress));
      progressFill.style.width = current.progress + "%";
      installerTimer = setTimeout(advance, delay(current.delay));
      sessionTimers.push(installerTimer);
    };
    session.mode = "vm-installer";
    advance();
  }

  function showVmManagerInstallComplete(formData) {
    managerNetwork = { ip: String(formData.get("ip")).trim(), password: String(formData.get("password")), user: String(formData.get("admin")).trim() };
    managerFs.dns = String(formData.get("dns")).trim();
    window.MobaShell.deployManager(vfs, String(formData.get("hostname")).trim());
    installerProgress.hidden = true;
    installerComplete.hidden = false;
    installerComplete.innerHTML = "";
    installerComplete.appendChild(el("div", "moba-vme-installer__complete-title", "HPE VME Manager VM Installed"));
    installerComplete.appendChild(el("p", "", "Please open a web browser to " + String(formData.get("url")).trim() + " to complete setup."));
    const done = el("button", "moba-vme-installer__done", "OK");
    done.type = "button";
    done.addEventListener("click", closeVmManagerInstaller, { once: true });
    installerComplete.appendChild(done);
    session.mode = "vm-installer-complete";
    done.focus();
    track("vm-install-complete");
  }

  installerForm.addEventListener("submit", startVmManagerInstall);
  installerEl.addEventListener("keydown", vmInstallerKey);
  installerEl.querySelector("[data-installer-browse]").addEventListener("click", openVmFilePicker);
  installerEl.querySelector('[data-installer-action="abort"]').addEventListener("click", closeVmManagerInstaller);
  installerEl.querySelector('[data-installer-action="help"]').addEventListener("click", () => {
    installerError.textContent = "Enter the VM configuration, choose a QCOW image, and select Install to start.";
    installerError.hidden = false;
  });
  filePickerEl.addEventListener("click", (event) => {
    const folder = event.target.closest("[data-folder]");
    const file = event.target.closest("[data-file]");
    if (folder) {
      pickerFolders.querySelectorAll("[data-folder]").forEach((row) => row.classList.toggle("is-selected", row === folder));
    } else if (file) {
      selectVmFile(file.dataset.file);
    }
  });
  filePickerEl.addEventListener("keydown", vmFilePickerKey);
  filePickerEl.addEventListener("dblclick", (event) => {
    const folder = event.target.closest("[data-folder]");
    if (!folder) return;
    enterVmFolder(folder.dataset.folder);
  });
  filePickerEl.querySelector("[data-file-picker-open]").addEventListener("click", openSelectedVmFile);
  filePickerEl.querySelector("[data-file-picker-cancel]").addEventListener("click", () => {
    filePickerEl.hidden = true;
    session.mode = "vm-installer-form";
    installerFileInput.focus();
  });

  vmMenuEl.addEventListener("click", (e) => {
    const option = e.target.closest("[data-vm-option]");
    if (!option) return;
    vmMenuSelected = Number(option.dataset.vmOption);
    renderVmMenu();
    track("vm-menu-nav", { index: vmMenuSelected });
    if (vmMenuSelected === 4 || vmMenuSelected === vmMenuOptions.length - 1) activateVmMenuOption();
    else screenEl.focus({ preventScroll: true });
  });
  vmMenuEl.addEventListener("dblclick", activateVmMenuOption);

  // The server drops the connection, MobaXterm shows "Session stopped", and the login prompt returns once the VM is back up.
  const REBOOT_MS = 90000;

  function rebootServer() {
    const s = session;
    const later = (fn, ms) => {
      s.runTimer = setTimeout(() => {
        if (session === s) fn();
      }, delay(ms));
      sessionTimers.push(s.runTimer);
    };
    later(() => {
      printLine(s.user + "@" + SSH_HOSTNAME + ":" + window.MobaShell.promptPath(s.shell) + (s.user === "root" ? "# " : "$ "));
      later(() => {
        s.mode = "stopped";
        s.authed = false;
        clearInterval(monTimer);
        monTimer = null;
        updateMonitor();
        sftpBtn.hidden = true;
        setSide("sessions");
        printLine([["Remote side unexpectedly closed network connection", "t-red"]]);
        printLine("");
        printLine("");
        screenEl.appendChild(el("div", "moba-term__rule"));
        printLine([["Session stopped", "t-red"]]);
        printLine(["    - Press ", ["<Return>", "t-mag"], " to exit tab"]);
        printLine(["    - Press ", ["R", "t-mag"], " to restart session"]);
        printLine(["    - Press ", ["S", "t-mag"], " to save terminal output to file"]);
        const last = outLine("");
        last.appendChild(cursorEl);
        screenEl.appendChild(last);
        scrollEnd();
        later(() => {
          hpeVmReady = hpeVmInstalled;
          if (guided) s.rebootDone = true;
          else restartSession();
        }, REBOOT_MS);
      }, 500);
    }, 300);
  }

  function restartSession() {
    const s = session;
    s.rebootDone = false;
    s.shell = window.MobaShell.createState(vfs, s.user, SSH_HOSTNAME, s.host, SSH_CLIENT_IP);
    s.shell.history = s.history;
    s.sudo = false;
    s.cmd = "";
    s.mode = "";
    screenEl.textContent = "";
    showTab("term");
    askPassword();
    screenEl.focus({ preventScroll: true });
    track("session-restart");
  }

  let charWidthCache = 0;
  function terminalColumns() {
    if (!charWidthCache) {
      const ctx = document.createElement("canvas").getContext("2d");
      const font = getComputedStyle(screenEl).font;
      if (ctx && font) ctx.font = font;
      charWidthCache = (ctx && ctx.measureText("M").width) || 10;
    }
    return Math.max(40, Math.floor((screenEl.clientWidth - 40) / charWidthCache));
  }

  function printChunks(chunks) {
    let lines = [];
    let cur = null;
    chunks.forEach((ch) => {
      if (ch && ch.clear) {
        screenEl.textContent = "";
        lines = [];
        cur = null;
        return;
      }
      const text = Array.isArray(ch) ? ch[0] : ch;
      const cls = Array.isArray(ch) ? ch[1] : null;
      String(text).split("\n").forEach((seg, i) => {
        if (i > 0) {
          if (cur === null) lines.push([]);
          cur = null;
        }
        if (!seg) return;
        if (!cur) {
          cur = [];
          lines.push(cur);
        }
        cur.push(cls ? [seg, cls] : seg);
      });
    });
    lines.forEach((parts) => screenEl.appendChild(outLine(parts.length ? parts : "")));
    scrollEnd();
  }

  function runShell(raw) {
    const s = session;
    s.shell.cols = terminalColumns();
    const res = window.MobaShell.run(raw, s.shell);
    const finish = () => {
      if (session !== s) return;
      printChunks(res.chunks);
      if (res.unsupported) notAvailable("'" + res.unsupported + "'");
      renderSftp();
      if (res.exit) {
        printLine("logout");
        sessionTimers.push(setTimeout(() => {
          if (session === s) resetSession();
        }, 400));
        return;
      }
      newPrompt();
    };
    if (res.delay) {
      s.runTimer = setTimeout(finish, delay(res.delay));
      sessionTimers.push(s.runTimer);
    } else {
      finish();
    }
  }

  // Mirrors the terminal's current folder in the SFTP browser.
  function renderSftp() {
    if (!session || !session.shell) return;
    const st = session.shell;
    const entries = window.MobaShell.listDir(st, st.cwd) || [];
    const key = (n) => n.replace(/^\./, "").toLowerCase();
    const sorted = (list) => list.sort((a, b) => (key(a.name) < key(b.name) ? -1 : key(a.name) > key(b.name) ? 1 : 0));
    const isDir = (e) => e.node.t === "d";
    const list = sftp.querySelector(".moba-sftp__list");
    list.textContent = "";
    const add = (name, icon) => {
      const row = document.createElement("div");
      row.innerHTML = icon;
      row.appendChild(el("span", "", name));
      row.title = name;
      list.appendChild(row);
    };
    if (st.cwd !== "/") add("..", SFTP_UP);
    sorted(entries.filter(isDir)).forEach((e) => add(e.name, icon20(FOLDER)));
    sorted(entries.filter((e) => !isDir(e))).forEach((e) => add(e.name, icon20(SFTP_SYSTEM_FILES.indexOf(e.name) >= 0 ? DOT_FILE : PLAIN_FILE)));
    sftp.querySelector(".moba-sftp__path span").textContent = st.cwd === "/" ? "/" : st.cwd + "/";
  }

  // ── apt upgrade ────────────────────────────────────────────────
  const UPGRADE_PACKAGES = `
apparmor apport apport-core-dump-handler apt apt-utils base-files bash bind9-dnsutils bind9-host bind9-libs binutils binutils-common
binutils-x86-64-linux-gnu bsdextrautils bsdutils busybox-initramfs busybox-static ca-certificates cloud-init coreutils cpio cryptsetup
cryptsetup-bin cryptsetup-initramfs curl dbus dbus-bin dbus-daemon dbus-session-bus-common dbus-system-bus-common dbus-user-session
dirmngr dmidecode dmsetup dpkg dpkg-dev e2fsprogs e2fsprogs-l10n eject fdisk file findutils fwupd gcc-14-base gir1.2-glib-2.0 git git-man
gnupg gnupg-l10n gnupg-utils gpg gpg-agent gpg-wks-client gpgconf gpgsm gpgv grub-common grub-efi-amd64-bin grub-efi-amd64-signed
grub-pc grub-pc-bin grub2-common gzip initramfs-tools initramfs-tools-bin initramfs-tools-core iproute2 iputils-ping keyboard-configuration
klibc-utils kmod krb5-locales libacl1 libapparmor1 libattr1 libaudit-common libaudit1 libblkid1 libbz2-1.0 libc-bin libc-dev-bin libc6 libc6-dev
libcap2 libcap2-bin libcom-err2 libcryptsetup12 libcurl3t64-gnutls libcurl4t64 libdb5.3t64 libdbus-1-3 libdebconfclient0 libdpkg-perl libefiboot1t64
libefivar1t64 libelf1t64 libexpat1 libext2fs2t64 libfdisk1 libfwupd2 libgcc-s1 libgcrypt20 libgdbm-compat4t64 libgdbm6t64 libglib2.0-0t64 libglib2.0-bin
libglib2.0-data libgmp10 libgnutls30t64 libgpg-error0 libgssapi-krb5-2 libhogweed6t64 libidn2-0 libip4tc2 libip6tc2 libjansson4 libjson-c5 libk5crypto3
libklibc libkmod2 libkrb5-3 libkrb5support0 libldap2 liblzma5 libmagic-mgc libmagic1t64 libmnl0 libmount1 libncurses6 libncursesw6 libnetplan1
libnettle8t64 libnftables1 libnghttp2-14 libnl-3-200 libnl-genl-3-200 libnss-systemd libnuma1 libp11-kit0 libpam-modules libpam-modules-bin
libpam-runtime libpam-systemd libpam0g libparted2t64 libpcap0.8t64 libpcre2-8-0 libperl5.38t64 libpng16-16t64 libpolkit-agent-1-0
libpolkit-gobject-1-0 libpsl5t64 libpython3.12-minimal libpython3.12-stdlib libpython3.12t64 libreadline8t64 libsasl2-2 libsasl2-modules
libsasl2-modules-db libseccomp2 libselinux1 libsmartcols1 libsqlite3-0 libss2 libssh-4 libssl3t64 libstdc++6 libsystemd-shared libsystemd0
libtasn1-6 libtinfo6 libudev1 libunistring5 libuuid1 libxml2 libxmlb2 libxslt1.1 libxtables12 libxxhash0 libyaml-0-2 libzstd1 linux-base
linux-firmware linux-generic linux-headers-generic linux-image-generic locales login logsave mawk media-types mount nano ncurses-base ncurses-bin
ncurses-term netplan-generator netplan.io nftables open-vm-tools openssh-client openssh-server openssh-sftp-server openssl parted passwd pciutils
perl perl-base perl-modules-5.38 pinentry-curses pkexec policykit-1 polkitd python3 python3-apport python3-cryptography python3-distro-info
python3-gi python3-jinja2 python3-minimal python3-netplan python3-pkg-resources python3-problem-report python3-setuptools python3-urllib3
python3-yaml python3.12 python3.12-minimal readline-common rsync rsyslog sensible-utils shim-signed snapd sudo systemd systemd-dev
systemd-resolved systemd-sysv systemd-timesyncd tar tcpdump tzdata ubuntu-minimal ubuntu-pro-client ubuntu-pro-client-l10n ubuntu-standard
udev ufw unattended-upgrades usb.ids util-linux vim vim-common vim-runtime vim-tiny xxd xz-utils zlib1g`.trim().split(/\s+/);

  const ARCH_ALL = /^(python3-.*|perl-modules-.*|ca-certificates|tzdata|locales|base-files|distro-info-data|usb\.ids|linux-firmware|vim-runtime|readline-common|ufw|apport|cloud-init|ubuntu-pro-client-l10n|sensible-utils|keyboard-configuration|e2fsprogs-l10n|ncurses-base|ncurses-term|media-types|unattended-upgrades|gnupg|gnupg-l10n|dbus-session-bus-common|dbus-system-bus-common|libglib2\.0-data|initramfs-tools|initramfs-tools-core|linux-base|krb5-locales)$/;
  const BIG_PACKAGES = { "linux-firmware": 291400, snapd: 29500, "vim-runtime": 7312, systemd: 3820, libc6: 2905, "libc6-dev": 2118, fwupd: 4140, "perl-modules-5.38": 3120, "python3.12-minimal": 2411, "cloud-init": 614 };

  const hashOf = (str) => {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  };
  const fmtKb = (kb) => (kb < 10000 ? kb.toLocaleString("en-US") + " kB" : fmtMb(kb));
  const fmtMb = (kb) => {
    const mb = kb / 1000;
    return (mb >= 100 ? Math.round(mb) : mb.toFixed(1)) + " MB";
  };

  // Versions and sizes are generated from the package name, so they are stable between runs.
  let planCache = null;
  function getUpgradePlan() {
    if (planCache) return planCache;
    const items = UPGRADE_PACKAGES.map((name) => {
      const h = hashOf(name);
      const arch = ARCH_ALL.test(name) ? "all" : "amd64";
      const m = 3 + (h % 6);
      const base = 1 + ((h >>> 3) % 9) + "." + ((h >>> 7) % 40) + "." + ((h >>> 13) % 12);
      return {
        name: name,
        arch: arch,
        ver: base + "-0ubuntu0.24.04." + m,
        old: base + "-0ubuntu0.24.04." + (m - 1 - (h % 2)),
        kb: BIG_PACKAGES[name] || 15 + ((h >>> 5) % 1500),
        sec: h % 3 === 0,
        label: name + (name.indexOf("lib") === 0 && arch !== "all" ? ":amd64" : "")
      };
    });
    const wrapped = [];
    let line = "  ";
    items.forEach((p) => {
      if (line.trim() && line.length + p.name.length > 79) {
        wrapped.push(line.trimEnd());
        line = "  ";
      }
      line += p.name + " ";
    });
    wrapped.push(line.trimEnd());
    const totalKb = items.reduce((sum, p) => sum + p.kb, 0);
    planCache = { items: items, wrapped: wrapped, count: items.length, totalKb: totalKb };
    return planCache;
  }

  function aptUpgrade(yes) {
    const s = session;
    if (s.user !== "root" && !s.sudo) {
      stream([
        { text: "E: Could not open lock file /var/lib/dpkg/lock-frontend - open (13: Permission denied)", delay: 500 },
        { text: "E: Unable to acquire the dpkg frontend lock (/var/lib/dpkg/lock-frontend), are you root?", delay: 100 }
      ]);
      return;
    }
    const steps = [
      { text: "Reading package lists...", delay: 600 }, { text: " Done", delay: 500, append: true },
      { text: "Building dependency tree...", delay: 150 }, { text: " Done", delay: 600, append: true },
      { text: "Reading state information...", delay: 150 }, { text: " Done", delay: 400, append: true },
      { text: "Calculating upgrade...", delay: 150 }, { text: " Done", delay: 700, append: true }
    ];
    if (s.upgraded) {
      steps.push({ text: "0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.", delay: 200 });
      stream(steps);
      return;
    }
    const plan = getUpgradePlan();
    steps.push({ text: "The following packages will be upgraded:", delay: 150 });
    plan.wrapped.forEach((l) => steps.push({ text: l, delay: 30 }));
    steps.push(
      { text: plan.count + " upgraded, 0 newly installed, 0 to remove and 0 not upgraded.", delay: 150 },
      { text: "Need to get " + fmtMb(plan.totalKb) + " of archives.", delay: 30 },
      { text: "After this operation, " + fmtMb(plan.totalKb * 0.2) + " of additional disk space will be used.", delay: 30 }
    );
    stream(steps, yes ? upgradeDownload : askContinue);
  }

  function askContinue() {
    const s = session;
    const line = outLine("Do you want to continue? [Y/n] ");
    s.cmdEl = el("span", "");
    line.appendChild(s.cmdEl);
    line.appendChild(cursorEl);
    screenEl.appendChild(line);
    s.mode = "confirm";
    s.cmd = "";
    scrollEnd();
  }

  function answerContinue() {
    const s = session;
    const a = s.cmd.trim().toLowerCase();
    cursorEl.remove();
    if (!a || a === "y" || a === "yes") {
      s.mode = "busy";
      upgradeDownload();
    } else {
      printLine("Abort.");
      newPrompt();
    }
  }

  function upgradeDownload() {
    const plan = getUpgradePlan();
    const secs = Math.max(2, Math.round(plan.totalKb / 30000));
    const steps = plan.items.map((p, i) => ({
      text: "Get:" + (i + 1) + " http://" + (p.sec ? "security" : "archive") + ".ubuntu.com/ubuntu noble-" + (p.sec ? "security" : "updates") + "/main amd64 " + p.name + " " + p.arch + " " + p.ver + " [" + fmtKb(p.kb) + "]",
      delay: i ? 12 : 600
    }));
    steps.push(
      { text: "Fetched " + fmtMb(plan.totalKb) + " in " + secs + "s (" + (plan.totalKb / 1000 / secs).toFixed(1) + " MB/s)", delay: 600 },
      { text: "Extracting templates from packages: 100%", delay: 500 },
      { text: "Preconfiguring packages ...", delay: 400 }
    );
    stream(steps, () => (practice ? upgradeInstall() : runTui(KEYBOARD_SCREENS, upgradeInstall)));
  }

  function upgradeInstall() {
    const plan = getUpgradePlan();
    const steps = [{ text: "(Reading database ... 74512 files and directories currently installed.)", delay: 500 }];
    plan.items.forEach((p, i) => {
      steps.push(
        { text: "Preparing to unpack .../" + String(i).padStart(3, "0") + "-" + p.name + "_" + p.ver + "_" + p.arch + ".deb ...", delay: i ? 10 : 300 },
        { text: "Unpacking " + p.label + " (" + p.ver + ") over (" + p.old + ") ...", delay: 4 }
      );
    });
    plan.items.forEach((p, i) => steps.push({ text: "Setting up " + p.label + " (" + p.ver + ") ...", delay: i ? 8 : 400 }));
    [
      "Processing triggers for man-db (2.12.0-4build2) ...",
      "Processing triggers for libc-bin (2.39-0ubuntu8.6) ...",
      "Processing triggers for initramfs-tools (0.142ubuntu25.5) ...",
      "update-initramfs: Generating /boot/initrd.img-6.8.0-137-generic",
      "Scanning processes...",
      "Scanning linux images...",
      "",
      "Running kernel seems to be up-to-date.",
      "",
      "Restarting services...",
      "",
      "Service restarts being deferred:",
      " systemctl restart unattended-upgrades.service",
      "",
      "No containers need to be restarted.",
      "",
      "No user sessions are running outdated binaries.",
      "",
      "No VM guests are running outdated hypervisor (qemu) binaries on this host."
    ].forEach((t, i) => steps.push({ text: t, delay: i < 4 ? 500 : 250 }));
    stream(steps, () => {
      session.upgraded = true;
      newPrompt();
    });
  }

  // ── Full-screen text dialogs (debconf) ─────────────────────────
  const rowHeight = () => (tui.list.firstElementChild ? tui.list.firstElementChild.offsetHeight || 18 : 18);

  function runTui(screens, done) {
    const s = session;
    s.mode = "tui";
    s.tui = { screens: screens, i: 0, sel: 0, focus: "list", done: done };
    s.runTimer = setTimeout(() => {
      tuiEl.hidden = false;
      showTuiScreen();
    }, delay(700));
    sessionTimers.push(s.runTimer);
  }

  function showTuiScreen() {
    const t = session.tui;
    const sc = t.screens[t.i];
    tui.title.textContent = sc.title;
    tui.text.textContent = sc.text;
    tui.label.textContent = sc.label;
    tui.list.textContent = "";
    sc.items.forEach((item, idx) => {
      const row = el("div", "moba-tui__row", item);
      row.dataset.i = String(idx);
      tui.list.appendChild(row);
    });
    t.sel = Math.max(0, sc.items.indexOf(sc.sel));
    t.focus = "list";
    tui.list.scrollTop = 0;
    tuiRender();
  }

  function tuiRender() {
    const t = session.tui;
    const rows = tui.list.children;
    // Show whole rows only, as a text terminal would.
    tui.list.style.height = "";
    const rh = (rows[0] && rows[0].offsetHeight) || 18;
    const avail = tui.wrap.clientHeight;
    tui.list.style.height = Math.max(rh * 3, Math.floor(avail / rh) * rh) + "px";
    for (let i = 0; i < rows.length; i++) rows[i].classList.toggle("is-sel", i === t.sel);
    const row = rows[t.sel];
    if (row) {
      const top = t.sel * rh;
      if (top < tui.list.scrollTop) tui.list.scrollTop = top;
      else if (top + rh > tui.list.scrollTop + tui.list.clientHeight) tui.list.scrollTop = top + rh - tui.list.clientHeight;
    }
    tui.btns.forEach((b) => b.classList.toggle("is-focus", b.dataset.b === t.focus));
    const range = tui.list.scrollHeight - tui.list.clientHeight;
    tui.bar.style.visibility = range > 0 ? "visible" : "hidden";
    const trackH = tui.track.clientHeight;
    const thumbH = Math.max(8, (trackH * tui.list.clientHeight) / Math.max(1, tui.list.scrollHeight));
    tui.thumb.style.height = thumbH + "px";
    tui.thumb.style.top = (range > 0 ? ((trackH - thumbH) * tui.list.scrollTop) / range : 0) + "px";
  }

  function tuiAccept() {
    const t = session.tui;
    t.i++;
    tuiEl.hidden = true;
    if (t.i < t.screens.length) {
      session.runTimer = setTimeout(() => {
        tuiEl.hidden = false;
        showTuiScreen();
      }, delay(500));
      sessionTimers.push(session.runTimer);
      return;
    }
    const done = t.done;
    session.tui = null;
    session.mode = "busy";
    screenEl.focus({ preventScroll: true });
    done();
  }

  function tuiKey(e) {
    const t = session.tui;
    if (!t || tuiEl.hidden || e.ctrlKey || e.metaKey || e.altKey) return;
    const items = t.screens[t.i].items;
    const order = ["list", "ok", "cancel"];
    const page = Math.max(1, Math.floor(tui.list.clientHeight / rowHeight()) - 1);
    const move = (to) => {
      t.sel = Math.min(items.length - 1, Math.max(0, to));
    };
    const k = e.key;
    let handled = true;
    if (k === "Tab") {
      t.focus = order[(order.indexOf(t.focus) + (e.shiftKey ? 2 : 1)) % 3];
    } else if (k === "Enter" || (k === " " && t.focus !== "list")) {
      e.preventDefault();
      tuiAccept();
      return;
    } else if (t.focus === "list" && k === "ArrowUp") move(t.sel - 1);
    else if (t.focus === "list" && k === "ArrowDown") move(t.sel + 1);
    else if (t.focus === "list" && k === "PageUp") move(t.sel - page);
    else if (t.focus === "list" && k === "PageDown") move(t.sel + page);
    else if (t.focus === "list" && k === "Home") move(0);
    else if (t.focus === "list" && k === "End") move(items.length - 1);
    else if (t.focus !== "list" && (k === "ArrowLeft" || k === "ArrowRight")) t.focus = t.focus === "ok" ? "cancel" : "ok";
    else if (t.focus === "list" && k.length === 1) {
      const lower = k.toLowerCase();
      for (let n = 1; n <= items.length; n++) {
        const idx = (t.sel + n) % items.length;
        if (items[idx].toLowerCase().indexOf(lower) === 0) {
          t.sel = idx;
          break;
        }
      }
    } else handled = false;
    if (handled) {
      e.preventDefault();
      tuiRender();
    }
  }

  tuiEl.addEventListener("click", (e) => {
    const t = session && session.tui;
    if (!t) return;
    const row = e.target.closest(".moba-tui__row");
    const btn = e.target.closest("[data-b]");
    if (row) {
      t.sel = Number(row.dataset.i);
      t.focus = "list";
      tuiRender();
    } else if (btn) {
      tuiAccept();
    }
  });
  tuiEl.addEventListener("dblclick", (e) => {
    if (session && session.tui && e.target.closest(".moba-tui__row")) tuiAccept();
  });

  function promptLine(host, user) {
    const line = el("div", "moba-term__line");
    const ico = document.createElement("img");
    ico.src = "../Images/MobaXtermIcon.webp";
    ico.alt = "";
    line.appendChild(ico);
    line.appendChild(document.createTextNode(user + "@"));
    line.appendChild(el("span", "moba-term__ip", host));
    line.appendChild(document.createTextNode("'s password:"));
    return line;
  }

  function resetSession() {
    stopUpload();
    uploadDialog.hidden = true;
    sessionTimers.forEach(clearTimeout);
    sessionTimers = [];
    clearTimeout(installerTimer);
    installerTimer = null;
    clearInterval(monTimer);
    monTimer = null;
    monOn = true;
    if (session) session.tab.remove();
    session = null;
    screenEl.textContent = "";
    pw.hidden = true;
    tuiEl.hidden = true;
    vmMenuEl.hidden = true;
    installerEl.hidden = true;
    filePickerEl.hidden = true;
    mon.hidden = true;
    titlebar.classList.remove("is-inactive");
    sftpBtn.hidden = true;
    showTab("home");
  }

  function startSshSession(host, user) {
    resetSession();
    const run = () => {
      if (win.hidden && win.dataset.minimized !== "true") return;
      const tab = el("div", "moba-tab moba-tab--session");
      tab.setAttribute("role", "tab");
      tab.tabIndex = 0;
      tab.insertAdjacentHTML("beforeend", SSH_ICON);
      tab.appendChild(el("span", "", "2. " + host + " (" + user + ")"));
      const x = el("button", "moba-tab__x");
      x.type = "button";
      x.setAttribute("aria-label", "Close tab");
      x.innerHTML = '<svg width="10" height="10" viewBox="0 0 10 10"><path d="M1 1l8 8M9 1L1 9" stroke="currentColor" stroke-width="1.300"/></svg>';
      tab.appendChild(x);
      tabsEl.insertBefore(tab, newTab);
      session = { host: host, user: user, label: host + " (" + user + ")", tab: tab, authed: false, awaiting: false, buf: "", mode: "", history: [], aptUpdated: false, upgraded: false, runTimer: null, cmd: "", cmdEl: null, draft: "", histPos: 0, sudo: false, lastTab: false, shell: null };
      const manager = host !== SSH_HOST;
      session.shell = window.MobaShell.createState(manager ? managerFs : vfs, user, manager ? "hpe-vm1" : SSH_HOSTNAME, host, SSH_CLIENT_IP);
      session.shell.history = session.history;

      x.addEventListener("click", (e) => {
        e.stopPropagation();
        resetSession();
      });
      tab.addEventListener("click", () => {
        showTab("term");
        screenEl.focus({ preventScroll: true });
      });

      screenEl.textContent = "";
      showTab("term");
      askPassword();
      screenEl.focus({ preventScroll: true });
    };
    if (window.VmeDesktop) window.VmeDesktop.busy(700, 1100, run);
    else run();
  }

  function askPassword() {
    const line = promptLine(session.host, session.user);
    screenEl.appendChild(line);
    line.appendChild(cursorEl);
    session.awaiting = true;
    session.buf = "";
  }

  function submitPassword() {
    const s = session;
    const correct = s.host === SSH_HOST ? s.user === "root" && s.buf === SSH_PASSWORD : !!managerNetwork && s.user === managerNetwork.user && s.buf === managerNetwork.password;
    track("ssh-password", { correct: correct });
    s.awaiting = false;
    s.buf = "";
    const out = el("div", "moba-term__line");
    screenEl.appendChild(out);
    out.appendChild(cursorEl);
    s.out = out;
    sessionTimers.push(setTimeout(() => {
      if (correct) {
        s.pendingLogin = true;
        if (skipSavePrompt) finishLogin();
        else sessionTimers.push(setTimeout(openPw, 300));
      } else {
        out.textContent = "Access ";
        out.appendChild(el("span", "moba-term__err", "denied"));
        askPassword();
      }
    }, 600));
  }

  // Keys are handled by the password prompt first, then by the shell once logged in.
  screenEl.tabIndex = 0;
  screenEl.setAttribute("aria-label", "Terminal");
  screenEl.addEventListener("keydown", (e) => {
    if (!session) return;
    const ctrl = (e.ctrlKey || e.altKey) && !e.getModifierState("AltGraph");
    if (session.awaiting) {
      if (e.metaKey || ctrl) return;
      if (e.key === "Enter") {
        e.preventDefault();
        submitPassword();
      } else if (e.key === "Backspace") {
        e.preventDefault();
        session.buf = session.buf.slice(0, -1);
      } else if (e.key.length === 1) {
        e.preventDefault();
        session.buf += e.key;
      }
      return;
    }
    if (session.mode === "shell" || session.mode === "busy" || session.mode === "confirm") shellKey(e, ctrl);
    else if (session.mode === "tui") tuiKey(e);
    else if (session.mode === "vm-menu") vmMenuKey(e);
    else if (session.mode === "vm-installer-form") vmInstallerKey(e);
    else if (session.mode === "vm-file-picker") vmFilePickerKey(e);
    else if (session.mode === "vm-installer-complete" && e.key === "Enter") {
      e.preventDefault();
      closeVmManagerInstaller();
    }
    else if (session.mode === "stopped" && e.key === "Enter") {
      e.preventDefault();
      resetSession();
    }
    else if (guided && session.mode === "stopped" && e.key === "R" && !ctrl && !e.metaKey) {
      e.preventDefault();
      if (session.rebootDone) restartSession();
      else printLine([["Connection refused", "t-red"]]);
    }
  });
  screenEl.addEventListener("paste", (e) => {
    if (!session) return;
    const text = (e.clipboardData.getData("text") || "").split(/\r?\n/)[0];
    if (session.awaiting) {
      e.preventDefault();
      session.buf += text;
    } else if (session.mode === "shell") {
      e.preventDefault();
      setCmd(session.cmd + text);
    }
  });
  term.addEventListener("click", () => screenEl.focus({ preventScroll: true }));
  monBtn.addEventListener("click", () => {
    monOn = !monOn;
    updateMonitor();
  });
  mon.querySelector(".moba-mon__x").addEventListener("click", () => {
    monOn = false;
    updateMonitor();
  });

  homeTab.addEventListener("click", () => showTab("home"));
  starBtn.addEventListener("click", () => setSide("sessions"));
  sftpBtn.addEventListener("click", () => setSide("sftp"));

  pw.addEventListener("click", (e) => {
    if (e.target.closest("[data-pw]")) {
      track("save-password", { answer: e.target.closest("[data-pw]").dataset.pw });
      closePw();
    }
    else if (e.target.closest("#mobaPwInfo")) notAvailable("Help");
  });
  pw.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.stopPropagation();
      closePw();
    }
  });

  win.querySelectorAll("[data-na]").forEach((el) => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      notAvailable(el.dataset.na);
    });
  });

  // ── Window chrome ───────────────────────────────────────────────
  function setTaskbarState() {
    taskbarBtn.classList.toggle("is-open", !win.hidden || win.dataset.minimized === "true");
    taskbarBtn.classList.toggle("is-active", !win.hidden);
  }

  function raise() {
    win.style.zIndex = "6";
    if (explorerWin) explorerWin.style.zIndex = "";
    const chromeWin = $("vmeChrome");
    if (chromeWin) chromeWin.style.zIndex = "4";
  }

  function resetPosition() {
    win.style.left = win.style.top = win.style.right = win.style.bottom = "";
    win.style.width = win.style.height = "";
  }

  function openWindow() {
    win.hidden = false;
    taskbarBtn.hidden = false;
    delete win.dataset.minimized;
    raise();
    setTaskbarState();
  }

  // First launch takes a moment, like a real machine; restoring a minimized window is instant.
  function launch() {
    if (!win.hidden) {
      raise();
      return;
    }
    if (win.dataset.minimized === "true") {
      openWindow();
      return;
    }
    if (launching) return;
    launching = true;
    taskbarBtn.hidden = false;
    taskbarBtn.classList.add("is-open");
    const done = () => {
      launching = false;
      openWindow();
    };
    if (window.VmeDesktop) window.VmeDesktop.busy(600, 1000, done);
    else done();
  }

  function minimizeWindow() {
    win.hidden = true;
    win.dataset.minimized = "true";
    setTaskbarState();
  }

  function closeWindow() {
    win.hidden = true;
    taskbarBtn.hidden = true;
    delete win.dataset.minimized;
    win.classList.remove("is-maximized");
    resetPosition();
    closeSessionDialog();
    resetSession();
    setTaskbarState();
  }

  function toggleMaximize() {
    win.classList.toggle("is-maximized");
    resetPosition();
  }

  document.addEventListener("vme:open-moba", launch);

  taskbarBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    if (win.hidden) launch();
    else minimizeWindow();
  });

  $("mobaMin").addEventListener("click", minimizeWindow);
  $("mobaMax").addEventListener("click", toggleMaximize);
  $("mobaClose").addEventListener("click", closeWindow);
  titlebar.addEventListener("dblclick", (event) => {
    if (!event.target.closest("button")) toggleMaximize();
  });

  // Clicks inside the window must not reach the desktop (which clears icon selection).
  win.addEventListener("click", (event) => {
    event.stopPropagation();
    const startMenu = $("vmeStartMenu");
    if (startMenu && !startMenu.hidden) $("vmeStartBtn").click();
  });

  win.addEventListener("pointerdown", raise);
  if (explorerWin) {
    explorerWin.addEventListener("pointerdown", () => {
      win.style.zIndex = "4";
    });
  }

  titlebar.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || event.target.closest("button") || win.classList.contains("is-maximized")) return;
    const deskRect = desktop.getBoundingClientRect();
    const rect = win.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    const width = rect.width;
    const height = rect.height;

    win.style.width = width + "px";
    win.style.height = height + "px";
    win.style.right = "auto";
    win.style.bottom = "auto";
    titlebar.setPointerCapture(event.pointerId);

    function move(e) {
      const maxLeft = deskRect.width - width;
      const maxTop = deskRect.height - 50 - height;
      win.style.left = Math.min(Math.max(e.clientX - deskRect.left - offsetX, 0), Math.max(maxLeft, 0)) + "px";
      win.style.top = Math.min(Math.max(e.clientY - deskRect.top - offsetY, 0), Math.max(maxTop, 0)) + "px";
    }

    function stop() {
      titlebar.removeEventListener("pointermove", move);
      titlebar.removeEventListener("pointerup", stop);
      titlebar.removeEventListener("pointercancel", stop);
    }

    titlebar.addEventListener("pointermove", move);
    titlebar.addEventListener("pointerup", stop);
    titlebar.addEventListener("pointercancel", stop);
  });
})();
