(function () {
  "use strict";

  const desktop = document.getElementById("vmeDesktop");
  if (!desktop) return;

  const TASKBAR = 50;
  const EDGES = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];

  function makeResizable(win) {
    const minW = parseInt(win.dataset.minW, 10) || 420;
    const minH = parseInt(win.dataset.minH, 10) || 300;

    EDGES.forEach((edge) => {
      const grip = document.createElement("div");
      grip.className = "vme-rz vme-rz--" + edge;
      grip.dataset.edge = edge;
      win.appendChild(grip);
    });

    win.addEventListener("pointerdown", (event) => {
      const grip = event.target.closest(".vme-rz");
      if (!grip || grip.parentNode !== win || event.button !== 0 || win.classList.contains("is-maximized")) return;
      event.preventDefault();
      event.stopPropagation();

      const edge = grip.dataset.edge;
      const deskW = desktop.clientWidth;
      const deskH = desktop.clientHeight - TASKBAR;
      const start = { x: event.clientX, y: event.clientY, l: win.offsetLeft, t: win.offsetTop, w: win.offsetWidth, h: win.offsetHeight };
      const right = start.l + start.w;
      const bottom = start.t + start.h;

      win.style.right = "auto";
      win.style.bottom = "auto";
      win.style.left = start.l + "px";
      win.style.top = start.t + "px";
      win.style.width = start.w + "px";
      win.style.height = start.h + "px";
      grip.setPointerCapture(event.pointerId);

      function move(e) {
        const dx = e.clientX - start.x;
        const dy = e.clientY - start.y;
        let l = start.l;
        let t = start.t;
        let w = start.w;
        let h = start.h;

        if (edge.indexOf("e") >= 0) w = Math.min(Math.max(start.w + dx, minW), deskW - start.l);
        if (edge.indexOf("s") >= 0) h = Math.min(Math.max(start.h + dy, minH), deskH - start.t);
        if (edge.indexOf("w") >= 0) {
          l = Math.min(Math.max(start.l + dx, 0), right - minW);
          w = right - l;
        }
        if (edge.indexOf("n") >= 0) {
          t = Math.min(Math.max(start.t + dy, 0), bottom - minH);
          h = bottom - t;
        }

        win.style.left = l + "px";
        win.style.top = t + "px";
        win.style.width = w + "px";
        win.style.height = h + "px";
      }

      function stop() {
        grip.removeEventListener("pointermove", move);
        grip.removeEventListener("pointerup", stop);
        grip.removeEventListener("pointercancel", stop);
      }

      grip.addEventListener("pointermove", move);
      grip.addEventListener("pointerup", stop);
      grip.addEventListener("pointercancel", stop);
    });

    // Keep a resized window inside the desktop if the browser window shrinks.
    window.addEventListener("resize", () => {
      if (!win.style.width || win.hidden || win.classList.contains("is-maximized")) return;
      const deskW = desktop.clientWidth;
      const deskH = desktop.clientHeight - TASKBAR;
      const w = Math.min(win.offsetWidth, deskW);
      const h = Math.min(win.offsetHeight, deskH);
      win.style.width = Math.max(w, Math.min(minW, deskW)) + "px";
      win.style.height = Math.max(h, Math.min(minH, deskH)) + "px";
      win.style.left = Math.max(0, Math.min(win.offsetLeft, deskW - win.offsetWidth)) + "px";
      win.style.top = Math.max(0, Math.min(win.offsetTop, deskH - win.offsetHeight)) + "px";
    });
  }

  desktop.querySelectorAll("[data-resizable]").forEach(makeResizable);
})();
