// Guided Mode for the VME Installation and Setup lab.
// Shows one step at a time and follows the learner through "vme:track" events sent by the simulator.
(function () {
  "use strict";

  const desktop = document.getElementById("vmeDesktop");
  if (!desktop) return;

  const DONE_MS = 900;
  const DVD = "DVD Drive (E:)";
  const DEB = "hpe-vm_1.0.15-1_amd64.deb";
  const QCOW = "hpe-vm-essentials-9.0.1-1.qcow2.gz";
  const SSH_HOST = "172.16.3.3";

  const norm = (s) => String(s || "").trim().replace(/\s+/g, " ");
  const ipv4 = (v) => /^\d{1,3}(\.\d{1,3}){3}$/.test(v) && v.split(".").every((n) => Number(n) <= 255);
  const sameSet = (a, b) => a.length === b.length && b.every((x) => a.indexOf(x) >= 0);
  const fieldValue = (id) => (document.getElementById(id) || {}).value || "";

  const ack = (text, hint, label) => ({ text: text, hint: hint, ack: true, label: label || "Continue" });
  const on = (text, ev, test, extra) => Object.assign({ text: text, ev: ev, test: test }, extra);
  const cmd = (text, command, extra) =>
    Object.assign({ text: text, cmd: command, where: "MobaXterm > hypervisor SSH terminal (172.16.3.3)", ev: "command-done", test: (d) => d.text === command }, extra);
  // Installer fields report on focus-out so the learner can type, press Enter and move on.
  const field = (text, name, valid, extra) =>
    on(text, "vm-field", (d) => d.field === name && valid(d.value), Object.assign({
      bad: (d) => d.field === name,
      where: "MobaXterm > Install VME Manager form",
      result: "In Guided Mode, press Tab or click another field after entering the value so the guide can check it."
    }, extra));
  const nonEmpty = (v) => v.trim() !== "";
  const empty = (v) => v === "";

  const PARTS = [
    {
      title: "Mount the ISO and upload files",
      steps: [
        ack(
          "Locate the VM Essentials installation ISO.",
          "The ISO is already downloaded to C:\\HPE in this simulator. No external download is needed.",
          "Done"
        ),
        on("Open the folder containing the installation files.", "explorer-folder", (d) => d.path === "C:\\HPE", {
          where: "Window > File Explorer",
          actions: ["Click the yellow File Explorer icon on the taskbar at the bottom of the window.", "Select This PC in the left pane.", "Open Windows 2022 (C:).", "Double-click the HPE folder."],
          result: "File Explorer shows the contents of C:\\HPE."
        }),
        on("Mount the installation ISO as a DVD drive.", "iso-mounted", null, {
          where: "File Explorer > C:\\HPE",
          actions: ["Double-click HPE_VM_Essentials_SW_image_v9.0.1_0_S5Q83-11083.iso."],
          result: "DVD Drive (E:) appears and contains the installation files."
        }),
        ack("Identify the console installation package.", DEB + " is the Debian package that installs the HPE VM Essentials Console on the hypervisor."),
        ack("Identify the manager VM image.", QCOW + " is the compressed disk image used to create the VM Essentials Manager VM. Leave it compressed; the installer accepts the .gz file."),
        on("Open MobaXterm.", "moba-open", null, {
          where: "Window",
          actions: ["Double-click the MobaXterm desktop icon."],
          result: "The MobaXterm window opens."
        }),
        on("Start a new remote session.", "session-dialog", null, {
          where: "MobaXterm > top toolbar",
          actions: ["Click the Session icon near the upper-left corner."],
          result: "The session-type dialog opens."
        }),
        on("Choose an SSH connection.", "session-type", (d) => d.type === "SSH", {
          strict: true, actions: ["In the session dialog, click SSH."], result: "The SSH connection fields appear."
        }),
        on("Connect to the hypervisor as root.", "ssh-form", (d) => d.host === SSH_HOST && d.user === "root" && d.port === "22", {
          where: "MobaXterm > SSH session settings",
          values: [["Remote host", SSH_HOST], ["Username", "root"]],
          result: "The remote host and username are correct. Wait for the next guided step before clicking OK."
        }),
        on("Connect to the hypervisor.", "ssh-ok", null, {
          actions: ["In the SSH settings dialog, click OK."], result: "The terminal asks for root's password."
        }),
        on("Sign in as root.", "ssh-password", (d) => d.correct, {
          strict: true, values: [["Hypervisor password", "Lab@123456"]],
          after: ["Press Enter in the terminal."],
          note: "Password characters are not displayed while you type."
        }),
        on("Do not save the SSH password.", "save-password", (d) => d.answer === "no", {
          strict: true, actions: ["When MobaXterm asks whether to save the password, click No."],
          result: "The root@manager command prompt and SFTP file browser are available.",
          note: "Practice Mode skips this password-saving prompt automatically."
        }),
        on("Open the file upload dialog.", "upload-open", null, {
          where: "MobaXterm > SSH browser (SFTP), left pane",
          actions: ["Click the upward-pointing Upload arrow in the SFTP toolbar."],
          result: "A local file picker opens. Files will be uploaded to /root on the hypervisor."
        }),
        on("Open the mounted DVD in the upload dialog.", "upload-navigate", (d) => d.location === DVD, {
          actions: ["In the upload file picker, select This PC.", "Open DVD Drive (E:)."],
          result: "The DVD's files appear in the picker."
        }),
        on("Select both installation files.", "upload-select", (d) => sameSet(d.names, [DEB, QCOW]), {
          bad: (d) => d.names.length > 0 && !d.names.every((n) => n === DEB || n === QCOW),
          badOn: { "upload-start": () => true },
          actions: ["Click " + DEB + ".", "Hold Ctrl and click " + QCOW + "."],
          result: "Both files are selected. Do not select any other files."
        }),
        on("Upload the selected files to the hypervisor.", "upload-start", (d) => sameSet(d.names, [DEB, QCOW]), {
          strict: true, actions: ["Click Open in the file picker to begin the upload.", "Wait for the transfer progress to finish before installing the package."],
          result: "The transferred files appear in the SFTP browser under /root.",
          note: "In Practice Mode, a fault may prevent one file from arriving. Check the actual server files."
        }),
        cmd("Refresh the hypervisor's package list.", "apt update -y", {
          result: "The package update finishes and the root command prompt returns."
        }),
        cmd("Upgrade the installed hypervisor packages.", "apt upgrade -y", {
          hint: "If keyboard configuration screens appear, press Enter to keep the highlighted default at each screen. Practice Mode skips these screens.",
          result: "The upgrade finishes and the root command prompt returns."
        })
      ]
    },
    {
      title: "Install the VM Essentials Console",
      steps: [
        ack("Verify that both uploads reached /root.", "In MobaXterm's left SFTP pane, look for " + DEB + " and " + QCOW + ". If either is missing, upload it again.", "Done"),
        cmd("Install the VM Essentials Console package.", "apt install -f /root/hpe-vm_1.0.15-1_amd64.deb", {
          result: "The console package installs successfully and the root prompt returns."
        }),
        cmd(
          "Restart the hypervisor and reconnect.",
          "reboot",
          {
            ev: "session-restart", test: null,
            after: ["Wait for the SSH session to disconnect.", "With the terminal focused, press Shift + R to restart the session after the server is ready.", "If Connection refused appears, wait and press Shift + R again.", "When prompted, sign in again as root with password Lab@123456."],
            result: "The hypervisor accepts SSH connections again.",
            note: "A real reboot can take 2-3 minutes. This lab uses a shorter wait."
          }
        )
      ]
    },
    {
      title: "Install the VM Essentials Manager",
      steps: [
        cmd("Open the VM Essentials Console.", "hpe-vm", { ev: "vm-menu-open", test: null, result: "The HPE VM Essentials Console menu opens." }),
        on("Highlight Install VME Manager.", "vm-menu-nav", (d) => d.index === 4, {
          actions: ["Use the Down Arrow key to move the highlight to Install VME Manager."],
          result: "Install VME Manager is highlighted. Do not press Enter until the next guided step."
        }),
        on("Open the manager installation form.", "vm-installer-open", null, {
          actions: ["With Install VME Manager highlighted, press Enter."], result: "The manager configuration form opens."
        }),
        field("Set the manager IP address.", "ip", ipv4, { values: [["IP Address", "172.16.3.6"]], note: "In Practice Mode, an address conflict may require a different free IP from the scenario's range." }),
        field("Set the manager subnet mask.", "netmask", ipv4, { values: [["Netmask", "255.255.255.0"]] }),
        field("Set the default gateway.", "gateway", ipv4, { values: [["Gateway", "172.16.3.1"]] }),
        field("Set the DNS resolver.", "dns", ipv4, { values: [["DNS Server", "172.16.3.9"]] }),
        field(
          "Clear the existing Appliance URL.",
          "url",
          empty,
          {
            actions: ["Click Appliance URL.", "Select all existing text.", "Press Backspace or Delete to leave the field completely empty."],
            result: "The guide advances to entering the new URL. If the field is already empty, press Backspace once."
          }
        ),
        field("Enter the manager's Appliance URL.", "url", (v) => /^https?:\/\/\S+$/.test(v.trim()), {
          bad: (d) => !d.cleared, values: [["Appliance URL", "https://hpe-vm1.talabs.local"]],
          note: "Use talabs.local, not tablabs.local. This is the temporary manager's fully qualified domain name."
        }),
        field("Set the manager hostname.", "hostname", nonEmpty, { values: [["Hostname", "hpe-vm1"]] }),
        field("Set the manager's guest administrator.", "admin", nonEmpty, { values: [["Admin User", "admin"]], note: "This account is for the manager VM's operating system, not the Web UI master account created later." }),
        field("Set the manager VM's password.", "password", nonEmpty, { values: [["Admin Password", "!HPEstorage2050"]] }),
        field(
          "Confirm the manager VM's password.",
          "confirm",
          (v) => nonEmpty(v) && v === fieldValue("vmeManagerPassword"),
          { values: [["Confirm Password", "!HPEstorage2050"]], note: "The confirmation must match Admin Password exactly, including punctuation and capitalization." }
        ),
        on(
          "Browse for the uploaded manager image.",
          "vm-picker-open", null,
          { actions: ["Move focus to Browse Files beside Image URI using Tab or the arrow keys.", "Press Enter to open the image picker. You can also click Browse Files."], result: "The image file picker opens." }
        ),
        on("Open the hypervisor's /root directory.", "vm-picker-folder", (d) => d.folder === "root", {
          actions: ["In the image picker, move focus to the directory list on the right using Tab.", "Highlight root.", "Press Enter to open root."],
          result: "The file list shows the files uploaded to /root."
        }),
        on(
          "Select the compressed manager disk image.",
          "vm-picker-file",
          (d) => d.file === QCOW,
          { strict: true, actions: ["Use Tab to reach the file list on the left.", "Highlight " + QCOW + ".", "Press Enter to select the image."], result: "The selected path appears in the filename field at the bottom." }
        ),
        on("Confirm the selected image.", "vm-picker-done", null, {
          actions: ["Check that the filename ends in " + QCOW + ".", "Move focus to Open and press Enter, or click Open."],
          result: "The picker closes and Image URI contains the selected /root image path."
        }),
        field("Leave the proxy unset.", "proxy", empty, { values: [["Proxy", "Leave blank"]] }),
        field("Leave the proxy exception list unset.", "noProxy", empty, { values: [["No Proxy List", "Leave blank"]] }),
        field("Choose the Small VM size.", "size", (v) => v === "Small", { values: [["Select VM Size", "Small"]] }),
        field("Choose the management network interface.", "interface", (v) => v === "ens192", {
          values: [["Management Interface", "ens192"]], note: "Press Tab after selecting the interface. The next step will ask you to start the installation."
        }),
        on("Install the manager and wait for completion.", "vm-install-complete", null, {
          actions: ["Review the configuration.", "Select Install.", "Wait for the installation progress to reach the completion screen."],
          result: "HPE VME Manager VM Installed appears.",
          note: "If an error appears, read it and correct the indicated field before retrying. Practice Mode may deliberately introduce an IP conflict."
        }),
        on("Return to the console menu and highlight Exit.", "vm-menu-nav", (d) => d.index === 6, {
          early: false, actions: ["On the installation completion screen, click OK.", "Use the arrow keys in the console menu to highlight Exit."],
          result: "Exit is highlighted. Press Enter to return to the hypervisor command prompt."
        })
      ]
    }
  ];

  window.SimLabsSetup.installationParts = PARTS.slice();
  if (document.documentElement.dataset.labMode !== "guided") return;
  PARTS.push(...window.SimLabsSetup.parts);
  const steps = [];
  PARTS.forEach((part, p) => {
    part.steps.forEach((step, i) => {
      steps.push(Object.assign({ part: p, number: i + 1, count: part.steps.length, optional: !!part.optional }, step));
    });
  });
  const total = steps.length;

  // ── Following the learner ───────────────────────────────────────
  let cur = 0;
  let shown = 0;
  let animating = false;
  let failed = false;
  let actionIndex = 0;
  const progress = window.SimLabsProgress || null;

  function accepts(step, e) {
    if (step.ack) return e.name === "ack";
    if (e.name !== step.ev) return false;
    return step.test ? !!step.test(e) : true;
  }

  function isWrong(step, e) {
    if (step.optional || e.name === "setup-state") return false;
    if (e.name === "ack" || e.name === "command-done") return false;
    if (e.name === "command") {
      if (step.cmd) return e.text !== step.cmd;
      return steps.slice(cur + 1).some((s) => s.cmd);
    }
    if (e.name === step.ev) {
      if (step.strict) return true;
      if (step.bad && step.bad(e)) return true;
    }
    if (step.badOn && step.badOn[e.name]) return !!step.badOn[e.name](e);
    return steps.slice(cur + 1).some((s) => s.early !== false && accepts(s, e));
  }

  function handle(e) {
    if (cur >= total) return;
    if (progress && progress.replaying) return;
    const step = steps[cur];
    if (accepts(step, e)) {
      cur++;
      failed = false;
      if (cur >= total) document.dispatchEvent(new CustomEvent("vme:lab-complete"));
      else if (progress) progress.saveStep(cur);
      pump();
    } else if (isWrong(step, e) && !failed) {
      failed = true;
      render();
    }
  }

  document.addEventListener("vme:track", (event) => {
    const e = event.detail;
    if (e && e.name) handle(e);
  });
  document.addEventListener("vme:open-moba", () => handle({ name: "moba-open" }));

  const sshField = (id) => (document.getElementById(id) || {}).value || "";
  const urlCleared = (target) => {
    if (target.id === "vmeManagerUrl" && target.value === "") handle({ name: "vm-field", field: "url", value: "", cleared: true });
  };
  document.addEventListener("input", (event) => {
    const target = event.target;
    urlCleared(target);
    if (!target.closest || !target.closest(".moba-ssh__basic")) return;
    handle({ name: "ssh-form", host: sshField("mobaSshHost").trim(), user: sshField("mobaSshUser").trim(), port: sshField("mobaSshPort").trim() });
  });
  // Backspace or Delete on an already empty field counts as clearing it.
  document.addEventListener("keydown", (event) => {
    if (event.key === "Backspace" || event.key === "Delete") {
      const target = event.target;
      setTimeout(() => urlCleared(target), 0);
    }
  });

  const FIELD_IDS = {
    vmeManagerIp: "ip",
    vmeManagerNetmask: "netmask",
    vmeManagerGateway: "gateway",
    vmeManagerDns: "dns",
    vmeManagerUrl: "url",
    vmeManagerHostname: "hostname",
    vmeManagerUser: "admin",
    vmeManagerPassword: "password",
    vmeManagerConfirm: "confirm",
    vmeManagerProxy: "proxy",
    vmeManagerNoProxy: "noProxy",
    vmeManagerSize: "size",
    vmeManagerInterface: "interface"
  };
  document.addEventListener("focusout", (event) => {
    const name = FIELD_IDS[event.target.id];
    if (name) handle({ name: "vm-field", field: name, value: event.target.value });
  });

  // ── Panel ───────────────────────────────────────────────────────
  const main = desktop.parentElement;
  main.classList.add("vme-lab--guided");

  const el = (tag, cls, text) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  };

  const panel = el("aside", "vme-guide");
  panel.setAttribute("aria-label", "Guided mode steps");
  const badge = el("span", "vme-guide__badge", "Guided Mode");
  const title = el("h2", "vme-guide__title", "VME Installation and Setup");
  const partEl = el("p", "vme-guide__part");
  const progressEl = el("div", "vme-guide__progress");
  const progressText = el("span");
  const bar = el("div", "vme-guide__bar");
  const fill = document.createElement("i");
  bar.appendChild(fill);
  progressEl.append(progressText, bar);
  const stepHost = el("div");
  stepHost.setAttribute("aria-live", "polite");
  let renderedStep = -1;
  panel.append(badge, title, partEl, progressEl, stepHost);
  main.appendChild(panel);

  window.SimLabsSetup.watchInteractions(desktop, () => {
    if (shown !== cur || cur >= total) return;
    if (actionIndex < window.SimLabsSetup.instructionPages(steps[cur]).length - 1) {
      actionIndex++;
      render();
    }
  });

  function render() {
    const doneCount = Math.min(cur, total);
    progressText.textContent = doneCount + " of " + total + " steps completed";
    fill.style.width = (doneCount / total) * 100 + "%";
    stepHost.textContent = "";

    if (shown >= total) {
      partEl.textContent = "All parts completed";
      const card = el("div", "vme-guide__step is-done");
      card.append(
        el("span", "vme-guide__label", "Lab complete"),
        el("span", "vme-guide__text", "You have installed and configured VM Essentials, its HVM cluster, networks, shared storage, management VM and VMware group.")
      );
      const again = el("button", "submit-btn vme-guide__btn", "Restart lab");
      again.type = "button";
      again.addEventListener("click", () => window.location.reload());
      card.appendChild(again);
      stepHost.appendChild(card);
      panel.scrollTop = 0;
      return;
    }

    const step = steps[shown];
    if (renderedStep !== shown) actionIndex = 0;
    const pages = window.SimLabsSetup.instructionPages(step);
    const lastAction = actionIndex === pages.length - 1;
    const isDone = shown < cur;
    const isError = !isDone && failed;
    partEl.textContent = "Part " + (step.part + 1) + " of " + PARTS.length + ": " + PARTS[step.part].title;

    const card = el("div", "vme-guide__step" + (isDone ? " is-done" : "") + (isError ? " is-error" : ""));
    card.append(
      el("span", "vme-guide__label", "Step " + step.number + " of " + step.count + (isDone ? " \u2713 Completed" : "")),
      el("span", "vme-instruction__caption", "Action " + (actionIndex + 1) + " of " + pages.length),
      window.SimLabsSetup.renderInstruction(pages[actionIndex])
    );
    if (isError) card.appendChild(el("span", "vme-guide__msg", "This step is not complete yet. Follow the actions above and check the values exactly as shown."));
    if (!isDone && lastAction) card.appendChild(el("p", "vme-instruction__advance", step.ack
      ? "Click " + step.label + " below after you finish this step."
      : "This step advances automatically when the required action is detected."));
    if (!isDone && actionIndex > 0) {
      const back = el("button", "submit-btn submit-btn--secondary vme-guide__btn", "Back");
      back.type = "button";
      back.addEventListener("click", () => { actionIndex--; render(); panel.scrollTop = 0; });
      card.appendChild(back);
    }
    if (step.ack && !isDone && lastAction) {
      const button = el("button", "submit-btn vme-guide__btn", step.label);
      button.type = "button";
      button.addEventListener("click", () => handle({ name: "ack" }));
      card.appendChild(button);
    }
    if (step.optional && !isDone) {
      const skip = el("button", "submit-btn submit-btn--secondary vme-guide__btn", "Skip optional section");
      skip.type = "button";
      skip.addEventListener("click", () => {
        while (cur < total && steps[cur].part === step.part) cur++;
        shown = cur;
        failed = false;
        if (progress) progress.saveStep(cur);
        render();
      });
      card.appendChild(skip);
    }
    stepHost.appendChild(card);
    if (renderedStep !== shown) {
      panel.scrollTop = 0;
      renderedStep = shown;
    }
  }

  // Completed steps stay green for a moment before the next one appears.
  function pump() {
    if (animating) {
      render();
      return;
    }
    if (shown >= cur) {
      render();
      return;
    }
    animating = true;
    render();
    setTimeout(() => {
      animating = false;
      shown++;
      pump();
    }, DONE_MS);
  }

  // ── Resume from saved progress ──────────────────────────────────
  function offerResume(saved) {
    const step = steps[saved];
    const overlay = el("div", "overlay show");
    const modal = el("div", "modal");
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "resumeTitle");
    const content = el("div", "modal-content");
    const heading = el("h2", "modal__title", "Continue where you left off?");
    heading.id = "resumeTitle";
    const intro = el(
      "p",
      "modal__intro",
      "You completed " + saved + " of " + total + " steps. Next: Part " + (step.part + 1) + ", step " + step.number + " of " + step.count + "."
    );
    const note = el("p", "modal__intro", "Continue replays your earlier actions, so the windows, folders and terminal output you had open are restored.");
    const resume = el("button", "submit-btn", "Continue from saved progress");
    resume.type = "button";
    const restart = el("button", "submit-btn submit-btn--secondary", "Start new");
    restart.type = "button";

    resume.addEventListener("click", () => {
      overlay.remove();
      if (cur !== 0) return;
      cur = shown = saved;
      failed = false;
      render();
      progress.loadActions().then((list) => progress.replay(list));
    });
    restart.addEventListener("click", () => {
      overlay.remove();
      progress.clearStep();
      progress.begin();
    });

    content.append(heading, intro, note, resume, restart);
    modal.appendChild(content);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    resume.focus();
  }

  render();

  if (progress) {
    progress.ready.then(() => {
      const saved = progress.loadStep();
      if (cur === 0 && saved > 0 && saved < total) offerResume(saved);
      else progress.begin();
    });
  }
})();
