// Practice Mode for the VME Installation and Setup lab.
// Shows a scenario and a timer, injects one random fault, and scores the diagnosis, fix, efficiency and hint use.
// The attempt is saved in this browser, so a reload resumes it. Reset clears it and starts a new variant.
(function () {
  "use strict";

  const desktop = document.getElementById("vmeDesktop");
  if (!desktop || document.documentElement.dataset.labMode !== "practice") return;

  const LAB_ID = "vme-installation-setup";
  const STORAGE_KEY = "vme.practice.v2." + LAB_ID;
  const DEB_NAME = "hpe-vm_1.0.15-1_amd64.deb";
  const CONFLICT_IP = "172.16.3.6";
  const TARGET_MS = 15 * 60 * 1000;
  const LIMIT_MS = 30 * 60 * 1000;
  const MAX_TIMELINE = 60;
  const DIAGNOSTIC = /^(ls|cat|df|du|ping|ip|hostname|nslookup|dig|tail|grep|find)(\s|$)/;
  const GROUPS = ["Diagnosis", "Resolution", "Efficiency", "Hints"];

  const CAUSES = [
    { id: "deb-missing", label: "The Debian package did not reach the server" },
    { id: "ip-conflict", label: "The management IP address is already in use" },
    { id: "iso-unmounted", label: "The ISO is not mounted in the DVD drive" },
    { id: "ssh-auth", label: "The SSH password is wrong" },
    { id: "disk-full", label: "The server is out of disk space" }
  ];

  const FAULTS = {
    "deb-missing": {
      check: "Package on server",
      keywords: ["deb", "package", "upload", "sftp", "/root", "missing"],
      explanation: "The .deb package was not copied to /root during the upload, so apt could not install it.",
      fix: "Upload hpe-vm_1.0.15-1_amd64.deb again from DVD Drive (E:), then run the apt install command again.",
      hints: [
        { text: "Check what is actually in /root on the server before you run the install again.", penalty: 3 },
        { text: "The Debian package never arrived on the server. Upload it again from DVD Drive (E:).", penalty: 5 }
      ],
      ideal: [
        "Check which files reached /root (ls /root or the SSH browser).",
        "Upload hpe-vm_1.0.15-1_amd64.deb again from DVD Drive (E:).",
        "Run apt install -f /root/hpe-vm_1.0.15-1_amd64.deb.",
        "Enter the VME Manager values and install."
      ]
    },
    "ip-conflict": {
      check: "Management IP address",
      keywords: ["ip", "address", "conflict", "in use", "duplicate", "172.16.3"],
      explanation: "Address " + CONFLICT_IP + " is already used by another host on the management network, so the installer refused it.",
      fix: "Enter a free address from the management range (172.16.3.7 to 172.16.3.20) and run the installer again.",
      hints: [
        { text: "Read the installer message. The problem is the address you entered, not the package.", penalty: 3 },
        { text: "Choose a different free address in the management range and install again.", penalty: 5 }
      ],
      ideal: [
        "Read the installer error message.",
        "Choose a free address from 172.16.3.7 to 172.16.3.20.",
        "Keep the other values from the brief and install."
      ]
    }
  };

  // ── Saved attempt ──────────────────────────────────────────────
  function loadSaved() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return saved && FAULTS[saved.faultId] && saved.state ? saved : null;
    } catch (e) {
      return null;
    }
  }

  const saved = loadSaved();
  // A new variant is picked only when there is no saved attempt. Reload keeps the same fault.
  let faultId = saved ? saved.faultId : (Math.random() < 0.5 ? "deb-missing" : "ip-conflict");
  const fault = () => FAULTS[faultId];

  const state = {
    started: 0,
    finished: false,
    finishedAt: 0,
    timerId: 0,
    timeline: [],
    commands: 0,
    diagnostics: 0,
    errors: 0,
    installerOpens: 0,
    installed: false,
    setupComplete: false,
    hintsShown: 0,
    diagnosis: null,
    dropped: false,
    debDelivered: false,
    conflictSeen: false
  };

  function persist() {
    const snapshot = Object.assign({}, state, { timerId: 0 });
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ faultId: faultId, state: snapshot }));
    } catch (e) {
      // Storage unavailable (private mode or full); the attempt still works until the page is reloaded.
    }
  }

  function clearSaved() {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      // Nothing to clear if storage is unavailable.
    }
  }

  const pad = (n) => String(n).padStart(2, "0");
  const clock = (ms) => {
    const s = Math.floor(ms / 1000);
    return pad(Math.floor(s / 60)) + ":" + pad(s % 60);
  };
  const elapsed = () => {
    if (!state.started) return 0;
    return (state.finished ? state.finishedAt : Date.now()) - state.started;
  };
  const hintPenalty = () => fault().hints.slice(0, state.hintsShown).reduce((sum, hint) => sum + hint.penalty, 0);

  // ── Hooks used by the simulator (vme-moba.js) ──────────────────
  // Silently drops the first DEB upload, so the package is missing on the server.
  // Later uploads of the same package succeed, which is recorded as the package being delivered.
  function dropUpload(name) {
    if (faultId !== "deb-missing" || name !== DEB_NAME) return false;
    if (!state.dropped) {
      state.dropped = true;
      updateControls();
      return true;
    }
    if (!state.debDelivered) {
      state.debDelivered = true;
      updateControls();
    }
    return false;
  }

  // Returns an installer error message while the IP conflict fault is active.
  function checkInstall(formData) {
    if (faultId === "ip-conflict" && String(formData.get("ip") || "").trim() === CONFLICT_IP) {
      state.conflictSeen = true;
      updateControls();
      return "Address " + CONFLICT_IP + " is already in use on the management network. Choose a different IP address.";
    }
    return null;
  }

  window.SimLabsPractice = { dropUpload: dropUpload, checkInstall: checkInstall };

  // ── Tracking ───────────────────────────────────────────────────
  function describe(e) {
    switch (e.name) {
      case "command": return "Ran: " + e.text;
      case "upload-open": return "Opened the DVD upload dialog";
      case "upload-start": return "Uploaded: " + (e.names || []).join(", ");
      case "error": return "Error (" + e.source + "): " + e.message;
      case "vm-installer-open": return "Opened the VME Manager installer";
      case "vm-install-complete": return "VME Manager installed";
      case "hpe-vm-cli-install": return "Installed hpe-vm from the command line";
      case "vm-menu-open": return "Opened the hpe-vm menu";
      case "session-restart": return "Restarted the server";
      case "ssh-ok": return "Connected to " + e.host;
      case "ssh-password": return e.correct ? "Entered the SSH password" : "Entered a wrong SSH password";
      case "iso-mounted": return "Mounted the ISO";
      case "explorer-folder": return "Opened " + (e.path || "a folder");
      default: return "";
    }
  }

  function addTimeline(label) {
    state.timeline.push({ at: elapsed(), label: label });
  }

  document.addEventListener("vme:track", (event) => {
    const e = event.detail;
    if (!e || !state.started || state.finished) return;
    if (e.name === "command") {
      state.commands++;
      if (DIAGNOSTIC.test(e.text || "")) state.diagnostics++;
    }
    if (e.name === "upload-open") state.diagnostics++;
    if (e.name === "error") state.errors++;
    if (e.name === "vm-installer-open") state.installerOpens++;
    if (e.name === "vm-install-complete") {
      state.installed = true;
      updateControls();
    }
    if (e.name === "setup-state") updateControls();
    const label = describe(e);
    if (label) addTimeline(label);
    persist();
  });

  // ── Panel ──────────────────────────────────────────────────────
  const main = desktop.parentElement;
  main.classList.add("vme-lab--practice");

  const el = (tag, cls, text) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  };
  const section = (heading) => {
    const sec = el("section", "vme-practice__section");
    sec.appendChild(el("h3", "vme-practice__heading", heading));
    return sec;
  };

  const panel = el("aside", "vme-guide vme-practice");
  panel.setAttribute("aria-label", "Practice mode scenario");
  const badge = el("span", "vme-guide__badge", "Practice Mode");
  const title = el("h2", "vme-guide__title", "VME Installation and Setup");
  const timerEl = el("p", "vme-practice__timer");
  const body = el("div", "vme-practice__body");
  panel.append(badge, title, timerEl, body);
  main.appendChild(panel);

  // Scenario
  const briefSec = section("Scenario");
  briefSec.append(
    el("p", "vme-practice__text", "Install the HPE VM Essentials Console and Manager on this jump host from the DVD files. A fault has been introduced somewhere in the process."),
    window.SimLabsSetup.renderInstruction({
      text: "Lab connection details",
      values: [["Hypervisor SSH host", "172.16.3.3"], ["Hypervisor SSH username", "root"], ["Hypervisor SSH password", "Lab@123456"], ["SSH port", "22"], ["Manager IP range", "172.16.3.6 to 172.16.3.20"], ["Netmask", "255.255.255.0"], ["Gateway", "172.16.3.1"], ["DNS", "172.16.3.9"], ["Manager hostname", "hpe-vm1"], ["Application URL", "https://hpe-vm1.talabs.local"], ["Manager guest SSH username", "admin"], ["Manager guest SSH password", "!HPEstorage2050"]],
      note: "The master Web UI account is created later in the setup wizard. Keep it separate from these SSH accounts."
    }),
    el("p", "vme-practice__text", "Find the root cause, record your diagnosis, fix it and finish the manager installation. Then complete manager setup, HVM networking/storage, managed-VM operations, Node-03 and the VMware group. Optional KVM recovery is not scored. The setup reference advances one action at a time as you interact with the lab window.")
  );
  const startBtn = el("button", "submit-btn vme-guide__btn", "Start practice");
  startBtn.type = "button";
  startBtn.addEventListener("click", start);
  briefSec.appendChild(startBtn);

  // Fault status: one row for the check that the injected fault breaks. Names the check, not the root cause.
  const statusSec = section("Fault status");
  const statusRow = el("div", "vme-practice__fault");
  statusRow.setAttribute("aria-live", "polite");
  const statusTop = el("div", "vme-practice__row-top");
  const statusLabel = el("span", "vme-practice__row-label", fault().check);
  const statusState = el("span", "vme-practice__fault-state");
  statusTop.append(statusLabel, statusState);
  const statusDetail = el("p", "vme-practice__note");
  statusRow.append(statusTop, statusDetail);
  statusSec.appendChild(statusRow);

  // Hints
  const hintSec = section("Hints");
  const hintList = el("ol", "vme-practice__list");
  const hintBtn = el("button", "submit-btn--secondary vme-guide__btn", "Show hint");
  hintBtn.type = "button";
  hintBtn.addEventListener("click", showHint);
  const hintNote = el("p", "vme-practice__note");
  hintSec.append(hintList, hintBtn, hintNote);

  // Diagnosis
  const diagSec = section("Diagnosis");
  const form = el("form", "vme-practice__form");
  form.noValidate = true;
  const causeGroup = el("fieldset", "vme-practice__causes");
  causeGroup.appendChild(el("legend", "vme-practice__legend", "Root cause"));
  CAUSES.forEach((cause) => {
    const label = el("label", "vme-practice__option");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = "practiceCause";
    input.value = cause.id;
    label.append(input, " " + cause.label);
    causeGroup.appendChild(label);
  });
  const notesLabel = el("label", "vme-practice__label", "Notes: what you checked and why");
  notesLabel.htmlFor = "practiceNotes";
  const notes = document.createElement("textarea");
  notes.id = "practiceNotes";
  notes.className = "vme-practice__textarea";
  notes.rows = 4;
  notes.maxLength = 500;
  const diagBtn = el("button", "submit-btn vme-guide__btn", "Submit diagnosis");
  diagBtn.type = "submit";
  const diagStatus = el("p", "vme-practice__note");
  diagStatus.setAttribute("aria-live", "polite");
  form.append(causeGroup, notesLabel, notes, diagBtn, diagStatus);
  form.addEventListener("submit", submitDiagnosis);
  diagSec.appendChild(form);

  // Finish
  const finishSec = section("Finish");
  const finishBtn = el("button", "submit-btn vme-guide__btn", "Finish and get score");
  finishBtn.type = "button";
  finishBtn.addEventListener("click", finish);
  const finishNote = el("p", "vme-practice__note");
  finishSec.append(finishBtn, finishNote);

  // Reset
  const resetSec = section("Attempt");
  const resetBtn = el("button", "submit-btn--secondary vme-guide__btn", "Reset scenario");
  resetBtn.type = "button";
  resetBtn.addEventListener("click", resetScenario);
  resetSec.append(
    el("p", "vme-practice__note", "Clears the timer, hints, diagnosis and timeline, then starts a new fault variant. Your score history is kept."),
    resetBtn
  );

  const referenceSec = section("Setup reference");
  const referenceParts = window.SimLabsSetup.installationParts.concat(window.SimLabsSetup.parts);
  const referenceSelect = el("select", "vme-instruction__select");
  referenceSelect.setAttribute("aria-label", "Reference section");
  const referencePages = [];
  referenceParts.forEach((part, partIndex) => {
    const option = el("option", "", part.title);
    option.value = String(referencePages.length);
    referenceSelect.appendChild(option);
    part.steps.forEach((step) => {
      window.SimLabsSetup.instructionPages(step).forEach((instruction) => {
        referencePages.push({ partIndex, instruction });
      });
    });
  });
  let referenceIndex = 0;
  const referencePosition = el("p", "vme-instruction__caption");
  const referenceHost = el("div", "vme-guide__step");
  referenceHost.setAttribute("aria-live", "polite");
  const referenceControls = el("div", "vme-instruction__controls");
  const referenceBack = el("button", "submit-btn submit-btn--secondary vme-guide__btn", "Back");
  referenceBack.type = "button";
  function renderReference() {
    const current = referencePages[referenceIndex];
    referenceSelect.selectedIndex = current.partIndex;
    referencePosition.textContent = "Action " + (referenceIndex + 1) + " of " + referencePages.length;
    referenceHost.replaceChildren(window.SimLabsSetup.renderInstruction(current.instruction));
    referenceBack.disabled = referenceIndex === 0;
  }
  referenceSelect.addEventListener("change", () => {
    referenceIndex = Number(referenceSelect.value);
    renderReference();
  });
  referenceBack.addEventListener("click", () => { referenceIndex--; renderReference(); });
  referenceControls.appendChild(referenceBack);
  referenceSec.append(referenceSelect, referencePosition, referenceHost, referenceControls);
  window.SimLabsSetup.watchInteractions(desktop, () => {
    if (referenceIndex < referencePages.length - 1) {
      referenceIndex++;
      renderReference();
    }
  });
  renderReference();
  body.append(briefSec, statusSec, referenceSec, hintSec, diagSec, finishSec, resetSec);

  function start() {
    if (state.started) return;
    state.started = Date.now();
    addTimeline("Practice started");
    state.timerId = setInterval(tick, 1000);
    startBtn.disabled = true;
    tick();
    updateControls();
  }

  function tick() {
    timerEl.textContent = "Elapsed " + clock(elapsed()) + " | Target " + clock(TARGET_MS);
  }

  // The fault check is "broken" once the symptom has appeared and "fixed" once the install succeeds.
  function faultStatus() {
    if (faultId === "deb-missing") {
      if (!state.dropped) return { text: "Not checked yet", tone: "open", detail: "Nothing has been uploaded yet." };
      if (!state.debDelivered) return { text: "Broken", tone: "broken", detail: "The package is not on the server. Upload it again from DVD Drive (E:)." };
      return { text: "Fixed", tone: "fixed", detail: "The package was uploaded again." };
    }
    if (state.installed) return { text: "Fixed", tone: "fixed", detail: "VME Manager installed with a free address." };
    if (state.conflictSeen) return { text: "Broken", tone: "broken", detail: "The installer rejected the management IP address." };
    return { text: "Not checked yet", tone: "open", detail: "The installer has not rejected any values yet." };
  }

  function nextHintCost() {
    const next = fault().hints[state.hintsShown];
    return next ? next.penalty : 0;
  }

  function updateControls() {
    const live = state.started && !state.finished;
    Array.from(form.elements).forEach((control) => { control.disabled = !live; });
    const total = fault().hints.length;
    const hintsLeft = state.hintsShown < total;
    hintBtn.disabled = !live || !hintsLeft;
    hintBtn.textContent = hintsLeft
      ? "Show hint " + (state.hintsShown + 1) + " of " + total + " (costs " + nextHintCost() + " points)"
      : "All hints shown";
    hintNote.textContent = "Hints used so far cost " + hintPenalty() + " points. The next hint costs " +
      (hintsLeft ? nextHintCost() : 0) + " points.";

    const status = faultStatus();
    statusRow.dataset.tone = status.tone;
    statusState.textContent = status.text;
    statusDetail.textContent = status.detail;

    if (state.finished) {
      finishBtn.disabled = true;
      finishNote.textContent = "Practice finished.";
      persist();
      return;
    }
    const remaining = window.SimLabsSetup.remaining();
    const ready = state.started && state.installed && state.diagnosis && remaining.length === 0;
    finishBtn.disabled = !ready;
    if (!state.started) finishNote.textContent = "Start the practice to begin.";
    else if (!state.installed) finishNote.textContent = "Finish installing the VM Essentials Manager from the .qcow2.gz image; installing only the console package is not sufficient.";
    else if (!state.diagnosis) finishNote.textContent = "Available after you submit a diagnosis.";
    else if (remaining.length) finishNote.textContent = remaining.length + " setup checks remaining. Next: " + remaining[0].text;
    else finishNote.textContent = "Ready. You can still change the diagnosis before you finish.";
    persist();
  }

  function showHint() {
    const hints = fault().hints;
    if (state.hintsShown >= hints.length) return;
    const hint = hints[state.hintsShown];
    state.hintsShown++;
    hintList.appendChild(el("li", "", hint.text + " (-" + hint.penalty + " points)"));
    addTimeline("Hint " + state.hintsShown + " shown");
    updateControls();
  }

  function submitDiagnosis(event) {
    event.preventDefault();
    const checked = form.querySelector('input[name="practiceCause"]:checked');
    if (!checked) {
      diagStatus.textContent = "Choose a root cause first.";
      return;
    }
    state.diagnosis = { cause: checked.value, notes: notes.value.trim() };
    diagStatus.textContent = "Diagnosis recorded. You can change it until you finish.";
    addTimeline("Diagnosis submitted: " + CAUSES.find((c) => c.id === checked.value).label);
    updateControls();
  }

  function finish() {
    if (finishBtn.disabled || state.finished) return;
    state.setupComplete = window.SimLabsSetup.remaining().length === 0;
    state.finished = true;
    state.finishedAt = Date.now();
    clearInterval(state.timerId);
    tick();
    updateControls();
    document.dispatchEvent(new CustomEvent("vme:lab-complete"));
    const result = score();
    renderScorecard(result);
    saveScore(result);
  }

  // ── Saved scores ───────────────────────────────────────────────
  const scoresUrl = "/api/labs/" + encodeURIComponent(LAB_ID) + "/scores";

  function saveScore(result) {
    const api = window.SimLabsApi;
    if (!api) return;
    setSaveStatus("Saving your score...");
    const payload = {
      total: result.total,
      elapsedMs: elapsed(),
      fault: faultId,
      checks: result.checks.map((c) => ({ group: c.group, label: c.label, points: c.points, max: c.max }))
    };
    api.request(scoresUrl, { method: "POST", body: payload }).then((saved) => {
      if (!saved.ok) {
        setSaveStatus("Your score could not be saved. Sign in and try again later.");
        return;
      }
      setSaveStatus("Score saved to your account.");
      return loadHistory();
    });
  }

  function setSaveStatus(text) {
    const status = document.getElementById("vmePracticeSaveStatus");
    if (status) status.textContent = text;
  }

  function loadHistory() {
    return window.SimLabsApi.request(scoresUrl).then((result) => {
      const holder = document.getElementById("vmePracticeHistory");
      if (!holder || !result.ok || !Array.isArray(result.data.scores) || !result.data.scores.length) return;
      holder.textContent = "";
      holder.appendChild(el("p", "vme-practice__note", "Best score: " + result.data.best + " / 100"));
      const list = el("ol", "vme-practice__list");
      result.data.scores.forEach((s) => {
        const when = new Date(s.createdAt).toLocaleString();
        list.appendChild(el("li", "", s.total + " / 100 (" + s.grade + "), " + clock(s.elapsedMs) + ", " + when));
      });
      holder.appendChild(list);
    });
  }

  // ── Scoring ────────────────────────────────────────────────────
  function grade(total) {
    if (total >= 90) return "Expert";
    if (total >= 75) return "Proficient";
    if (total >= 50) return "Developing";
    return "Needs practice";
  }

  function score() {
    const d = state.diagnosis;
    const checks = [];
    const add = (group, label, points, max, detail) => checks.push({ group: group, label: label, points: points, max: max, detail: detail });

    add("Diagnosis", "Correct root cause", d && d.cause === faultId ? 25 : 0, 25,
      d ? CAUSES.find((c) => c.id === d.cause).label : "No diagnosis submitted");
    add("Diagnosis", "Evidence checked before fixing", state.diagnostics > 0 ? 10 : 0, 10,
      state.diagnostics + " diagnostic check(s) (commands and upload dialog)");
    const noteHit = !!(d && fault().keywords.some((k) => d.notes.toLowerCase().indexOf(k) !== -1));
    add("Diagnosis", "Notes describe the problem", noteHit ? 5 : 0, 5,
      noteHit ? "Notes match the fault" : "Notes do not describe the fault");

    add("Resolution", "Installation completed", state.installed ? 15 : 0, 15,
      state.installed ? "VME Manager installed" : "Install not completed");
    const configured = state.finished ? state.setupComplete : window.SimLabsSetup.remaining().length === 0;
    add("Resolution", "Manager and cluster configured", configured ? 15 : 0, 15,
      configured ? "All mandatory setup checks passed" : "Mandatory setup is incomplete");
    add("Resolution", "Fix confirmed by a successful retry", state.installed && state.errors > 0 ? 10 : 0, 10,
      state.errors > 0 ? "Installed after " + state.errors + " error(s)" : "No failed attempt was recorded");

    const total = elapsed();
    const timePts = total <= TARGET_MS ? 8 : total >= LIMIT_MS ? 0 : Math.round(8 * (LIMIT_MS - total) / (LIMIT_MS - TARGET_MS));
    add("Efficiency", "Time to finish", timePts, 8, clock(total) + " (target " + clock(TARGET_MS) + ")");
    add("Efficiency", "Errors during the lab", Math.max(0, 8 - 2 * state.errors), 8, state.errors + " error(s)");
    const restarts = Math.max(0, state.installerOpens - 1);
    add("Efficiency", "No unnecessary restarts", Math.max(0, 4 - 2 * restarts), 4,
      state.installerOpens + " installer opening(s)");

    add("Hints", "Hint penalty", -hintPenalty(), 0, state.hintsShown + " hint(s) used");

    const sum = checks.reduce((acc, c) => acc + c.points, 0);
    const final = Math.max(0, Math.min(100, Math.round(sum)));
    return { checks: checks, total: final, grade: grade(final) };
  }

  // ── Scorecard ──────────────────────────────────────────────────
  function renderScorecard(result) {
    body.textContent = "";
    const head = el("div", "vme-practice__score");
    head.append(
      el("span", "vme-practice__total", result.total + " / 100"),
      el("span", "vme-guide__badge vme-practice__grade", result.grade)
    );
    body.appendChild(head);
    body.appendChild(el("p", "vme-practice__note", "Commands run: " + state.commands + ". Errors: " + state.errors + ". Hints used: " + state.hintsShown + ". Time: " + clock(elapsed()) + "."));

    GROUPS.forEach((group) => {
      const rows = result.checks.filter((c) => c.group === group);
      if (!rows.length) return;
      const sec = section(group);
      rows.forEach((c) => {
        const row = el("div", "vme-practice__row");
        const top = el("div", "vme-practice__row-top");
        top.append(
          el("span", "vme-practice__row-label", c.label),
          el("span", "vme-practice__row-points", c.max ? c.points + " / " + c.max : String(c.points))
        );
        row.append(top, el("p", "vme-practice__note", c.detail));
        sec.appendChild(row);
      });
      body.appendChild(sec);
    });

    const review = section("What to review");
    const list = el("ul", "vme-practice__list");
    const d = state.diagnosis;
    if (!d || d.cause !== faultId) list.appendChild(el("li", "", "Root cause: " + fault().explanation));
    if (state.diagnostics === 0) list.appendChild(el("li", "", "Check the server and the installer message before you change settings."));
    list.appendChild(el("li", "", "Fix: " + fault().fix));
    review.appendChild(list);
    review.appendChild(el("p", "vme-practice__note", "Ideal path:"));
    const ideal = el("ol", "vme-practice__list");
    fault().ideal.forEach((step) => ideal.appendChild(el("li", "", step)));
    review.appendChild(ideal);
    const link = el("a", "vme-practice__link", "Work through this lab in Guided Mode");
    link.href = window.location.pathname + "?mode=guided";
    review.appendChild(link);
    body.appendChild(review);

    const timeline = section("Timeline");
    const events = el("ol", "vme-practice__timeline");
    state.timeline.slice(0, MAX_TIMELINE).forEach((entry) => {
      events.appendChild(el("li", "", clock(entry.at) + "  " + entry.label));
    });
    timeline.appendChild(events);
    if (state.timeline.length > MAX_TIMELINE) {
      timeline.appendChild(el("p", "vme-practice__note", (state.timeline.length - MAX_TIMELINE) + " more event(s) not shown."));
    }
    body.appendChild(timeline);

    const saved = section("Your scores");
    const saveStatus = el("p", "vme-practice__note");
    saveStatus.id = "vmePracticeSaveStatus";
    const history = el("div", "");
    history.id = "vmePracticeHistory";
    saved.append(saveStatus, history);
    body.appendChild(saved);

    const again = el("button", "submit-btn vme-guide__btn", "Try another variant");
    again.type = "button";
    again.addEventListener("click", resetScenario);
    body.appendChild(again);
    panel.scrollTop = 0;
  }

  function resetScenario() {
    if (state.started && !state.finished && !window.confirm("Reset this scenario? Your timer, hints, diagnosis and timeline will be cleared.")) return;
    document.dispatchEvent(new CustomEvent("vme:setup-reset"));
    clearSaved();
    window.location.reload();
  }

  // Rebuilds the saved attempt after a reload. The simulated server is in memory only, so the
  // package upload and the install are not restored; the learner must do them again.
  function restoreAttempt(record) {
    Object.keys(state).forEach((key) => {
      if (key !== "timerId" && Object.prototype.hasOwnProperty.call(record.state, key)) state[key] = record.state[key];
    });
    state.timerId = 0;
    fault().hints.slice(0, state.hintsShown).forEach((hint) => {
      hintList.appendChild(el("li", "", hint.text + " (-" + hint.penalty + " points)"));
    });
    if (state.diagnosis) {
      const radio = form.querySelector('input[name="practiceCause"][value="' + state.diagnosis.cause + '"]');
      if (radio) radio.checked = true;
      notes.value = state.diagnosis.notes || "";
      diagStatus.textContent = "Diagnosis recorded. You can change it until you finish.";
    }
    if (state.finished) {
      startBtn.disabled = true;
      renderScorecard(score());
      if (window.SimLabsApi) loadHistory();
      return;
    }
    if (state.started) {
      startBtn.disabled = true;
      state.timerId = setInterval(tick, 1000);
      state.installed = false;
      state.debDelivered = false;
      addTimeline("Page reloaded. The simulated server was reset, so upload the package and install again.");
    }
  }

  if (saved) restoreAttempt(saved);
  tick();
  updateControls();
})();
