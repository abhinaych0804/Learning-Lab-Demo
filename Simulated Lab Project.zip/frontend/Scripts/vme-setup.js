(function () {
  "use strict";

  const note = (text, details) => Object.assign({ text: text, ack: true, label: "Continue" }, details);
  const task = (key, text, details) => Object.assign({ key: key, text: text, ev: "setup-state", test: (e) => check(key, e.snapshot) }, details);
  const parts = [
    {
      title: "Optional: KVM operations and network checks",
      optional: true,
      steps: [
        note("Check the manager VM and enable automatic startup.", {
          where: "MobaXterm > hypervisor SSH session (172.16.3.3)",
          actions: ["If the hpe-vm menu is still open, highlight Exit.", "Press Enter to leave the menu if needed.", "Click the terminal."],
          commands: [
            ["List all VMs and their states", "virsh list --all"],
            ["List running VMs configured to start automatically", "virsh list --autostart"],
            ["List running VMs without automatic startup", "virsh list --no-autostart"],
            ["Enable automatic startup for the manager", "virsh autostart hpe-vm1"]
          ],
          result: "hpe-vm1 is running and is marked as autostarted.",
          note: "In Guided Mode, use Skip optional section if you do not want to practice these checks."
        }),
        note("Open an SSH session to the manager VM.", {
          where: "MobaXterm > Session > SSH",
          actions: ["Click Session in the toolbar.", "Select SSH."],
          values: [["Remote host", "172.16.3.6"], ["Username", "admin"], ["Port", "22"]],
          after: ["Click OK.", "Accept a connectivity warning if one appears.", "Enter the manager VM password from the installer. Do not use the hypervisor root password.", "Press Enter."],
          result: "A command prompt for admin on hpe-vm1 appears.",
          note: "In Practice Mode, use your replacement management IP if you resolved an address conflict. Use the username and password you entered during manager installation."
        }),
        note("Verify that the manager can resolve the vCenter name.", {
          where: "MobaXterm > manager SSH session",
          actions: ["Click the terminal."],
          commands: [["Look up the vCenter server", "nslookup vcenter-01.talabs.local"]],
          after: ["Check that the output names DNS server 172.16.3.9 and returns an address for vCenter.", "Before running any virsh commands, reconnect to the hypervisor at 172.16.3.3 as root."],
          result: "The lookup succeeds without a timeout or NXDOMAIN error.",
          note: "vcenter.talabs.local is also supported as an alias in this lab."
        })
      ]
    },
    {
      title: "Optional: recover a failed KVM deployment",
      optional: true,
      steps: [
        note("Identify the disposable VM used for recovery practice.", {
          where: "MobaXterm > hypervisor SSH session (172.16.3.3), signed in as root",
          actions: ["Use this section only to practice recovering a failed deployment."],
          commands: [["List all VMs", "virsh list --all"]],
          result: "Locate the disposable failed-vm in the list. The working hpe-vm1 manager is also listed.",
          note: "Do not shut down or delete hpe-vm1. Recovery exercises use failed-vm only and affect the simulator, not a real hypervisor."
        }),
        note("Shut down and remove the failed VM definition.", {
          where: "MobaXterm > hypervisor SSH session",
          commands: [
            ["1. Request a shutdown", "virsh shutdown failed-vm"],
            ["2. Confirm failed-vm is shut off", "virsh list --all"],
            ["3. Remove its VM definition", "virsh undefine failed-vm"],
            ["4. Confirm failed-vm no longer appears", "virsh list --all"]
          ],
          result: "failed-vm is removed from the VM list; its disk still exists.",
          note: "virsh destroy failed-vm forces a power-off; it does not delete the VM. Use it only if shutdown fails. It reports an error if the VM is already off."
        }),
        note("Remove only the failed VM's leftover disk.", {
          where: "MobaXterm > hypervisor SSH session",
          actions: ["First confirm failed-vm no longer appears in virsh list --all."],
          commands: [
            ["Inspect the disk folder", "ll /var/morpheus/kvm/local"],
            ["Delete only the failed deployment's disk", "rm /var/morpheus/kvm/local/failed-vm.qcow2"],
            ["Verify removal", "ll /var/morpheus/kvm/local"]
          ],
          result: "failed-vm.qcow2 is gone; the working manager disk remains.",
          note: "Do not use a *.qcow2 wildcard or delete unrelated files. A wildcard can remove disks belonging to other VMs."
        })
      ]
    },
    {
      title: "Initial settings and manager login",
      steps: [
        note("Open the manager's first-time setup page.", {
          where: "Window > Google Chrome",
          actions: [
            "Click Google Chrome on the taskbar at the bottom of the window, or double-click its desktop icon.",
            "In Chrome's bookmarks bar, click HPE VM Temp.",
            "If Your connection is not private appears, click Advanced.",
            "Click Proceed to hpe-vm1.talabs.local (unsafe).",
            "If Morpheus is Loading appears, wait. The page refreshes automatically."
          ],
          result: "The setup wizard opens at Create Master Tenant.",
          note: "Accept this certificate warning only for the simulated lab appliance. If a login page appears instead, choose Don't have credentials? Set up a new lab to repeat setup. The domain is talabs.local."
        }),
        task("appliance", "Create the master account and configure the appliance.", {
          where: "Chrome > manager setup wizard",
          actions: [
            "In Create Master Tenant, enter an account name of your choice.",
            "Click Next to open Create Master User.",
            "Enter your first name.",
            "Enter your last name.",
            "Enter a master username of your choice.",
            "Enter a valid email address.",
            "Enter a lab-only password of at least 8 characters.",
            "Enter the same password in Confirm Password.",
            "Click Next to open Initial Setup."
          ],
          values: [["Appliance Name", "HPE-VM1"], ["Appliance URL", "https://hpe-vm1.talabs.local/"], ["Enable Backups", "Off (unchecked)"], ["Enable Monitoring", "On (checked)"], ["Enable Logs", "On (checked)"]],
          after: ["Click Next to open License.", "Leave the optional License Key blank.", "Click Next.", "Click Complete Setup.", "Wait for the login page."],
          result: "The login page appears. Guided Mode advances automatically when setup is saved.",
          note: "Remember the master username and password: you will use them to log in to the Web UI. These are separate from the SSH credentials."
        }),
        task("login", "Log in to the manager Web UI.", {
          where: "Chrome > manager login page",
          actions: ["Enter the master username you created in the setup wizard.", "Enter your master password.", "Click Log In.", "Wait for the dashboard."],
          result: "The dashboard shows the Operations, Infrastructure and Administration menus.",
          note: "To reopen the login page, open Chrome and click the HPE VM Essentials bookmark. Use your new Web UI account, not the hypervisor root account."
        })
      ]
    },
    {
      title: "General configuration settings",
      steps: [
        task("appliance-review", "Review the appliance settings without changing them.", {
          where: "Administration > Settings > Appliance",
          actions: ["Open Administration.", "Select Settings. The Appliance tab is selected by default.", "Locate Cloud Sync Interval. It controls how often cloud information is refreshed.", "Locate Cluster Sync Interval. It controls how often cluster information is refreshed.", "Find Skip Agent Install. Leave it unselected, as it is by default in version 8.1 and later."],
          result: "You have reviewed the settings; no values need to be changed or saved."
        }),
        task("provisioning", "Set the default cloud-init user.", {
          where: "Administration > Settings > Provisioning",
          actions: ["Click the Provisioning tab.", "Scroll to Cloud-Init Settings.", "In Username, enter a default guest username of your choice.", "In Password, replace the masked placeholder with a lab-only password of your choice.", "Scroll to the bottom.", "Click Save."],
          result: "Settings saved appears. These defaults apply to new VMs that have cloud-init enabled.",
          note: "This task does not prescribe a username or password. Do not leave the password as the asterisk placeholder."
        }),
        task("backups", "Keep manager backups disabled for now.", {
          where: "Administration > Settings > Backups",
          actions: ["Click the Backups tab.", "Turn Create Backups off. If it is already off, leave it off.", "Scroll to the bottom.", "Click Save, even if you made no change."],
          result: "Settings saved appears with Create Backups off.",
          note: "Backup storage has not been configured yet. You can enable backups later."
        }),
        task("environments", "Review the default environments.", {
          where: "Administration > Settings > Environments",
          actions: ["Click the Environments tab.", "Review the four existing environment names. Leave them unchanged."],
          result: "The four default environments remain available."
        }),
        task("license", "Review the installed HVM socket license.", {
          where: "Administration > Settings > License",
          actions: ["Click the License tab.", "Locate Current Licenses and confirm that the license allows 32 HVM sockets.", "Review HVM Sockets usage below the license list."],
          result: "Before you create a cluster, the page shows 0 of 32 HVM sockets used."
        })
      ]
    },
    {
      title: "Users, roles and infrastructure groups",
      steps: [
        note("Understand how users receive permissions.", {
          actions: ["A user is an account that can access the Web UI, CLI or API. Interactive and programmatic users are treated alike.", "New users need roles to gain feature permissions beyond login.", "A role defines the features and resources its users can access.", "Permissions from multiple roles add together. None does not override access granted by another role."],
          result: "Key idea: assign the right roles to grant access; a role cannot explicitly deny a permission granted elsewhere."
        }),
        note("Understand infrastructure groups.", {
          actions: ["An infrastructure group logically collects clouds, networks, datastores and other resources.", "A group can span clouds, and a cloud can belong to multiple groups in the platform.", "Users do not receive group access directly. Assign users to a role, then grant that role access to the group."],
          result: "In this lab, you will create one group for the private HVM cloud."
        }),
        task("hvm-group", "Create the HVM infrastructure group.", {
          where: "Infrastructure > Groups",
          actions: ["Open Infrastructure.", "Select Groups.", "Click + Create."],
          values: [["Name", "HPE HVM Group"], ["Code", "hpe-hvm-group"], ["Labels", "Leave blank"], ["Location", "HPE HVM Lab"]],
          after: ["Check the spelling.", "Click Save Changes."],
          result: "HPE HVM Group appears in the groups list.",
          note: "Name is required. Code is the identifier used by automation; enter it exactly as shown."
        })
      ]
    },
    {
      title: "Create an infrastructure cloud",
      steps: [
        note("Understand what a cloud represents.", {
          actions: ["A Cloud represents a compute environment that the manager can inventory and manage.", "VM Essentials licensing supports Private and VMware vCenter clouds. A full platform license enables additional cloud providers.", "Connected clouds support workload provisioning, automation and ongoing management. Available resources differ by cloud type."],
          result: "You will create a Private Cloud to manage the HVM cluster."
        }),
        task("cloud", "Create the private HVM cloud.", {
          where: "Infrastructure > Clouds",
          actions: ["Click + Add.", "Search for Private.", "Select Private Cloud.", "Click Next."],
          values: [["Name", "HPE HVM Cloud"], ["Code", "hvmcloud"], ["Labels", "Leave blank"], ["Location", "HPE HVM Lab"], ["Enabled", "On"], ["Automatically Power On VMs", "On"], ["Inventory Existing Instances", "On"]],
          after: ["Click Next to open Group.", "Select Use Existing.", "Choose HPE HVM Group.", "Click Next.", "Review the settings.", "Click Complete."],
          result: "HPE HVM Cloud appears in the cloud list. It may show Initializing briefly."
        })
      ]
    },
    {
      title: "Create an HVM cluster",
      steps: [
        task("cluster", "Create the two-host HVM cluster.", {
          where: "Infrastructure > Clusters",
          actions: ["Click + Add Cluster.", "Select HVM as the Cluster Type.", "Click Next.", "On Group, select HPE HVM Group.", "Click Next.", "On Configure, use + SSH Host to add the second host row."],
          values: [["Cloud", "HPE HVM Cloud"], ["Cluster Name", "HPE HVM Cluster"], ["Description", "hvmcluster"], ["Layout", "HVM 1.3 Cluster on HVM/Ubuntu 24.04"], ["First SSH Hosts Name", "Node-01"], ["First host IP", "172.16.3.31"], ["Second SSH Hosts Name", "Node-02"], ["Second host IP", "172.16.3.32"], ["SSH Port (both hosts)", "22"], ["SSH Username", "student"], ["SSH Password", "!HPEstorage2050"], ["Management Net Interface", "ens192"], ["Compute Net Interface", "ens256"], ["Compute Vlans", "50-53"]],
          after: ["Click Next, leaving all other fields at their defaults.", "On Review, check both host names and IP addresses.", "Click Complete.", "Open HPE HVM Cluster.", "Open History to inspect provisioning.", "Open Hosts to check the host list."],
          result: "The cluster contains Node-01 and Node-02. Provisioning finishes after a short simulated wait."
        })
      ]
    },
    {
      title: "Update cluster networks",
      steps: [
        note("Give the compute networks meaningful names.", {
          actions: ["The compute (customer) network uses VLAN IDs 50, 51, 52 and 53.", "You will rename these networks Production, Development, Test and QA.", "Change only the display names and the access options explicitly listed in the following tasks. Keep the VLAN IDs unchanged."]
        }),
        task("production", "Configure VLAN 50 as the Production network.", {
          where: "Infrastructure > Clusters > HPE HVM Cluster > Networks",
          actions: ["Click Edit for Compute VLAN 50.", "Scroll down to Group Access.", "Expand Group Access to reveal the group options."],
          values: [["Display Name", "Production"], ["DHCP Server", "On"], ["Allow IP Override", "On"], ["HPE HVM Group Access", "On"], ["Default network for HPE HVM Group", "On"]],
          after: ["Leave all other settings unchanged and click Save Changes."],
          result: "VLAN 50 is named Production and is the default network for HPE HVM Group."
        }),
        task("development", "Configure VLAN 51 as the Development network.", {
          where: "HPE HVM Cluster > Networks",
          actions: ["Click Edit for Compute VLAN 51."],
          values: [["Display Name", "Development"], ["DHCP Server", "On"], ["Allow IP Override", "On"], ["Default network for HPE HVM Group", "Off"]],
          after: ["Leave the remaining defaults unchanged and click Save Changes."],
          result: "VLAN 51 is named Development. Production remains the group default."
        }),
        task("test-qa", "Rename VLANs 52 and 53.", {
          where: "HPE HVM Cluster > Networks",
          actions: ["Click Edit for Compute VLAN 52.", "Set Display Name to Test.", "Click Save Changes.", "Click Edit for Compute VLAN 53.", "Set Display Name to QA.", "Click Save Changes."],
          result: "The network list shows Production, Development, Test and QA.",
          note: "For Test and QA, change only Display Name. Leave DHCP Server and Allow IP Override off, keep group access unchanged, and do not select either as the default."
        }),
        task("management", "Remove user access to the Management network.", {
          where: "HPE HVM Cluster > Networks",
          actions: ["Click Edit for Management.", "Scroll to the bottom.", "Expand Group Access.", "Clear Access for every group. Leave the other network settings unchanged.", "Click Save Changes."],
          result: "Management shows no group access. This prevents users from choosing it for workloads; it does not disconnect host management."
        })
      ]
    },
    {
      title: "Add NFS storage and a heartbeat target",
      steps: [
        task("datastore", "Add the shared NFS datastore.", {
          where: "Infrastructure > Clusters > HPE HVM Cluster > Storage",
          actions: ["Under Data Stores, click Add."],
          values: [["Type", "NFS Datastore"], ["Name", "Storage01"], ["Source Host", "172.17.3.2"], ["Source Directory", "/hpe-vm1"], ["Version", "Default"], ["Image Target", "On"], ["HPE HVM Group Access", "On"]],
          after: ["Leave Heartbeat Target off for this step.", "Check the values.", "Click Save."],
          result: "Storage01 appears in Data Stores. The no-heartbeat-target warning remains until the next task.",
          note: "Source Host is 172.17.3.2. The file shares in the later task use a different address: 172.16.3.2."
        }),
        note("Understand the heartbeat datastore warning.", {
          actions: ["Each host writes a heartbeat file to the shared heartbeat datastore.", "Other hosts monitor these files. If a host stops updating its file, the cluster can detect the failure and initiate failover.", "The yellow warning means that no datastore has been selected as a heartbeat target."],
          result: "Next, you will use Storage01 as the heartbeat target."
        }),
        task("heartbeat", "Enable the heartbeat target on Storage01.", {
          where: "HPE HVM Cluster > Storage > Data Stores",
          actions: ["In the Storage01 row, click Edit.", "Select Heartbeat Target. Keep the other values unchanged.", "Click Save Changes."],
          result: "Storage01 shows Heartbeat Target enabled and the yellow warning disappears."
        })
      ]
    },
    {
      title: "Create manager file-share stores",
      steps: [
        task("fileshare", "Create the manager's image and backup file share.", {
          where: "Infrastructure > Storage > FileShares",
          actions: ["Click + Add.", "Select NFSv3."],
          values: [["Name", "FileShare01"], ["Host", "172.16.3.2"], ["Export Folder", "/hpe-vm-image"], ["Active", "On"], ["Default Backup Target", "On"], ["Update existing backups", "On"], ["Default Deployment Archive Target", "Off"], ["Default Virtual Image Store", "On"], ["Default Support Bundle Store", "Off"]],
          after: ["Leave all other settings at their defaults and click Save Changes.", "If the list has not updated after about 5 seconds, use the Reload button inside the simulated Chrome window."],
          result: "FileShare01 appears in the FileShares list."
        }),
        task("templates", "Create the file share for VM templates.", {
          where: "Infrastructure > Storage > FileShares",
          actions: ["Click + Add.", "Select NFSv3."],
          values: [["Name", "Templates-share"], ["Host", "172.16.3.2"], ["Export Folder", "/hpe-vm-templ"], ["Active", "On"], ["Default Backup Target", "Off"], ["Update existing backups", "Off"], ["Default Deployment Archive Target", "Off"], ["Default Virtual Image Store", "Off"], ["Default Support Bundle Store", "Off"]],
          after: ["Leave all other defaults unchanged and click Save Changes."],
          result: "Templates-share appears alongside FileShare01. Its folder contains preloaded templates for the provisioning lab."
        })
      ]
    },
    {
      title: "Manage the manager VM and install its agent",
      steps: [
        task("managed", "Convert the manager VM from unmanaged to managed.", {
          where: "Infrastructure > Compute > Virtual Machines",
          actions: ["Find hpe-vm on Node-01. Its Type is initially Unmanaged.", "Select the checkbox for hpe-vm.", "Open Actions.", "Click Convert To Managed."],
          values: [["Username", "admin"], ["Password", "Manager VM password from installation (!HPEstorage2050 in the brief)"], ["Agent", "No Agent install"], ["Instance Type", "Ubuntu"], ["Version", "24.04"], ["Layout", "Single KVM VM"], ["Operating System", "Ubuntu 24.04 64-bit"], ["Plan (read-only)", "4 CPU, 16GB Memory"]],
          after: ["Leave other settings unchanged and click Save Changes."],
          result: "The Type changes to Managed. Click hpe-vm to open its details.",
          note: "The plan comes from the VM's discovered CPU and memory. Use the guest SSH password, not your master Web UI password."
        }),
        task("agent", "Install the Morpheus Agent on the manager VM.", {
          where: "Infrastructure > Compute > Virtual Machines > hpe-vm",
          actions: ["Open Actions.", "Select Install Agent.", "In the confirmation dialog, click OK.", "Open History to watch the installation. Status changes to Upgrading while it runs.", "Wait for Provisioned.", "Check Agent Version above the tabs."],
          result: "Agent Version is populated and discovered guest properties appear.",
          note: "Use Reload inside the simulated Chrome window if needed; do not refresh the outer lab page."
        })
      ]
    },
    {
      title: "Move the manager VM to cluster storage",
      steps: [
        note("Understand why the manager disk must move.", {
          actions: ["The QCOW2 installation placed the manager VM's disk on local hypervisor storage.", "Moving the disk to shared cluster storage enables host-to-host movement and supports high availability.", "This operation is similar to Storage vMotion in VMware."],
          result: "You will move the root disk from Local to Storage01. The CD-ROM does not need to move."
        }),
        task("migration", "Move the manager's root disk to Storage01.", {
          where: "Infrastructure > Compute > Virtual Machines > hpe-vm > Storage",
          actions: ["Confirm that the root disk is on Local. Ignore the CD-ROM row.", "Open Actions.", "Select Reconfigure.", "In Volumes - root disk, select Storage01.", "Click Reconfigure.", "Open History. Status changes to Resizing while the data moves.", "Wait for status to return to Provisioned.", "Open Storage again."],
          result: "The root disk's Datastore is Storage01.",
          note: "You can work on other tasks during migration. Guided Mode waits for the move to finish before marking this step complete. Simulated migration is faster than a real data move."
        })
      ]
    },
    {
      title: "Add Node-03 to the HVM cluster",
      steps: [
        task("node", "Add the third host, Node-03.", {
          where: "Infrastructure > Clusters > HPE HVM Cluster",
          actions: ["Open Actions.", "Select Add HPE VM Hypervisor.", "Enter Node-03 in Name.", "Leave Description blank.", "Click Next."],
          values: [["Plan", "Default Manual"], ["SSH Host IP", "172.16.3.33"], ["SSH Port", "22"], ["SSH Username", "student"], ["SSH Password", "!HPEstorage2050"], ["Management Net Interface", "ens192"], ["Storage Net Interface", "ens224"], ["Compute Net Interface", "ens256"], ["Compute Vlans", "50-53"]],
          after: ["Click Next, leaving all other defaults unchanged.", "Verify the settings on Review.", "Click Complete.", "Open History.", "Wait for Server provisioning to show Complete.", "Wait for Post Provisioning Operations to show Complete.", "Open Hosts.", "Verify Node-01, Node-02 and Node-03 are all Provisioned."],
          result: "The HVM cluster has three provisioned hosts.",
          note: "A real deployment takes about 3-4 minutes; this simulator finishes faster. You may work elsewhere while it runs, but this task completes only after provisioning finishes."
        })
      ]
    },
    {
      title: "Configure a VMware infrastructure group",
      steps: [
        note("Prepare a separate group for VMware resources.", {
          actions: ["Keep the HPE HVM Group you created earlier.", "Create a second group to organize VMware resources separately.", "As with the HVM group, users receive access through roles rather than direct group membership."]
        }),
        task("vmware", "Create the VMware infrastructure group.", {
          where: "Infrastructure > Groups",
          actions: ["Click + Create."],
          values: [["Name", "VMware Group"], ["Code", "vmwaregroup"], ["Labels", "Leave blank"], ["Location", "Training Lab"]],
          after: ["Verify the spelling.", "Click Save Changes."],
          result: "Both HPE HVM Group and VMware Group appear in the list.",
          note: "Name is mandatory. Enter Code exactly as shown so automation can identify the group."
        })
      ]
    }
  ];

  function check(key, s) {
    if (!s) return false;
    const settings = s.settings || {};
    const infra = s.infrastructure || {};
    const c = infra.cluster;
    const networks = c ? c.networks : [];
    const n = (vlan) => networks.find((x) => x.vlan === vlan) || {};
    const ds = c && c.datastore;
    const vm = infra.vm || {};
    const group = (name, code, location) => (s.groups || []).find((g) => g.name === name && g.code === code && g.location === location && !g.labels);
    const g = group("HPE HVM Group", "hpe-hvm-group", "HPE HVM Lab");
    const cloud = (s.clouds || []).find((x) => x.type === "private" && x.name === "HPE HVM Cloud" && x.code === "hvmcloud" && x.location === "HPE HVM Lab" && x.enabled && x.powerOn && x.inventory && g && x.groupId === g.id);
    const share = (name, folder) => (infra.shares || []).find((x) => x.name === name && x.host === "172.16.3.2" && x.folder === folder && x.type === "NFSv3" && x.active && !x.archive && !x.support);
    switch (key) {
      case "appliance": return s.setupDone && settings.applianceName === "HPE-VM1" && settings.applianceUrl === "https://hpe-vm1.talabs.local/" && !settings.bkCreate && settings.monitoring && settings.logs;
      case "login": return s.loggedIn;
      case "appliance-review": return s.visited === "appliance";
      case "provisioning": return !!(settings.ciUser && settings.ciPass && settings.ciPass !== "************");
      case "backups": return settings.bkCreate === false && settings.backupsSaved === true;
      case "environments": return s.visited === "environments";
      case "license": return s.visited === "license";
      case "hvm-group": return !!g;
      case "cloud": return !!cloud;
      case "cluster": return !!(c && cloud && c.cloudId === cloud.id && c.groupId === g.id && c.name === "HPE HVM Cluster" && c.description === "hvmcluster" && c.layout === "HVM 1.3 Cluster on HVM/Ubuntu 24.04" && c.management === "ens192" && c.compute === "ens256" && c.vlans === "50-53" && c.hosts.length >= 2 && c.hosts[0].name === "Node-01" && c.hosts[0].ip === "172.16.3.31" && c.hosts[1].name === "Node-02" && c.hosts[1].ip === "172.16.3.32");
      case "production": return n(50).name === "Production" && n(50).dhcp && n(50).override && n(50).access && n(50).default;
      case "development": return n(51).name === "Development" && n(51).dhcp && n(51).override && !n(51).default;
      case "test-qa": return n(52).name === "Test" && n(53).name === "QA" && [n(52), n(53)].every((x) => !x.default && !x.dhcp && !x.override && x.access);
      case "management": return networks.some((x) => x.vlan === null && !x.access);
      case "datastore": return !!(ds && ds.name === "Storage01" && ds.type === "NFS Datastore" && ds.version === "Default" && ds.host === "172.17.3.2" && ds.directory === "/hpe-vm1" && ds.image && ds.access);
      case "heartbeat": return !!(ds && ds.heartbeat);
      case "fileshare": { const f = share("FileShare01", "/hpe-vm-image"); return !!(f && f.backup && f.update && f.images); }
      case "templates": { const f = share("Templates-share", "/hpe-vm-templ"); return !!(f && !f.backup && !f.images && !f.update); }
      case "managed": return vm.managed === true;
      case "agent": return !!vm.agent && !vm.agentDue;
      case "migration": return vm.datastore === "Storage01" && !vm.migrationDue;
      case "node": return !!(c && c.hosts.some((h) => h.name === "Node-03" && h.ip === "172.16.3.33" && h.storage === "ens224" && h.management === "ens192" && h.compute === "ens256" && h.vlans === "50-53" && !h.due));
      case "vmware": return !!group("VMware Group", "vmwaregroup", "Training Lab");
      default: return false;
    }
  }

  let snapshot = null;
  const reviewed = new Set();
  document.addEventListener("vme:track", (event) => {
    const e = event.detail;
    if (e && e.name === "setup-state") {
      snapshot = e.snapshot;
      if (snapshot.visited) reviewed.add(snapshot.visited);
    }
  });
  const required = parts.flatMap((p) => p.steps.filter((s) => s.key));

  function instructionPages(step) {
    const pages = [];
    const add = (details) => pages.push(Object.assign({ text: step.text, where: step.where }, details));
    (step.actions || []).forEach((action) => add({ actions: [action] }));
    (step.values || []).forEach((value) => add({ values: [value] }));
    const commands = step.commands || (step.cmd ? [["Run in the terminal, then press Enter", step.cmd]] : []);
    commands.forEach((command) => add({ commands: [command] }));
    (step.after || []).forEach((action) => add({ actions: [action] }));
    if (!pages.length) add({});
    // Keep safety and credential context visible while following any individual action.
    pages.forEach((page) => {
      page.note = step.note || step.hint;
    });
    pages[pages.length - 1].result = step.result;
    return pages;
  }

  function watchInteractions(container, advance) {
    let skipFocusout = null;
    const editable = (target) => target && target.closest && target.closest("input, textarea, select, [contenteditable='true']");
    container.addEventListener("click", (event) => {
      if (event.detail !== 1 || editable(event.target) || editable(document.activeElement)) return;
      advance();
    }, true);
    container.addEventListener("keydown", (event) => {
      if (!["Enter", "ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight", "Escape"].includes(event.key)) return;
      if (event.target && event.target.closest && event.target.closest("button, a, [role='button']")) return;
      if (editable(event.target)) {
        if (event.key !== "Enter") return;
        skipFocusout = event.target;
        setTimeout(() => { skipFocusout = null; }, 0);
      }
      advance();
    }, true);
    container.addEventListener("focusout", (event) => {
      if (editable(event.target) && skipFocusout !== event.target) advance();
    }, true);
  }

  function renderInstruction(step) {
    const node = (tag, cls, text) => {
      const el = document.createElement(tag);
      el.className = cls;
      if (text !== undefined) el.textContent = text;
      return el;
    };
    const body = node("div", "vme-instruction");
    body.appendChild(node("h3", "vme-instruction__title", step.text));
    if (step.where) {
      const location = node("p", "vme-instruction__location");
      location.append(node("strong", "", "Go to: "), document.createTextNode(step.where));
      body.appendChild(location);
    }
    const actions = (items, start) => {
      if (!items || !items.length) return;
      const list = node("ol", "vme-instruction__actions");
      list.start = start;
      items.forEach((text) => list.appendChild(node("li", "", text)));
      body.appendChild(list);
    };
    actions(step.actions, 1);
    if (step.values && step.values.length) {
      body.appendChild(node("p", "vme-instruction__caption", step.values.length === 1 ? "Use this setting" : "Use these settings"));
      const values = node("dl", "vme-instruction__values");
      step.values.forEach(([label, value]) => {
        const row = node("div", "vme-instruction__value");
        row.append(node("dt", "", label), node("dd", "", value));
        values.appendChild(row);
      });
      body.appendChild(values);
    }
    const commands = step.commands || (step.cmd ? [["Run in the terminal, then press Enter", step.cmd]] : []);
    commands.forEach(([label, command]) => {
      const block = node("div", "vme-instruction__command");
      block.append(node("p", "vme-instruction__caption", label), node("code", "", command));
      body.appendChild(block);
    });
    actions(step.after, (step.actions || []).length + 1);
    if (step.result) {
      const result = node("p", "vme-instruction__result");
      result.append(node("strong", "", "Expected result: "), document.createTextNode(step.result));
      body.appendChild(result);
    }
    if (step.note || step.hint) {
      const note = node("p", "vme-instruction__note");
      note.append(node("strong", "", "Note: "), document.createTextNode(step.note || step.hint));
      body.appendChild(note);
    }
    return body;
  }

  window.SimLabsSetup = {
    parts: parts,
    check: check,
    renderInstruction: renderInstruction,
    instructionPages: instructionPages,
    watchInteractions: watchInteractions,
    remaining: () => required.filter((s) => {
      const tab = { "appliance-review": "appliance", environments: "environments", license: "license" }[s.key];
      return tab ? !reviewed.has(tab) : !check(s.key, snapshot);
    }),
    resetReviews: () => reviewed.clear()
  };
})();
