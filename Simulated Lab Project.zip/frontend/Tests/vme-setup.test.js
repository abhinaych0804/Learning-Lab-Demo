const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

function load(file) {
  const document = new EventTarget();
  const context = { window: {}, document, CustomEvent, TextEncoder, console, setTimeout, clearTimeout };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, "..", "Scripts", file), "utf8"), context);
  return context;
}

function shellFixture() {
  const shell = load("vme-moba-shell.js").window.MobaShell;
  const filesystem = shell.createFs("manager");
  shell.deployManager(filesystem, "hpe-vm1");
  const state = shell.createState(filesystem, "root", "manager", "172.16.3.3", "172.16.3.9");
  const run = (command) => {
    const result = shell.run(command, state);
    return { code: state.code, text: result.chunks.flat().join("") };
  };
  return { shell, filesystem, state, run };
}

test("KVM status, filters, autostart and failed-deployment recovery", () => {
  const { run } = shellFixture();
  assert.match(run("virsh list --all").text, /hpe-vm1\s+running/);
  assert.doesNotMatch(run("virsh list --autostart").text, /hpe-vm1/);
  assert.match(run("virsh list --no-autostart").text, /hpe-vm1/);
  assert.equal(run("virsh autostart hpe-vm1").code, 0);
  assert.match(run("virsh list --autostart").text, /hpe-vm1/);
  assert.doesNotMatch(run("virsh list --no-autostart").text, /hpe-vm1/);
  assert.equal(run("virsh undefine failed-vm").code, 1);
  assert.equal(run("rm /var/morpheus/kvm/local/failed-vm.qcow2").code, 1);
  assert.equal(run("virsh shutdown failed-vm").code, 0);
  assert.match(run("virsh list --all").text, /failed-vm\s+shut off/);
  assert.equal(run("virsh destroy failed-vm").code, 1);
  assert.equal(run("virsh undefine failed-vm").code, 0);
  assert.doesNotMatch(run("virsh list --all").text, /failed-vm/);
  assert.match(run("ll /var/morpheus/kvm/local").text, /failed-vm\.qcow2/);
  assert.equal(run("rm /var/morpheus/kvm/local/failed-vm.qcow2").code, 0);
  assert.doesNotMatch(run("ll /var/morpheus/kvm/local").text, /failed-vm\.qcow2/);
  assert.equal(run("virsh undefine hpe-vm1").code, 1);
  assert.equal(run("rm /var/morpheus/kvm/local/hpe-vm1.qcow2").code, 1);
  assert.equal(run("rm -rf /var/morpheus/kvm/local").code, 1);
  assert.match(run("ll /var/morpheus/kvm/local").text, /hpe-vm1\.qcow2/);
  assert.equal(run("virsh list --invalid").code, 1);
});

test("DNS aliases, lookup failures and host-specific virsh access", () => {
  const { shell } = shellFixture();
  const filesystem = shell.createFs("hpe-vm1");
  filesystem.dns = "172.16.3.9";
  const state = shell.createState(filesystem, "admin", "hpe-vm1", "172.16.3.6", "172.16.3.9");
  for (const host of ["vcenter-01.talabs.local", "vcenter.talabs.local"]) {
    const result = shell.run("nslookup " + host, state);
    assert.equal(state.code, 0);
    assert.match(result.chunks.join(""), /Server:\s+172\.16\.3\.9/);
  }
  shell.run("nslookup invalid.talabs.local", state);
  assert.equal(state.code, 1);
  filesystem.dns = "172.16.3.8";
  assert.match(shell.run("nslookup vcenter-01.talabs.local", state).chunks.join(""), /timed out/);
  assert.equal(state.code, 1);
  shell.run("sudo virsh list --all", state);
  assert.equal(state.code, 1);
});

function configured() {
  return {
    setupDone: true, loggedIn: true,
    settings: { applianceName: "HPE-VM1", applianceUrl: "https://hpe-vm1.talabs.local/", bkCreate: false, monitoring: true, logs: true, ciUser: "student", ciPass: "LabTestPassword", backupsSaved: true },
    groups: [{ id: 2, name: "HPE HVM Group", code: "hpe-hvm-group", location: "HPE HVM Lab", labels: "" }, { id: 3, name: "VMware Group", code: "vmwaregroup", location: "Training Lab", labels: "" }],
    clouds: [{ id: 1, type: "private", name: "HPE HVM Cloud", code: "hvmcloud", location: "HPE HVM Lab", groupId: 2, enabled: true, powerOn: true, inventory: true }],
    infrastructure: {
      cluster: {
        name: "HPE HVM Cluster", description: "hvmcluster", groupId: 2, cloudId: 1, layout: "HVM 1.3 Cluster on HVM/Ubuntu 24.04", management: "ens192", compute: "ens256", vlans: "50-53",
        hosts: [{ name: "Node-01", ip: "172.16.3.31" }, { name: "Node-02", ip: "172.16.3.32" }, { name: "Node-03", ip: "172.16.3.33", storage: "ens224", management: "ens192", compute: "ens256", vlans: "50-53" }],
        networks: [
          { vlan: 50, name: "Production", dhcp: true, override: true, access: true, default: true },
          { vlan: 51, name: "Development", dhcp: true, override: true, access: true, default: false },
          { vlan: 52, name: "Test", access: true, default: false }, { vlan: 53, name: "QA", access: true, default: false }, { vlan: null, name: "Management", access: false }
        ],
        datastore: { name: "Storage01", type: "NFS Datastore", version: "Default", host: "172.17.3.2", directory: "/hpe-vm1", image: true, access: true, heartbeat: true }
      },
      shares: [
        { name: "FileShare01", type: "NFSv3", host: "172.16.3.2", folder: "/hpe-vm-image", active: true, backup: true, update: true, images: true },
        { name: "Templates-share", type: "NFSv3", host: "172.16.3.2", folder: "/hpe-vm-templ", active: true, backup: false, update: false, images: false }
      ],
      vm: { managed: true, agent: "9.0.1", datastore: "Storage01" }
    }
  };
}

test("shared curriculum excludes optional recovery from mandatory completion", () => {
  const { window, document } = load("vme-setup.js");
  const setup = window.SimLabsSetup;
  assert.equal(setup.parts.filter((p) => p.optional).length, 2);
  assert.equal(setup.parts.filter((p) => p.optional).flatMap((p) => p.steps).filter((s) => s.key).length, 0);
  assert.equal(setup.remaining().length, 23);
  const snapshot = configured();
  for (const visited of ["appliance", "environments", "license"]) {
    snapshot.visited = visited;
    document.dispatchEvent(new CustomEvent("vme:track", { detail: { name: "setup-state", snapshot } }));
  }
  assert.equal(setup.remaining().length, 0);
  snapshot.infrastructure.vm.migrationDue = Date.now() + 1000;
  snapshot.infrastructure.cluster.hosts[2].due = Date.now() + 1000;
  assert.deepEqual(Array.from(setup.remaining(), (s) => s.key), ["migration", "node"]);
});

function curriculum() {
  const context = load("vme-setup.js");
  context.document.getElementById = () => ({});
  context.document.documentElement = { dataset: { labMode: "practice" } };
  vm.runInContext(fs.readFileSync(path.join(__dirname, "..", "Scripts", "vme-guide.js"), "utf8"), context);
  return context;
}

test("all 81 instructions stay in order and expose readable structured content", () => {
  const setup = curriculum().window.SimLabsSetup;
  assert.deepEqual(Array.from(setup.installationParts, (p) => p.steps.length), [18, 3, 23]);
  assert.equal(setup.parts.flatMap((p) => p.steps).length, 37);
  const steps = setup.installationParts.concat(setup.parts).flatMap((p) => p.steps);
  assert.equal(steps.length, 81);
  for (const step of steps) {
    assert.ok(step.text.length > 0 && step.text.length < 100, step.text);
    assert.ok(step.actions || step.values || step.cmd || step.commands || step.hint, step.text);
    assert.ok(step.ack || (step.ev && typeof step.test !== "undefined"), step.text);
    for (const action of (step.actions || []).concat(step.after || [])) assert.ok(action.trim(), step.text);
    for (const pair of (step.values || []).concat(step.commands || [])) {
      assert.equal(pair.length, 2);
      assert.ok(pair.every((v) => typeof v === "string" && v.trim()), step.text);
    }
  }
  assert.deepEqual(Array.from(steps.filter((s) => s.key), (s) => s.key), [
    "appliance", "login", "appliance-review", "provisioning", "backups", "environments", "license",
    "hvm-group", "cloud", "cluster", "production", "development", "test-qa", "management",
    "datastore", "heartbeat", "fileshare", "templates", "managed", "agent", "migration", "node", "vmware"
  ]);
});

test("instruction rendering uses text nodes, ordered actions and separate field values", () => {
  const { window, document } = curriculum();
  class Node {
    constructor(tag) { this.tag = tag; this.children = []; this.textContent = ""; }
    append(...children) { this.children.push(...children); }
    appendChild(child) { this.children.push(child); return child; }
  }
  document.createElement = (tag) => new Node(tag);
  document.createTextNode = (text) => Object.assign(new Node("#text"), { textContent: text });
  const step = {
    text: "<script>not HTML</script>", where: "Infrastructure > Clusters", actions: ["Open Configure.", "Enter the settings."],
    values: [["Name", "HPE HVM Cluster"]], commands: [["Check status", "virsh list --all"]],
    after: ["Click Next."], result: "Review appears.", note: "Leave other defaults."
  };
  const body = window.SimLabsSetup.renderInstruction(step);
  assert.equal(body.children[0].textContent, step.text);
  const lists = body.children.filter((n) => n.tag === "ol");
  assert.deepEqual(lists.map((n) => n.start), [1, 3]);
  assert.equal(lists[0].children.length, 2);
  const values = body.children.find((n) => n.tag === "dl").children[0];
  assert.equal(values.children[0].tag, "dt");
  assert.equal(values.children[1].tag, "dd");
  assert.equal(values.children[1].textContent, "HPE HVM Cluster");
  assert.equal(body.children.find((n) => n.className === "vme-instruction__command").children[1].tag, "code");
  for (const instruction of window.SimLabsSetup.installationParts.concat(window.SimLabsSetup.parts).flatMap((p) => p.steps)) {
    assert.ok(window.SimLabsSetup.renderInstruction(instruction).children.length >= 2, instruction.text);
  }
});

test("single-action pages preserve every action, setting and command in sequence", () => {
  const setup = curriculum().window.SimLabsSetup;
  for (const step of setup.installationParts.concat(setup.parts).flatMap((p) => p.steps)) {
    const pages = Array.from(setup.instructionPages(step));
    const expected = [
      ...(step.actions || []),
      ...(step.values || []),
      ...(step.commands || (step.cmd ? [["Run in the terminal, then press Enter", step.cmd]] : [])),
      ...(step.after || [])
    ];
    const actual = pages.flatMap((page) => {
      const entries = [...(page.actions || []), ...(page.values || []), ...(page.commands || [])];
      assert.ok(entries.length <= 1, step.text);
      assert.equal(page.text, step.text);
      assert.equal(page.where, step.where);
      assert.equal(page.note, step.note || step.hint);
      return entries;
    });
    assert.deepEqual(JSON.parse(JSON.stringify(actual)), JSON.parse(JSON.stringify(expected)), step.text);
    assert.equal(pages.at(-1).result, step.result);
    assert.ok(pages.slice(0, -1).every((page) => !page.result), step.text);
  }
  const master = setup.parts.flatMap((p) => p.steps).find((s) => s.key === "appliance");
  assert.ok(setup.instructionPages(master).length > 15);
});

test("lab-window interactions advance one action without counting typing as separate actions", async () => {
  const setup = load("vme-setup.js").window.SimLabsSetup;
  const listeners = {};
  const container = {
    addEventListener(name, handler) { listeners[name] = handler; }
  };
  const input = { closest: (selector) => selector.includes("input") ? input : null };
  const button = { closest: (selector) => selector.includes("button") ? button : null };
  let advanced = 0;
  setup.watchInteractions(container, () => { advanced++; });
  listeners.click({ detail: 1, target: {} });
  listeners.click({ detail: 2, target: {} });
  listeners.click({ detail: 1, target: input });
  assert.equal(advanced, 1);
  listeners.focusout({ target: input });
  listeners.keydown({ key: "a", target: {} });
  listeners.keydown({ key: "Enter", target: button });
  assert.equal(advanced, 2);
  listeners.keydown({ key: "Enter", target: input });
  assert.equal(advanced, 3);
  await new Promise((resolve) => setTimeout(resolve, 0));
  listeners.focusout({ target: input });
  assert.equal(advanced, 4);
});

test("mandatory checks reject wrong network, storage and bootstrap settings", () => {
  const setup = load("vme-setup.js").window.SimLabsSetup;
  const s = configured();
  s.infrastructure.cluster.datastore.host = "172.16.3.2";
  assert.equal(setup.check("datastore", s), false);
  s.infrastructure.cluster.networks[0].default = false;
  assert.equal(setup.check("production", s), false);
  s.infrastructure.shares[1].backup = true;
  assert.equal(setup.check("templates", s), false);
  s.settings.bkCreate = true;
  assert.equal(setup.check("appliance", s), false);
  assert.equal(setup.check("backups", s), false);
  s.settings.ciPass = "************";
  assert.equal(setup.check("provisioning", s), false);
  assert.equal(setup.check("unknown", s), false);
  assert.equal(setup.check("cluster", null), false);
});

test("pending operations resume and persist without an open infrastructure page", async () => {
  const create = load("vme-infrastructure.js").window.VmeInfrastructure;
  const server = configured();
  const infra = server.infrastructure;
  infra.vm.agent = "";
  infra.vm.datastore = "Local";
  infra.vm.agentDue = Date.now() + 10;
  infra.vm.migrationDue = Date.now() + 10;
  infra.vm.migrationTarget = "Storage01";
  infra.cluster.hosts[2].due = Date.now() + 10;
  let saved = 0;
  const ui = create({ server, save: () => { saved++; } });
  ui.resume();
  await new Promise((resolve) => setTimeout(resolve, 1150));
  assert.equal(infra.vm.agent, "9.0.1");
  assert.equal(infra.vm.datastore, "Storage01");
  assert.equal(infra.vm.agentDue, undefined);
  assert.equal(infra.vm.migrationDue, undefined);
  assert.equal(infra.cluster.hosts[2].due, undefined);
  assert.equal(saved, 1);
});
