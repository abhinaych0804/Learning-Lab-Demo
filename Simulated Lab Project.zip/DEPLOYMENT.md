# Deploying Simulated Labs

This guide targets **Azure App Service (Linux)** with **Azure Database for MySQL – Flexible Server**. Any host that
runs Node 22 and MySQL 8 works the same way: use the same settings.

One Node app serves both the API (`backend/`) and the pages (`frontend/`), so there is a single site and a single
address. Do not host the pages separately: the login cookie is `SameSite=Lax` and would not reach a different site.

## 1. Azure resources

1. **MySQL Flexible Server** (8.0) and an empty database named `simulated_labs`.
   - Create an account for the app with `SELECT, INSERT, UPDATE, DELETE` on `simulated_labs.*`.
   - Keep the server's admin account for migrations (step 4).
   - Let the web app reach the server (private access with VNet integration, or a firewall rule for the web app's
     outbound addresses).
2. **App Service**: Linux, runtime **Node 22 LTS**. Turn on **HTTPS Only** and set the health check path to
   `/api/health`.
3. **Email for sign-in codes**, one of:
   - **SendGrid**: a verified sender and an API key.
   - **Azure Communication Services Email**: an email service with a linked domain (an Azure-managed
     `*.azurecomm.net` domain works to start with) and a communication service. Use its connection string and the
     domain's sender address, for example `DoNotReply@<guid>.azurecomm.net`. Messages from a Microsoft-managed domain
     can be filtered by strict mail gateways, so send yourself a test first; a custom domain gives better delivery.

## 2. App settings

Set these under the web app's *Environment variables / Application settings*. Keep secrets in Key Vault references.

| Setting | Value |
|---|---|
| `NODE_ENV` | `production` |
| `HOST` | `0.0.0.0` |
| `JWT_SECRET` | new random string, 32+ characters: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`. Never reuse a development secret. |
| `ALLOWED_EMAIL_DOMAINS` | `hpe.com` (required in production; the app will not start without it) |
| `TRUST_PROXY` | `1` (one load balancer sits in front of App Service) |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` | your MySQL server and the app account |
| `DB_SSL` | `true` (managed MySQL requires encryption). Add `DB_SSL_CA` (path to a PEM file) only if the certificate is not trusted. |
| `SENDGRID_API_KEY`, `OTP_FROM_EMAIL` | SendGrid key and verified sender |
| `AZURE_COMMUNICATION_CONNECTION_STRING`, `OTP_FROM_EMAIL` | Alternative to SendGrid (used when `SENDGRID_API_KEY` is empty) |
| `OTP_ENABLED` | `true` |

`PORT` is provided by App Service. Do not set it.

## 3. Pipeline

1. In Azure DevOps create a pipeline from `azure-pipelines.yml`.
2. Add the variables `azureServiceConnection` (a service connection with access to the web app) and `webAppName`.
3. The `production` environment is created on first run. Add an approval to it if releases should be reviewed.

Each push to `master` builds the package and deploys it. The runtime in the pipeline (`NODE|22-lts`) and the Node
version in the App Service settings must match.

## 4. Database migrations

Run migrations once per release that adds files to `backend/db/migrations/`. They are safe to run again.

From the web app's SSH console (the app settings are available there; if `printenv DB_HOST` is empty, export them):

```
cd /home/site/wwwroot/backend
MIGRATE_DB_USER=<admin account> MIGRATE_DB_PASSWORD=<its password> npm run migrate
```

`MIGRATE_DB_USER` lets the migration use the admin account while the app keeps its read/write-only one. You can also
run the same command from a machine that can reach the database.

## 5. HPE-only access

- Registration (including the reporting manager's email), sign-in, and every API request check that the email's
  domain is in `ALLOWED_EMAIL_DOMAINS`. Matching is exact: `hpe.com` does not admit `mail.hpe.com`.
- The emailed code proves the person can read that mailbox.
- An account whose domain is not allowed cannot sign in, and its existing session stops working.
- The page files (HTML, scripts, images) are public; the data is not. To hide the pages too, put the site behind
  Microsoft Entra ID sign-in (App Service Authentication) as a second layer.
- Check that SendGrid mail reaches `@hpe.com` inboxes. Messages from an outside sender can be filtered, so ask HPE IT
  to allow the sender or use an internal mail relay.

## 6. Smoke test

1. `https://<your-app>/api/health` returns `{"success":true}`.
2. Register with an `@hpe.com` address, receive the code, sign in.
3. Register with another address: refused with "Only @hpe.com email addresses can be used with this site."
4. Open a VME lab, complete a step, reload: the progress is remembered.
5. Enter a wrong password 31 times from one machine: the 31st attempt is refused (429) and another machine is not
   affected. If everyone is limited together, `TRUST_PROXY` is missing.

## Troubleshooting

| Symptom | Cause |
|---|---|
| App exits on start | Read the log stream. `JWT_SECRET must be set…` or `ALLOWED_EMAIL_DOMAINS must be set…`. |
| 500 when registering or opening labs | Migrations have not been run (step 4). |
| Database connection errors about secure transport | Set `DB_SSL=true`. |
| No sign-in code arrives | No email option configured, sender not verified, or mail filtered (check Junk). |
