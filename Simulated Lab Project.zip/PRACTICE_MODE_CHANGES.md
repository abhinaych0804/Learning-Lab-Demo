# Practice Mode: Session Changes

## Scope
Practice mode for the VME installation and setup lab. It scores time, efficiency, and problem solving. Guided mode steps (`frontend/Scripts/vme-guide.js`) are the reference sequence. UI styles follow `frontend/Styles`.

## Post-installation setup extension
- Both modes now use the shared instructions and 23 mandatory checks in `frontend/Scripts/vme-setup.js`. Guided mode appends these to the existing ISO/package/QCOW2 installation steps. Practice mode provides a manually navigated single-action reference rather than a completion-tracked walkthrough.
- Existing first-run setup, login, Administration Settings, Groups and Clouds are reused. First-run setup now includes backup, monitoring and logging selections and retains the appliance name/URL.
- `frontend/Scripts/vme-infrastructure.js` adds HVM cluster creation, VLAN naming/access, NFS datastore/heartbeat configuration, both NFSv3 file shares, conversion to managed, agent installation, disk migration and Node-03 provisioning. Saved infrastructure survives page reloads. Background tasks use shorter simulated timings and finish even when another page is open.
- Optional KVM operations support `virsh list --all`, `--autostart`, `--no-autostart`, `virsh autostart`, shutdown/destroy/undefine, `ll` and DNS lookups from the manager SSH session. Manager SSH uses the IP and password actually entered during installation, including a replacement Practice IP.
- Destructive recovery uses the disposable `failed-vm`. The working manager and disks belonging to defined domains are protected. The reference explains why wildcard disk deletion is unsafe and distinguishes force shutdown from undefining a VM.
- The canonical domain is `talabs.local`; DNS checks support both supplied vCenter names. The datastore uses `172.17.3.2`; file shares use `172.16.3.2`. Cloud-init credentials were unspecified, so learners choose their own instead of receiving invented credentials.
- Practice Finish requires the manager image installation, a diagnosis and all mandatory setup checks, not just the console package installation. Optional recovery is not scored. Resolution allocates 15 points to installation and 15 to configuration; the total remains 100. Existing timer thresholds are unchanged. Resetting a scenario clears appliance configuration as well as the attempt.
- New UI styling is confined to `frontend/Styles/vme-infrastructure.css`, reusing the existing console components and guide/practice tokens.
- Regression tests: `node --test frontend\Tests\vme-setup.test.js`. Browser validation uses an isolated mock API; it does not verify production authentication or score persistence.

The remaining sections record earlier implementation history; the extension above supersedes installation-only completion behavior.

### Instruction readability
- The 81 tracked tasks are broken into individual action cards: only one action, field/value, or terminal command is visible at a time. Each lab-window interaction advances the instruction automatically; Back navigates to the prior action. Existing task completion checks remain in place, and acknowledgment tasks offer Continue only on the final action.
- Practice Mode's reference includes initial installation and post-installation setup, showing one action at a time. Lab-window interactions advance the reference, Back navigates to prior actions, and the section selector jumps to another part. Reference navigation does not start the timer or complete scored tasks.
- Instructions distinguish the outer lab page from the window/browser, and distinguish hypervisor SSH, manager guest SSH and the Web UI master account.
- Existing step order, counts, completion events and saved step indexes are unchanged. Guidance labels explain whether to click Continue or wait for automatic advancement.
- Presentation rules are in `frontend/Styles/vme-guide.css`; no inline styling was added.

## New files
- `frontend/Scripts/vme-practice.js`
  - Posts the score on Finish and shows saved status, best score and history on the scorecard.
  - Practice scenario, timer, and random fault selection (`deb-missing`, `ip-conflict`).
  - Hints (each costs points), diagnosis submission, Finish gating, and scorecard rendering.
  - Exposes `window.SimLabsPractice`.
  - Listens for `vme:track` events to score actions.
- `frontend/Styles/vme-practice.css`
  - `.vme-practice__*` classes using existing design tokens.
- `backend/db/migrations/004_lab_scores.sql` and `backend/src/routes/labs.js` (score endpoints).
- `backend/db/migrations/005_reporting_managers.sql`: adds the `manager` role and the `reporting_lines` table.
- `backend/src/config/labs.js`: single list of lab IDs (`LAB_IDS`).
- `backend/src/routes/manager.js`: manager guard, `GET /api/manager/reports`, and `POST /api/manager/requests/:userId/decision`.
- `frontend/Manager/index.html`, `frontend/Scripts/manager-panel.js`, and `frontend/Styles/manager-panel.css`: the manager panel.

## Modified files
- `frontend/Scripts/vme-moba.js`
  - Practice hooks: upload tracking in `startUpload`, install checks and error tracking in `startVmManagerInstall`, and apt error tracking.
  - Hooks do nothing when `SimLabsPractice` is not loaded.
  - Practice mode (`data-lab-mode="practice"`) skips the save-password prompt and the keyboard-layout TUI. Both keep their default answers, so the simulated state does not change. Guided mode still shows them.
  - Long `stream` steps (apt update, upgrade and install, and dpkg output) show a `Progress: [####----] NN%` line at the bottom of the terminal. It is removed on completion or Ctrl+C. Replay is unchanged.
  - Starting an upload shows a toast and scrolls the SFTP upload progress bar into view.
- `frontend/Scripts/vme-progress.js`
  - Removed auto-complete for non-guided modes. Completion now comes from `vme:lab-complete`.
- `frontend/Styles/vme-guide.css`
  - `main.vme-lab--guided` and `main.vme-lab--practice` share the flex layout.
- `frontend/Scripts/vme-mode.js`
  - Updated the practice mode description.
- `frontend/VME/InstallationAndSetup.html`
  - Links `vme-practice.css`.
  - Loads `vme-practice.js` after `vme-guide.js`.
  - Removed `data-complete-event`.
- `backend/src/routes/auth.js`: `/register` accepts `accountType` (`learner` or `manager`) and, for learners, `managerEmail`, which must belong to a registered manager. Creates a `reporting_lines` row with status `pending`.
- `backend/src/app.js`: mounts the manager routes.
- `frontend/index.html` and `frontend/Scripts/auth.js`: "Manager sign-up" tab, a manager email field for learners, a "Manager panel" menu item for managers, and a redirect to the panel after a manager logs in.

## Verified in browser
- Page loads with the practice panel, and the timer ticks.
- Start disables Start and enables diagnosis.
- Hint 1 shows with a -3 penalty.
- Diagnosis is recorded and can be changed until Finish.
- Finish stays disabled until the install completes.
- SSH login to 172.16.3.3 works.
- Save-password prompt answered No.
- Upload of the QCOW image and DEB package completed. The DEB was re-uploaded after the `deb-missing` fault was observed.

## Lab run status
- Previous run: not complete. No score was produced.
- apt update and upgrade completed. The keyboard layout prompt was answered with the default.
- `apt install -f /root/hpe-vm_1.0.15-1_amd64.deb -y` returned "apt: command not found".
- `dpkg -i` ran without output. `hpe-vm` was not installed and not on the PATH.
- Finish remained disabled.

## Install fix (code changes, browser run pending)
- `vme-moba.js`: `apt install` accepts any `.deb` argument (absolute, relative, or bare name, with or without `-f`/`-y`). `dpkg -i`/`--install` is handled, prints the unpack and setup output, and sets the installed state. Both reject non-root users and missing files with the matching error messages.
- The CLI install emits `hpe-vm-cli-install`. `vm-install-complete` is unchanged, so guided mode is not affected.
- `vme-practice.js`: listens for `hpe-vm-cli-install`. When Finish is disabled because of the install, the note reads "hpe-vm is not installed yet. Install the .deb with apt install ./hpe-vm_1.0.15-1_amd64.deb -y or dpkg -i."
- Still to verify in the browser: apt with `./file.deb`, `dpkg -i`, the Finish note, and that a score is produced. Running `hpe-vm` after install still reports "reboot required" until the simulated reboot runs, as before.

## Reporting managers
- Managers sign up in a separate tab. Learners name their manager and that manager's email at sign-up, and the manager must already be registered.
- Each learner needs manager approval (`reporting_lines.status`). A learner whose request is pending or declined cannot sign in: login returns 403 with a reason, and the session check returns 403 for any existing session. Accounts with no reporting line (created before this feature) are not blocked. Only approved learners appear in the panel.
- The panel (`Manager/index.html`) shows pending requests with Approve and Decline, summary stats, a stacked status chart per learner, a best-score chart, a per-lab table, and each learner's practice score history.
- Verified against the database: the endpoint returns 401 without a session, returns the expected JSON for a manager, and approval moves a learner from pending to reports. Test rows were removed.
- Not yet verified: the panel's browser rendering and the register-form flow in a browser.
- Open questions: whether admins should see the panel, and whether learners should see their pending or declined status.

## Known limitations
- Scores are saved per account in the `lab_scores` table (migration `004_lab_scores.sql`) when the learner finishes. The scorecard shows the best score and recent attempts. The score is computed in the browser, so the server only validates its range and format.
- Only the VME installation and setup lab is covered.

## Repository memory
- `/memories/repo/simulated-labs-architecture.md` has a Practice Mode section.
